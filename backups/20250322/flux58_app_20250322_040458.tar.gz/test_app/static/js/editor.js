// FLUX58 Video Editor - Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
    console.log("Editor script loaded");
    
    // Initialize editor
    initEditor();
    
    // Add event listeners
    addEventListeners();
    
    // Initialize timeline tools
    initTimelineTools();
    
    // Log project data
    console.log("Project data:", projectData);
});

// Main initialization function
function initEditor() {
    console.log("Initializing editor...");
    
    // Check if OpenShot is available via our API
    checkOpenShotStatus();
    
    // Initialize timeline
    initTimeline();
    
    // Initialize preview player
    initPreviewPlayer();
    
    // Initialize media library
    initMediaLibrary();
    
    // Initialize properties panel
    initPropertiesPanel();
    
    // Initialize theme switcher
    initThemeSwitcher();
}

// Check OpenShot library status
function checkOpenShotStatus() {
    console.log("Checking OpenShot status...");
    
    // Make an AJAX request to check OpenShot status
    fetch('/api/openshot/status')
        .then(response => response.json())
        .then(data => {
            console.log("OpenShot status:", data);
            
            // Update UI based on OpenShot availability
            if (data.available) {
                console.log("OpenShot is available:", data.version);
                document.querySelector('.editor-header').classList.add('openshot-available');
            } else {
                console.warn("OpenShot is not available. Some features will be limited.");
                showError("OpenShot library is not available. Some video editing features will be limited.");
            }
        })
        .catch(error => {
            console.error("Error checking OpenShot status:", error);
            showError("Error connecting to OpenShot. Some features may not work.");
        });
}

// Initialize timeline
function initTimeline() {
    console.log("Initializing timeline...");
    
    // Set initial timeline data
    updateTimelineDisplay();
    
    // Initialize timeline playhead dragging
    initPlayheadDragging();
    
    // Initialize clip dragging
    initClipDragging();
}

// Update timeline display based on project data
function updateTimelineDisplay() {
    // Update time markers
    const duration = projectData.timeline.duration || 60;
    const timeMarkers = document.querySelector('.timeline-time-markers');
    timeMarkers.innerHTML = '';
    
    const markerCount = Math.ceil(duration / 10);
    for (let i = 0; i <= markerCount; i++) {
        const minutes = Math.floor((i * 10) / 60);
        const seconds = (i * 10) % 60;
        const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        const marker = document.createElement('div');
        marker.className = 'time-marker';
        marker.textContent = timeString;
        marker.style.left = `${i * 100}px`;
        timeMarkers.appendChild(marker);
    }
    
    // Update total time display
    document.getElementById('total-time').textContent = formatTime(duration);
}

// Initialize preview player
function initPreviewPlayer() {
    console.log("Initializing preview player...");
    
    const playBtn = document.getElementById('play-btn');
    const prevFrameBtn = document.getElementById('prev-frame-btn');
    const nextFrameBtn = document.getElementById('next-frame-btn');
    const muteBtn = document.getElementById('mute-btn');
    const scrubber = document.querySelector('.timeline-scrubber');
    
    // Set up play button
    playBtn.addEventListener('click', function() {
        togglePlayback();
    });
    
    // Set up prev/next frame buttons
    prevFrameBtn.addEventListener('click', function() {
        seekFrame(-1);
    });
    
    nextFrameBtn.addEventListener('click', function() {
        seekFrame(1);
    });
    
    // Set up mute button
    muteBtn.addEventListener('click', function() {
        toggleMute();
    });
    
    // Set up scrubber
    scrubber.addEventListener('click', function(e) {
        seekToPosition(e);
    });
}

// Initialize media library
function initMediaLibrary() {
    console.log("Initializing media library...");
    
    // Initialize upload buttons
    initUploadButtons();
    
    // Initialize media view toggle
    initMediaViewToggle();
    
    // Initialize media tabs
    initMediaTabs();
    
    // Initialize media sorting
    initMediaSorting();
    
    // Initialize media search
    initMediaSearch();
    
    // Initialize media preview buttons
    initMediaPreviewButtons();
    
    // Initialize media items drag and drop
    initMediaDragAndDrop();
}

// Initialize all upload buttons
function initUploadButtons() {
    // Get all upload buttons by their ids
    const uploadButtons = [
        'upload-media-btn',
        'upload-first-media-btn',
        'upload-video-btn',
        'upload-audio-btn'
    ];
    
    // Add click event to each button
    uploadButtons.forEach(btnId => {
        const btn = document.getElementById(btnId);
        if (btn) {
            btn.addEventListener('click', function() {
                // If this is a specific media type button, pre-select that type
                let mediaType = 'video'; // Default
                if (btnId.includes('audio')) {
                    mediaType = 'audio';
                } else if (btnId.includes('image')) {
                    mediaType = 'image';
                }
                
                showMediaUploadDialog(mediaType);
            });
        }
    });
    
    // Handle AI generation button
    const aiGenerateBtn = document.getElementById('ai-generate-btn');
    if (aiGenerateBtn) {
        aiGenerateBtn.addEventListener('click', function() {
            const promptInput = document.getElementById('ai-prompt-input');
            const prompt = promptInput.value.trim();
            
            if (prompt) {
                // Call the LTX video generation via its manager if available
                if (window.ltxManager) {
                    window.ltxManager.generateVideoFromPrompt();
                } else {
                    showError("AI generation service is not available");
                }
            } else {
                showError("Please enter a text prompt for AI generation");
            }
        });
    }
}

// Initialize media view toggle (list/grid view)
function initMediaViewToggle() {
    const viewToggleBtn = document.getElementById('media-view-toggle');
    if (viewToggleBtn) {
        viewToggleBtn.addEventListener('click', function() {
            const mediaItems = document.getElementById('all-media-items');
            if (mediaItems) {
                mediaItems.classList.toggle('grid-view');
                
                // Update icon
                const icon = viewToggleBtn.querySelector('i');
                if (mediaItems.classList.contains('grid-view')) {
                    icon.classList.remove('bi-grid');
                    icon.classList.add('bi-list');
                } else {
                    icon.classList.remove('bi-list');
                    icon.classList.add('bi-grid');
                }
                
                // Save preference to localStorage
                localStorage.setItem('media_view_mode', 
                    mediaItems.classList.contains('grid-view') ? 'grid' : 'list');
            }
        });
        
        // Apply saved preference
        const savedViewMode = localStorage.getItem('media_view_mode');
        if (savedViewMode === 'grid') {
            // Simulate click to switch to grid view
            viewToggleBtn.click();
        }
    }
}

// Initialize media tabs with filtering
function initMediaTabs() {
    // Listen for tab changes
    const tabLinks = document.querySelectorAll('.nav-link[data-bs-toggle="tab"]');
    tabLinks.forEach(tab => {
        tab.addEventListener('shown.bs.tab', function(event) {
            const targetId = event.target.getAttribute('data-bs-target');
            
            // Handle specific tab content loading
            if (targetId === '#video-media') {
                populateMediaTypeTab('video');
            } else if (targetId === '#audio-media') {
                populateMediaTypeTab('audio');
            } else if (targetId === '#ai-media') {
                populateAIMediaTab();
            }
        });
    });
    
    // Initial population of the "All" tab
    updateMediaCount();
}

// Populate a media tab with filtered content by type
function populateMediaTypeTab(mediaType) {
    const mediaList = document.getElementById(`${mediaType}-media-list`);
    if (!mediaList) return;
    
    // Find the empty message (to hide/show based on results)
    const emptyMessage = mediaList.querySelector('.empty-type-message');
    
    // Filter assets by type
    const filteredAssets = (projectData.assets || []).filter(asset => asset.type === mediaType);
    
    // Show/hide empty message based on results
    if (filteredAssets.length === 0) {
        if (emptyMessage) emptyMessage.style.display = 'block';
        return;
    } else {
        if (emptyMessage) emptyMessage.style.display = 'none';
    }
    
    // Create the container if it doesn't exist
    let mediaItemsContainer = mediaList.querySelector('.media-items-container');
    if (!mediaItemsContainer) {
        mediaItemsContainer = document.createElement('div');
        mediaItemsContainer.className = 'media-items-container';
        mediaItemsContainer.id = `${mediaType}-media-items`;
        
        // Add header first
        const header = document.createElement('div');
        header.className = 'd-flex justify-content-between align-items-center px-3 py-2';
        header.innerHTML = `
            <div>
                <span class="text-light fw-bold">${capitalizeFirstLetter(mediaType)} Files</span>
            </div>
        `;
        
        mediaList.insertBefore(header, emptyMessage);
        mediaList.insertBefore(mediaItemsContainer, emptyMessage);
    } else {
        // Clear existing items
        mediaItemsContainer.innerHTML = '';
    }
    
    // Add filtered media items
    filteredAssets.forEach(asset => {
        const mediaItem = createMediaItemElement(asset);
        mediaItemsContainer.appendChild(mediaItem);
    });
    
    // Initialize drag and drop for the new items
    initMediaDragAndDrop();
}

// Populate AI media tab
function populateAIMediaTab() {
    const mediaList = document.getElementById('ai-media-list');
    if (!mediaList) return;
    
    // Find the empty message
    const emptyMessage = document.getElementById('no-ai-media-message');
    
    // Filter assets that are AI-generated
    const aiAssets = (projectData.assets || []).filter(asset => {
        // In a real implementation, there would be a flag or property indicating AI generation
        // For now, we'll just check for "AI" in the name as a simple placeholder
        return asset.name && (
            asset.name.toLowerCase().includes('ai') || 
            asset.name.toLowerCase().includes('generated')
        );
    });
    
    // Show/hide empty message based on results
    if (aiAssets.length === 0) {
        if (emptyMessage) emptyMessage.style.display = 'block';
        return;
    } else {
        if (emptyMessage) emptyMessage.style.display = 'none';
    }
    
    // Create the container if it doesn't exist
    let mediaItemsContainer = mediaList.querySelector('.media-items-container');
    if (!mediaItemsContainer) {
        mediaItemsContainer = document.createElement('div');
        mediaItemsContainer.className = 'media-items-container';
        mediaItemsContainer.id = 'ai-media-items';
        mediaList.insertBefore(mediaItemsContainer, emptyMessage);
    } else {
        // Clear existing items
        mediaItemsContainer.innerHTML = '';
    }
    
    // Add AI media items
    aiAssets.forEach(asset => {
        const mediaItem = createMediaItemElement(asset, true);
        mediaItemsContainer.appendChild(mediaItem);
    });
    
    // Initialize drag and drop for the new items
    initMediaDragAndDrop();
}

// Create a media item element
function createMediaItemElement(asset, isAI = false) {
    const mediaItem = document.createElement('div');
    mediaItem.className = 'media-item';
    mediaItem.dataset.assetId = asset.id;
    mediaItem.dataset.assetType = asset.type;
    mediaItem.draggable = true;
    
    // Determine icon and color based on media type
    let icon = 'bi-file';
    let color = '#4a6cf7';
    
    if (asset.type === 'video') {
        icon = 'bi-film';
        color = '#4a6cf7';
    } else if (asset.type === 'audio') {
        icon = 'bi-music-note-beamed';
        color = '#50cd89';
    } else if (asset.type === 'image') {
        icon = 'bi-image';
        color = '#ffc700';
    }
    
    // Create inner HTML with proper structure
    mediaItem.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="media-thumbnail me-2" style="background-color: #2e2e40;">
                <i class="${icon}" style="color: ${color};"></i>
            </div>
            <div class="media-info">
                <div class="fw-bold">${asset.name}
                    ${isAI ? '<span class="ai-badge"><i class="bi bi-stars"></i>AI</span>' : ''}
                </div>
                <small style="color: #a0a0c2;">
                    ${asset.duration || '--'}s
                    <span class="media-actions">
                        <button class="btn btn-sm btn-link text-light p-0 media-preview-btn" title="Preview">
                            <i class="bi bi-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-link text-light p-0 media-options-btn ms-2" title="Options">
                            <i class="bi bi-three-dots-vertical"></i>
                        </button>
                    </span>
                </small>
            </div>
        </div>
    `;
    
    // Add event listeners
    const previewBtn = mediaItem.querySelector('.media-preview-btn');
    if (previewBtn) {
        previewBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            previewMediaItem(asset);
        });
    }
    
    const optionsBtn = mediaItem.querySelector('.media-options-btn');
    if (optionsBtn) {
        optionsBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            showMediaItemOptions(asset, optionsBtn);
        });
    }
    
    // Add click handler to select the media item
    mediaItem.addEventListener('click', function() {
        selectMediaItem(mediaItem);
    });
    
    return mediaItem;
}

// Initialize media preview buttons
function initMediaPreviewButtons() {
    // Add handlers for existing preview buttons
    document.querySelectorAll('.media-preview-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            
            const mediaItem = btn.closest('.media-item');
            if (mediaItem) {
                const assetId = mediaItem.dataset.assetId;
                const asset = projectData.assets.find(a => a.id === assetId);
                
                if (asset) {
                    previewMediaItem(asset);
                }
            }
        });
    });
}

// Preview a media item
function previewMediaItem(asset) {
    console.log("Previewing media item:", asset);
    
    const videoCanvas = document.getElementById('preview-canvas');
    if (!videoCanvas) return;
    
    // Clear preview content
    videoCanvas.innerHTML = '';
    
    if (asset.type === 'video') {
        // Create video element for preview
        const video = document.createElement('video');
        video.style.width = '100%';
        video.style.height = '100%';
        video.style.objectFit = 'contain';
        video.controls = true;
        
        // Set source (in a real implementation, this would use the actual file path)
        video.src = asset.path || `/api/assets/${asset.id}/stream`;
        
        // Add to canvas
        videoCanvas.appendChild(video);
        
        // Store reference and play
        window.videoPlayer = video;
        video.play().catch(e => console.error("Error playing video:", e));
        
    } else if (asset.type === 'audio') {
        // Create audio player with visualization
        const audioContainer = document.createElement('div');
        audioContainer.className = 'audio-preview-container';
        audioContainer.style.textAlign = 'center';
        
        const audioVisualizer = document.createElement('div');
        audioVisualizer.className = 'audio-visualizer';
        audioVisualizer.style.height = '120px';
        audioVisualizer.style.background = 'linear-gradient(to bottom, #50cd89, #26af67)';
        audioVisualizer.style.borderRadius = '8px';
        audioVisualizer.style.margin = '20px auto';
        audioVisualizer.style.width = '80%';
        
        const audio = document.createElement('audio');
        audio.controls = true;
        audio.style.width = '80%';
        audio.style.margin = '20px auto';
        
        // Set source
        audio.src = asset.path || `/api/assets/${asset.id}/stream`;
        
        // Add components to container
        audioContainer.appendChild(audioVisualizer);
        audioContainer.appendChild(audio);
        
        // Add to canvas
        videoCanvas.appendChild(audioContainer);
        
        // Create simple audio visualization
        if (window.AudioContext || window.webkitAudioContext) {
            try {
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const analyser = audioContext.createAnalyser();
                const source = audioContext.createMediaElementSource(audio);
                
                source.connect(analyser);
                analyser.connect(audioContext.destination);
                
                analyser.fftSize = 256;
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);
                
                // Create visualization bars
                for (let i = 0; i < bufferLength; i++) {
                    const bar = document.createElement('div');
                    bar.className = 'visualizer-bar';
                    bar.style.width = `${100 / bufferLength}%`;
                    bar.style.height = '2px';
                    bar.style.background = 'rgba(255, 255, 255, 0.7)';
                    bar.style.position = 'absolute';
                    bar.style.bottom = '0';
                    bar.style.left = `${(i * 100) / bufferLength}%`;
                    audioVisualizer.appendChild(bar);
                }
                
                // Visualization animation
                function renderFrame() {
                    requestAnimationFrame(renderFrame);
                    
                    analyser.getByteFrequencyData(dataArray);
                    
                    const bars = audioVisualizer.querySelectorAll('.visualizer-bar');
                    for (let i = 0; i < bars.length; i++) {
                        const height = dataArray[i] / 2;
                        bars[i].style.height = height + 'px';
                    }
                }
                
                audio.addEventListener('play', function() {
                    renderFrame();
                });
                
            } catch (e) {
                console.error("Error creating audio visualization:", e);
            }
        }
        
        // Play audio
        audio.play().catch(e => console.error("Error playing audio:", e));
        
    } else if (asset.type === 'image') {
        // Create image preview
        const img = document.createElement('img');
        img.style.maxWidth = '100%';
        img.style.maxHeight = '100%';
        img.style.objectFit = 'contain';
        
        // Set source
        img.src = asset.path || `/api/assets/${asset.id}/stream`;
        
        // Add to canvas
        videoCanvas.appendChild(img);
    }
}

// Show options menu for a media item
function showMediaItemOptions(asset, buttonElement) {
    // Create context menu
    const menu = document.createElement('div');
    menu.className = 'dropdown-menu dropdown-menu-dark show';
    menu.style.position = 'absolute';
    menu.style.zIndex = '1050';
    
    // Add menu items
    menu.innerHTML = `
        <a class="dropdown-item" href="#" data-action="add-to-timeline">
            <i class="bi bi-plus-circle me-2"></i> Add to Timeline
        </a>
        <a class="dropdown-item" href="#" data-action="preview">
            <i class="bi bi-eye me-2"></i> Preview
        </a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="#" data-action="rename">
            <i class="bi bi-pencil me-2"></i> Rename
        </a>
        <a class="dropdown-item" href="#" data-action="duplicate">
            <i class="bi bi-files me-2"></i> Duplicate
        </a>
        <a class="dropdown-item" href="#" data-action="enhance" ${asset.type !== 'video' ? 'style="display:none"' : ''}>
            <i class="bi bi-stars me-2"></i> AI Enhance
        </a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item text-danger" href="#" data-action="delete">
            <i class="bi bi-trash me-2"></i> Delete
        </a>
    `;
    
    // Position the menu relative to the button
    const buttonRect = buttonElement.getBoundingClientRect();
    menu.style.top = `${buttonRect.bottom + 5}px`;
    menu.style.left = `${buttonRect.left - 200}px`; // Align the right edge
    
    // Add to document
    document.body.appendChild(menu);
    
    // Add event handlers for menu items
    menu.querySelectorAll('.dropdown-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            const action = this.dataset.action;
            
            // Handle different actions
            switch(action) {
                case 'add-to-timeline':
                    addAssetToTimeline(asset);
                    break;
                case 'preview':
                    previewMediaItem(asset);
                    break;
                case 'rename':
                    renameMediaItem(asset);
                    break;
                case 'duplicate':
                    duplicateMediaItem(asset);
                    break;
                case 'enhance':
                    enhanceMediaItem(asset);
                    break;
                case 'delete':
                    deleteMediaItem(asset);
                    break;
            }
            
            // Remove menu
            menu.remove();
        });
    });
    
    // Close menu when clicking outside
    function closeMenu(e) {
        if (!menu.contains(e.target) && e.target !== buttonElement) {
            menu.remove();
            document.removeEventListener('click', closeMenu);
        }
    }
    
    // Add click listener to document to close menu
    setTimeout(() => {
        document.addEventListener('click', closeMenu);
    }, 0);
}

// Select a media item
function selectMediaItem(mediaItem) {
    // Deselect all other media items
    document.querySelectorAll('.media-item.selected').forEach(item => {
        item.classList.remove('selected');
    });
    
    // Select this media item
    mediaItem.classList.add('selected');
    
    // Get asset data
    const assetId = mediaItem.dataset.assetId;
    const asset = projectData.assets.find(a => a.id === assetId);
    
    if (asset) {
        // Show asset details in properties panel
        showAssetProperties(asset);
    }
}

// Show asset properties in the properties panel
function showAssetProperties(asset) {
    // For now, just show basic asset details in the console
    console.log("Selected asset:", asset);
    
    // In a full implementation, we would update the properties panel with asset details
}

// Initialize media sorting
function initMediaSorting() {
    const sortLinks = document.querySelectorAll('[data-sort]');
    sortLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const sortType = this.dataset.sort;
            sortMediaItems(sortType);
            
            // Update active sort indicator
            document.querySelectorAll('[data-sort]').forEach(l => {
                l.classList.remove('active');
            });
            this.classList.add('active');
            
            // Update sort dropdown text
            const dropdownButton = document.getElementById('sortDropdown');
            if (dropdownButton) {
                const sortText = this.textContent.trim();
                dropdownButton.innerHTML = `<i class="bi bi-sort-down"></i> ${sortText}`;
            }
        });
    });
}

// Sort media items
function sortMediaItems(sortType) {
    if (!projectData.assets || !projectData.assets.length) return;
    
    // Clone the assets array to avoid modifying the original
    const sortedAssets = [...projectData.assets];
    
    // Sort based on the selected sort type
    switch(sortType) {
        case 'date-desc':
            sortedAssets.sort((a, b) => {
                return new Date(b.created_at || 0) - new Date(a.created_at || 0);
            });
            break;
        case 'date-asc':
            sortedAssets.sort((a, b) => {
                return new Date(a.created_at || 0) - new Date(b.created_at || 0);
            });
            break;
        case 'name-asc':
            sortedAssets.sort((a, b) => {
                return (a.name || '').localeCompare(b.name || '');
            });
            break;
        case 'name-desc':
            sortedAssets.sort((a, b) => {
                return (b.name || '').localeCompare(a.name || '');
            });
            break;
        case 'type':
            sortedAssets.sort((a, b) => {
                return (a.type || '').localeCompare(b.type || '');
            });
            break;
    }
    
    // Regenerate media items with sorted assets
    refreshMediaItems(sortedAssets);
}

// Refresh media items with a new array of assets
function refreshMediaItems(assets) {
    const allMediaItems = document.getElementById('all-media-items');
    if (!allMediaItems) return;
    
    // Clear existing items
    allMediaItems.innerHTML = '';
    
    // Add sorted media items
    assets.forEach(asset => {
        const mediaItem = createMediaItemElement(asset);
        allMediaItems.appendChild(mediaItem);
    });
    
    // Initialize drag and drop for the new items
    initMediaDragAndDrop();
}

// Initialize media search
function initMediaSearch() {
    const searchInput = document.getElementById('media-search');
    const searchButton = document.getElementById('search-media-btn');
    
    if (searchInput && searchButton) {
        // Search on button click
        searchButton.addEventListener('click', function() {
            searchMediaItems(searchInput.value);
        });
        
        // Search on Enter key
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchMediaItems(searchInput.value);
            }
        });
        
        // Clear search when input is cleared
        searchInput.addEventListener('input', function() {
            if (this.value === '') {
                // Reset search
                refreshMediaItems(projectData.assets);
                updateMediaCount();
            }
        });
    }
}

// Search media items
function searchMediaItems(searchTerm) {
    if (!searchTerm) {
        // If empty search term, show all items
        refreshMediaItems(projectData.assets);
        updateMediaCount();
        return;
    }
    
    // Convert to lowercase for case-insensitive search
    searchTerm = searchTerm.toLowerCase();
    
    // Filter assets by search term
    const filteredAssets = projectData.assets.filter(asset => {
        return (
            (asset.name && asset.name.toLowerCase().includes(searchTerm)) ||
            (asset.type && asset.type.toLowerCase().includes(searchTerm))
        );
    });
    
    // Update media items
    refreshMediaItems(filteredAssets);
    
    // Update count
    updateMediaCount(filteredAssets.length, searchTerm);
}

// Update media count display
function updateMediaCount(count, searchTerm) {
    const countElement = document.getElementById('media-count');
    if (!countElement) return;
    
    if (searchTerm) {
        // Show search results count
        countElement.textContent = `${count} result${count !== 1 ? 's' : ''} for "${searchTerm}"`;
    } else if (count !== undefined) {
        // Show total count
        countElement.textContent = `${count} file${count !== 1 ? 's' : ''}`;
    } else {
        // Reset to default
        const totalCount = (projectData.assets || []).length;
        countElement.textContent = `${totalCount} file${totalCount !== 1 ? 's' : ''}`;
    }
}

// Helper function to capitalize first letter
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Initialize properties panel
function initPropertiesPanel() {
    console.log("Initializing properties panel...");
    
    // Show "no selection" message if no clip is selected
    document.getElementById('no-selection').style.display = 'block';
    document.getElementById('clip-properties').style.display = 'none';
}

// Add event listeners
function addEventListeners() {
    // Export button
    const exportBtn = document.getElementById('export-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            showExportDialog();
        });
    }
    
    // Save button
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            saveProject();
        });
    }
    
    // AI Assist button
    const aiAssistBtn = document.getElementById('ai-assist-btn');
    if (aiAssistBtn) {
        aiAssistBtn.addEventListener('click', function() {
            showAIAssistDialog();
        });
    }
}

// UI Helper Functions

// Show media upload dialog
function showMediaUploadDialog() {
    console.log("Showing media upload dialog...");
    
    // Create modal dialog HTML
    const modalHTML = `
    <div class="modal fade" id="uploadMediaModal" tabindex="-1" aria-labelledby="uploadMediaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content bg-dark text-light">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadMediaModalLabel">Upload Media</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="uploadMediaForm" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="mediaFile" class="form-label">Select media file</label>
                            <input type="file" class="form-control bg-dark text-light" id="mediaFile" name="file" accept="video/*,audio/*,image/*">
                        </div>
                        <div class="mb-3">
                            <label for="mediaType" class="form-label">Media type</label>
                            <select class="form-select bg-dark text-light" id="mediaType" name="type">
                                <option value="video">Video</option>
                                <option value="audio">Audio</option>
                                <option value="image">Image</option>
                            </select>
                        </div>
                        <input type="hidden" name="project_id" value="${projectData.id}">
                    </form>
                    <div class="progress d-none mt-3" id="uploadProgress">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 0%"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="uploadMediaBtn">Upload</button>
                </div>
            </div>
        </div>
    </div>
    `;
    
    // Add modal to the document
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Initialize the modal
    const modal = new bootstrap.Modal(document.getElementById('uploadMediaModal'));
    modal.show();
    
    // Handle file upload
    document.getElementById('uploadMediaBtn').addEventListener('click', function() {
        const form = document.getElementById('uploadMediaForm');
        const formData = new FormData(form);
        const fileInput = document.getElementById('mediaFile');
        
        if (!fileInput.files.length) {
            alert('Please select a file to upload');
            return;
        }
        
        // Show progress bar
        const progressBar = document.querySelector('#uploadProgress .progress-bar');
        document.getElementById('uploadProgress').classList.remove('d-none');
        
        // Upload file with XHR to show progress
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/assets/upload', true);
        
        xhr.upload.onprogress = function(e) {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                progressBar.style.width = percentComplete + '%';
            }
        };
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                
                if (response.success) {
                    // Add the new asset to the project data
                    if (!projectData.assets) {
                        projectData.assets = [];
                    }
                    
                    projectData.assets.push(response.asset);
                    
                    // Close the modal
                    modal.hide();
                    
                    // Show success message
                    alert('Media uploaded successfully!');
                    
                    // Refresh the media library display
                    refreshMediaLibrary();
                } else {
                    alert('Error uploading media: ' + response.error);
                }
            } else {
                alert('Error uploading media. Please try again.');
            }
        };
        
        xhr.onerror = function() {
            alert('Error uploading media. Please try again.');
        };
        
        xhr.send(formData);
    });
    
    // Clean up the modal when it's hidden
    document.getElementById('uploadMediaModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

// Refresh media library display
function refreshMediaLibrary() {
    const mediaList = document.querySelector('.media-list');
    const itemsSection = mediaList.querySelector('div:not(.mb-3):not(.ai-tools)');
    
    // Clear existing items (except the search box and AI tools)
    if (itemsSection) {
        itemsSection.innerHTML = '';
    }
    
    // Re-add the header
    let mediaItemsHTML = `
    <div class="d-flex justify-content-between mb-2">
        <div>
            <span class="text-light">Files</span>
        </div>
        <div>
            <a href="#" class="text-light small"><i class="bi bi-sort-down"></i> Date</a>
        </div>
    </div>
    `;
    
    // Add media items
    if (projectData.assets && projectData.assets.length > 0) {
        projectData.assets.forEach((asset, index) => {
            let icon = 'bi-file';
            let color = '#4a6cf7';
            
            if (asset.type === 'video') {
                icon = 'bi-film';
                color = '#4a6cf7';
            } else if (asset.type === 'audio') {
                icon = 'bi-music-note-beamed';
                color = '#50cd89';
            } else if (asset.type === 'image') {
                icon = 'bi-image';
                color = '#ffc700';
            }
            
            mediaItemsHTML += `
            <div class="media-item" data-asset-id="${asset.id}" draggable="true">
                <div class="d-flex align-items-center">
                    <i class="${icon} me-2" style="color: ${color};"></i>
                    <div>
                        <div class="fw-bold">${asset.name}
                            ${index === 0 ? '<span class="ai-badge"><i class="bi bi-stars"></i>AI</span>' : ''}
                        </div>
                        <small style="color: #a0a0c2;">${asset.duration || '--'}s</small>
                    </div>
                </div>
            </div>
            `;
        });
    } else {
        mediaItemsHTML += `
        <div class="text-center py-4">
            <i class="bi bi-upload display-6" style="color: #4a6cf7;"></i>
            <p class="mt-2" style="color: #a0a0c2;">No media files</p>
            <button class="btn btn-sm mt-2" style="background: linear-gradient(135deg, #4a6cf7, #7239ea); color: white;" id="upload-first-media-btn">Upload Media</button>
        </div>
        `;
    }
    
    // Add the HTML to the media list
    if (itemsSection) {
        itemsSection.innerHTML = mediaItemsHTML;
    } else {
        mediaList.insertAdjacentHTML('beforeend', mediaItemsHTML);
    }
    
    // Add event listeners for the new items
    const mediaItems = document.querySelectorAll('.media-item');
    const uploadFirstBtn = document.getElementById('upload-first-media-btn');
    
    mediaItems.forEach(item => {
        item.addEventListener('dragstart', function(e) {
            e.dataTransfer.setData('text/plain', item.dataset.assetId);
            e.dataTransfer.effectAllowed = 'copy';
        });
    });
    
    if (uploadFirstBtn) {
        uploadFirstBtn.addEventListener('click', function() {
            showMediaUploadDialog();
        });
    }
}

// Show export dialog
function showExportDialog() {
    console.log("Showing export dialog...");
    
    // Create modal dialog HTML
    const modalHTML = `
    <div class="modal fade" id="exportModal" tabindex="-1" aria-labelledby="exportModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content bg-dark text-light">
                <div class="modal-header">
                    <h5 class="modal-title" id="exportModalLabel">Export Video</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="exportForm">
                        <div class="mb-3">
                            <label for="exportFormat" class="form-label">Format</label>
                            <select class="form-select bg-dark text-light" id="exportFormat" name="format">
                                <option value="mp4">MP4 (H.264)</option>
                                <option value="webm">WebM (VP9)</option>
                                <option value="mov">MOV (ProRes)</option>
                                <option value="gif">GIF (Animated)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="exportResolution" class="form-label">Resolution</label>
                            <select class="form-select bg-dark text-light" id="exportResolution" name="resolution">
                                <option value="1080p">1080p (1920x1080)</option>
                                <option value="720p">720p (1280x720)</option>
                                <option value="480p">480p (854x480)</option>
                                <option value="4k">4K (3840x2160)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="exportQuality" class="form-label">Quality</label>
                            <select class="form-select bg-dark text-light" id="exportQuality" name="quality">
                                <option value="high">High (10 credits)</option>
                                <option value="medium">Medium (5 credits)</option>
                                <option value="low">Low (Free)</option>
                            </select>
                        </div>
                        <input type="hidden" name="project_id" value="${projectData.id}">
                    </form>
                    <div class="progress d-none mt-3" id="exportProgress">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 0%"></div>
                    </div>
                    <div class="d-none mt-3" id="exportStatus">
                        <div class="alert alert-info">
                            <div class="d-flex align-items-center">
                                <div class="spinner-border spinner-border-sm me-2" role="status"></div>
                                <span id="exportStatusText">Starting export...</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="startExportBtn">Export</button>
                </div>
            </div>
        </div>
    </div>
    `;
    
    // Add modal to the document
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Initialize the modal
    const modal = new bootstrap.Modal(document.getElementById('exportModal'));
    modal.show();
    
    // Handle export
    document.getElementById('startExportBtn').addEventListener('click', function() {
        const form = document.getElementById('exportForm');
        const formData = new FormData(form);
        const exportData = {};
        
        // Convert FormData to JSON object
        for (const [key, value] of formData.entries()) {
            exportData[key] = value;
        }
        
        // Show progress and status
        document.getElementById('exportProgress').classList.remove('d-none');
        document.getElementById('exportStatus').classList.remove('d-none');
        document.getElementById('startExportBtn').disabled = true;
        
        // Make request to create export job
        fetch('/api/exports', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(exportData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Start polling for export status
                const exportId = data.export.id;
                pollExportStatus(exportId);
            } else {
                // Show error
                document.getElementById('exportStatusText').textContent = 'Error: ' + (data.error || 'Unknown error');
                document.getElementById('exportProgress').classList.add('d-none');
                document.getElementById('startExportBtn').disabled = false;
            }
        })
        .catch(error => {
            console.error('Error starting export:', error);
            document.getElementById('exportStatusText').textContent = 'Error starting export. Please try again.';
            document.getElementById('exportProgress').classList.add('d-none');
            document.getElementById('startExportBtn').disabled = false;
        });
    });
    
    // Clean up the modal when it's hidden
    document.getElementById('exportModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

// Poll export status
function pollExportStatus(exportId) {
    const statusElement = document.getElementById('exportStatusText');
    const progressBar = document.querySelector('#exportProgress .progress-bar');
    
    const checkStatus = () => {
        fetch(`/api/exports/${exportId}`)
            .then(response => response.json())
            .then(data => {
                if (data.export) {
                    const export_job = data.export;
                    const progress = export_job.progress || 0;
                    
                    // Update progress bar
                    progressBar.style.width = `${progress}%`;
                    
                    // Update status text
                    statusElement.textContent = `${export_job.status}: ${progress}%`;
                    
                    // Check if export is complete
                    if (export_job.status === 'completed') {
                        statusElement.textContent = 'Export completed!';
                        
                        // Show download link
                        const exportStatus = document.getElementById('exportStatus');
                        exportStatus.innerHTML = `
                            <div class="alert alert-success">
                                <strong>Export completed!</strong><br>
                                <a href="/exports/${exportId}/download" class="btn btn-primary mt-2">
                                    <i class="bi bi-download"></i> Download Video
                                </a>
                            </div>
                        `;
                        
                        return;
                    } else if (export_job.status === 'failed') {
                        statusElement.textContent = 'Export failed: ' + (export_job.error || 'Unknown error');
                        return;
                    }
                    
                    // Continue polling if not complete
                    setTimeout(checkStatus, 2000);
                } else {
                    statusElement.textContent = 'Error: Could not get export status';
                }
            })
            .catch(error => {
                console.error('Error checking export status:', error);
                statusElement.textContent = 'Error checking export status. Retrying...';
                
                // Retry in 5 seconds
                setTimeout(checkStatus, 5000);
            });
    };
    
    // Start checking status
    checkStatus();
}

// Show AI assist dialog
function showAIAssistDialog() {
    console.log("Showing AI assist dialog...");
    alert("AI assist feature not implemented yet.");
}

// Initialize theme switcher
function initThemeSwitcher() {
    console.log("Initializing theme switcher...");
    
    // Add theme switcher button to editor header
    const editorHeader = document.querySelector('.editor-header > div:last-child');
    
    if (editorHeader) {
        // Create the theme switcher button and dropdown
        const themeSwitcherHTML = `
            <div class="theme-switcher me-2">
                <button class="btn btn-outline-light btn-sm" id="theme-toggle-btn">
                    <i class="bi bi-palette"></i> Theme
                </button>
                <div class="theme-dropdown">
                    <div class="theme-option" data-theme="default">
                        <div class="theme-color dark"></div>
                        <span>Dark (Default)</span>
                    </div>
                    <div class="theme-option" data-theme="blue">
                        <div class="theme-color blue"></div>
                        <span>Blue Ocean</span>
                    </div>
                    <div class="theme-option" data-theme="green">
                        <div class="theme-color green"></div>
                        <span>Forest Green</span>
                    </div>
                    <div class="theme-option" data-theme="high-contrast">
                        <div class="theme-color high-contrast"></div>
                        <span>High Contrast</span>
                    </div>
                </div>
            </div>
        `;
        
        // Insert the theme switcher before the first button
        editorHeader.insertAdjacentHTML('afterbegin', themeSwitcherHTML);
        
        // Add event listeners to theme options
        const themeOptions = document.querySelectorAll('.theme-option');
        themeOptions.forEach(option => {
            option.addEventListener('click', function() {
                const theme = this.dataset.theme;
                setTheme(theme);
                
                // Mark this option as active
                themeOptions.forEach(opt => opt.classList.remove('active'));
                this.classList.add('active');
                
                // Save theme preference to localStorage
                localStorage.setItem('editor_theme', theme);
            });
        });
        
        // Load saved theme preference or use default
        const savedTheme = localStorage.getItem('editor_theme');
        if (savedTheme) {
            setTheme(savedTheme);
            
            // Mark the saved theme option as active
            const activeOption = document.querySelector(`.theme-option[data-theme="${savedTheme}"]`);
            if (activeOption) {
                activeOption.classList.add('active');
            }
        } else {
            // Mark default theme as active
            const defaultOption = document.querySelector('.theme-option[data-theme="default"]');
            if (defaultOption) {
                defaultOption.classList.add('active');
            }
        }
    }
}

// Set the theme
function setTheme(theme) {
    // Remove any existing theme classes
    document.documentElement.classList.remove('theme-blue', 'theme-green', 'theme-high-contrast');
    
    // Add the selected theme class if not default
    if (theme !== 'default') {
        document.documentElement.classList.add(`theme-${theme}`);
    }
    
    console.log(`Theme set to: ${theme}`);
}

// Save project
function saveProject() {
    console.log("Saving project...");
    
    // Make an AJAX request to save project
    fetch(`/api/projects/${projectData.id}/save`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(projectData)
    })
    .then(response => response.json())
    .then(data => {
        console.log("Project saved:", data);
        showSuccess("Project saved successfully");
    })
    .catch(error => {
        console.error("Error saving project:", error);
        showError("Error saving project");
    });
}

// Playback Functions

// Toggle play/pause
function togglePlayback() {
    console.log("Toggle playback");
    
    const playBtn = document.getElementById('play-btn');
    const playIcon = playBtn.querySelector('i');
    const videoCanvas = document.getElementById('preview-canvas');
    
    if (playIcon.classList.contains('bi-play-fill')) {
        // Start playback
        playIcon.classList.remove('bi-play-fill');
        playIcon.classList.add('bi-pause-fill');
        startPlayback();
    } else {
        // Pause playback
        playIcon.classList.remove('bi-pause-fill');
        playIcon.classList.add('bi-play-fill');
        pausePlayback();
    }
}

// Start playback
function startPlayback() {
    console.log("Starting playback...");
    
    const videoCanvas = document.getElementById('preview-canvas');
    const selectedClips = document.querySelectorAll('.clip.selected');
    
    // If we have a proper video player, start it
    if (window.videoPlayer) {
        window.videoPlayer.play();
        // Sync playhead with video timing
        syncPlayheadWithVideo();
        return;
    }
    
    // If no video player but a clip is selected and it has a video source
    if (selectedClips.length > 0) {
        const clipId = selectedClips[0].dataset.clipId;
        const assetId = selectedClips[0].dataset.assetId;
        
        // Try to find the asset data
        const assetData = projectData.assets.find(a => a.id === assetId);
        
        if (assetData && assetData.type === 'video') {
            // Create a video element if it doesn't exist
            let videoElement = videoCanvas.querySelector('video');
            if (!videoElement) {
                // Clear preview canvas content
                videoCanvas.innerHTML = '';
                
                // Create video element
                videoElement = document.createElement('video');
                videoElement.style.width = '100%';
                videoElement.style.height = '100%';
                videoElement.style.objectFit = 'contain';
                videoElement.controls = false;
                
                // Add to canvas
                videoCanvas.appendChild(videoElement);
                
                // Store video element as the player
                window.videoPlayer = videoElement;
                
                // Add event listeners
                videoElement.addEventListener('timeupdate', function() {
                    // Update current time display
                    document.getElementById('current-time').textContent = formatTime(videoElement.currentTime);
                    
                    // Update scrubber position
                    const duration = videoElement.duration;
                    const currentTime = videoElement.currentTime;
                    const position = duration > 0 ? currentTime / duration : 0;
                    updateScrubberPosition(position);
                    
                    // Update playhead position
                    const playhead = document.querySelector('.timeline-playhead');
                    const newPos = position * 600;
                    playhead.style.left = `${newPos}px`;
                });
                
                videoElement.addEventListener('ended', function() {
                    // Reset play button
                    const playBtn = document.getElementById('play-btn');
                    const playIcon = playBtn.querySelector('i');
                    playIcon.classList.remove('bi-pause-fill');
                    playIcon.classList.add('bi-play-fill');
                });
            }
            
            // Set video source
            // In a real implementation, we'd use the actual file path from the API
            const videoSource = assetData.path || `/api/assets/${assetId}/stream`;
            videoElement.src = videoSource;
            
            // Play video
            videoElement.play().catch(error => {
                console.error("Error playing video:", error);
                showError("Error playing video. Please try again.");
                
                // Fallback to playhead animation
                animatePlayhead();
            });
            
            return;
        }
    }
    
    // Fallback to playhead animation if no video player available
    animatePlayhead();
}

// Sync playhead with video timing
function syncPlayheadWithVideo() {
    if (!window.videoPlayer) return;
    
    // Clear existing interval
    if (window.playheadSyncInterval) {
        clearInterval(window.playheadSyncInterval);
    }
    
    // Set up interval to sync playhead with video
    window.playheadSyncInterval = setInterval(() => {
        if (!window.videoPlayer) {
            clearInterval(window.playheadSyncInterval);
            return;
        }
        
        const playhead = document.querySelector('.timeline-playhead');
        const duration = window.videoPlayer.duration;
        const currentTime = window.videoPlayer.currentTime;
        const position = duration > 0 ? currentTime / duration : 0;
        
        // Update playhead position
        const newPos = position * 600;
        playhead.style.left = `${newPos}px`;
        
        // Update scrubber position
        updateScrubberPosition(position);
        
        // Update current time display
        document.getElementById('current-time').textContent = formatTime(currentTime);
    }, 50);
}

// Pause playback
function pausePlayback() {
    console.log("Pausing playback...");
    
    // Pause video player if available
    if (window.videoPlayer) {
        window.videoPlayer.pause();
    }
    
    // Stop playhead animation
    if (window.playheadInterval) {
        clearInterval(window.playheadInterval);
    }
    
    // Stop playhead sync
    if (window.playheadSyncInterval) {
        clearInterval(window.playheadSyncInterval);
    }
}

// Animate playhead
function animatePlayhead() {
    // Get current playhead position
    const playhead = document.querySelector('.timeline-playhead');
    const currentLeft = parseInt(playhead.style.left) || 0;
    
    // Clear any existing interval
    if (window.playheadInterval) {
        clearInterval(window.playheadInterval);
    }
    
    // Set up new interval to move playhead
    window.playheadInterval = setInterval(() => {
        const newPos = (parseInt(playhead.style.left) || 0) + 1;
        
        // Check if we've reached the end
        if (newPos >= 600) {
            clearInterval(window.playheadInterval);
            const playBtn = document.getElementById('play-btn');
            const playIcon = playBtn.querySelector('i');
            playIcon.classList.remove('bi-pause-fill');
            playIcon.classList.add('bi-play-fill');
            return;
        }
        
        // Update playhead position
        playhead.style.left = `${newPos}px`;
        
        // Update scrubber position
        updateScrubberPosition(newPos / 600);
        
        // Update current time display
        const totalTime = projectData.timeline.duration || 60;
        const currentTime = (newPos / 600) * totalTime;
        document.getElementById('current-time').textContent = formatTime(currentTime);
    }, 50);
}

// Seek to frame
function seekFrame(direction) {
    console.log(`Seeking frame: ${direction}`);
    
    // Get current playhead position
    const playhead = document.querySelector('.timeline-playhead');
    let currentPos = parseInt(playhead.style.left) || 0;
    
    // Move by 5 pixels in the specified direction
    currentPos += (direction * 5);
    
    // Ensure we stay within bounds
    currentPos = Math.max(0, Math.min(600, currentPos));
    
    // Update playhead position
    playhead.style.left = `${currentPos}px`;
    
    // Update scrubber position
    updateScrubberPosition(currentPos / 600);
    
    // Update current time display
    const totalTime = projectData.timeline.duration || 60;
    const currentTime = (currentPos / 600) * totalTime;
    document.getElementById('current-time').textContent = formatTime(currentTime);
}

// Toggle mute
function toggleMute() {
    console.log("Toggle mute");
    
    const muteBtn = document.getElementById('mute-btn');
    const muteIcon = muteBtn.querySelector('i');
    
    if (muteIcon.classList.contains('bi-volume-up-fill')) {
        // Mute
        muteIcon.classList.remove('bi-volume-up-fill');
        muteIcon.classList.add('bi-volume-mute-fill');
    } else {
        // Unmute
        muteIcon.classList.remove('bi-volume-mute-fill');
        muteIcon.classList.add('bi-volume-up-fill');
    }
}

// Seek to position
function seekToPosition(e) {
    const scrubber = document.querySelector('.timeline-scrubber');
    const rect = scrubber.getBoundingClientRect();
    const clickPos = (e.clientX - rect.left) / rect.width;
    
    // Update scrubber position
    updateScrubberPosition(clickPos);
    
    // Update playhead position
    const playhead = document.querySelector('.timeline-playhead');
    const newPos = clickPos * 600;
    playhead.style.left = `${newPos}px`;
    
    // Update current time display
    const totalTime = projectData.timeline.duration || 60;
    const currentTime = clickPos * totalTime;
    document.getElementById('current-time').textContent = formatTime(currentTime);
}

// Update scrubber position
function updateScrubberPosition(position) {
    // Ensure position is between 0 and 1
    position = Math.max(0, Math.min(1, position));
    
    // Update progress bar
    const progress = document.querySelector('.timeline-scrubber .progress');
    progress.style.width = `${position * 100}%`;
    
    // Update handle position
    const handle = document.querySelector('.timeline-scrubber .handle');
    handle.style.left = `${position * 100}%`;
}

// Initialize playhead dragging
function initPlayheadDragging() {
    const playhead = document.querySelector('.timeline-playhead');
    const timeline = document.querySelector('.timeline-tracks');
    
    let isDragging = false;
    
    playhead.addEventListener('mousedown', function(e) {
        isDragging = true;
        e.preventDefault();
    });
    
    document.addEventListener('mousemove', function(e) {
        if (!isDragging) return;
        
        const rect = timeline.getBoundingClientRect();
        let newPos = e.clientX - rect.left;
        
        // Ensure we stay within bounds
        newPos = Math.max(0, Math.min(rect.width, newPos));
        
        // Update playhead position
        playhead.style.left = `${newPos}px`;
        
        // Update scrubber position
        updateScrubberPosition(newPos / 600);
        
        // Update current time display
        const totalTime = projectData.timeline.duration || 60;
        const currentTime = (newPos / 600) * totalTime;
        document.getElementById('current-time').textContent = formatTime(currentTime);
    });
    
    document.addEventListener('mouseup', function() {
        isDragging = false;
    });
}

// Initialize clip dragging
function initClipDragging(clipsToInit) {
    const clips = clipsToInit || document.querySelectorAll('.clip');
    
    clips.forEach(clip => {
        let isDragging = false;
        let startX, startLeft;
        let originalPos, originalWidth;
        
        clip.addEventListener('mousedown', function(e) {
            // Right-click for context menu
            if (e.button === 2) {
                showClipContextMenu(e, clip);
                return;
            }
            
            // Check if it's a resize handle click
            if (e.target.classList.contains('clip-resize-handle')) {
                initClipResize(e, clip);
                return;
            }
            
            isDragging = true;
            startX = e.clientX;
            startLeft = parseInt(clip.style.left) || 0;
            originalPos = startLeft;
            
            // Show properties for selected clip
            showClipProperties(clip);
            
            // Add selected class to highlight currently selected clip
            document.querySelectorAll('.clip').forEach(c => {
                c.classList.remove('selected');
            });
            clip.classList.add('selected');
            
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', function(e) {
            if (!isDragging) return;
            
            const dx = e.clientX - startX;
            let newLeft = startLeft + dx;
            
            // Ensure we stay within bounds
            newLeft = Math.max(0, newLeft);
            
            // Snap to grid if enabled
            if (projectData.timeline.snapToGrid) {
                // Snap to 10px intervals
                newLeft = Math.round(newLeft / 10) * 10;
            }
            
            // Update clip position
            clip.style.left = `${newLeft}px`;
            
            // Update position in properties panel
            const startTimeInput = document.getElementById('clip-start-time');
            if (startTimeInput) {
                startTimeInput.value = (newLeft / 10).toFixed(1);
            }
        });
        
        document.addEventListener('mouseup', function() {
            if (isDragging) {
                // Check if position changed
                const finalPos = parseInt(clip.style.left) || 0;
                if (finalPos !== originalPos) {
                    // Save project since clip moved
                    saveProject();
                }
            }
            isDragging = false;
        });
        
        // Add resize handles if not already present
        if (!clip.querySelector('.clip-resize-handle-left')) {
            const leftHandle = document.createElement('div');
            leftHandle.className = 'clip-resize-handle clip-resize-handle-left';
            clip.appendChild(leftHandle);
            
            const rightHandle = document.createElement('div');
            rightHandle.className = 'clip-resize-handle clip-resize-handle-right';
            clip.appendChild(rightHandle);
        }
    });
}

// Initialize clip resizing
function initClipResize(event, clip) {
    event.preventDefault();
    event.stopPropagation();
    
    const handle = event.target;
    const isLeftHandle = handle.classList.contains('clip-resize-handle-left');
    
    const startX = event.clientX;
    const originalLeft = parseInt(clip.style.left) || 0;
    const originalWidth = parseInt(clip.style.width) || 100;
    
    // Function to handle resize
    const handleResize = function(e) {
        const dx = e.clientX - startX;
        
        if (isLeftHandle) {
            // Resizing from left
            let newLeft = originalLeft + dx;
            let newWidth = originalWidth - dx;
            
            // Enforce minimum width
            if (newWidth < 20) {
                newWidth = 20;
                newLeft = originalLeft + originalWidth - 20;
            }
            
            // Ensure we don't go below 0
            newLeft = Math.max(0, newLeft);
            
            // Snap to grid if enabled
            if (projectData.timeline.snapToGrid) {
                newLeft = Math.round(newLeft / 10) * 10;
                // Recalculate width based on snapped left
                newWidth = originalWidth - (newLeft - originalLeft);
            }
            
            clip.style.left = `${newLeft}px`;
            clip.style.width = `${newWidth}px`;
            
            // Update position in properties panel
            document.getElementById('clip-start-time').value = (newLeft / 10).toFixed(1);
            document.getElementById('clip-duration').value = (newWidth / 10).toFixed(1);
        } else {
            // Resizing from right
            let newWidth = originalWidth + dx;
            
            // Enforce minimum width
            newWidth = Math.max(20, newWidth);
            
            // Snap to grid if enabled
            if (projectData.timeline.snapToGrid) {
                newWidth = Math.round(newWidth / 10) * 10;
            }
            
            clip.style.width = `${newWidth}px`;
            
            // Update duration in properties panel
            document.getElementById('clip-duration').value = (newWidth / 10).toFixed(1);
        }
    };
    
    // Function to finish resize
    const finishResize = function() {
        document.removeEventListener('mousemove', handleResize);
        document.removeEventListener('mouseup', finishResize);
        
        // Save project when done resizing
        saveProject();
    };
    
    // Set up event listeners
    document.addEventListener('mousemove', handleResize);
    document.addEventListener('mouseup', finishResize);
}

// Show clip context menu
function showClipContextMenu(event, clip) {
    event.preventDefault();
    
    // Show properties for the clicked clip
    showClipProperties(clip);
    
    // Add selected class to highlight currently selected clip
    document.querySelectorAll('.clip').forEach(c => {
        c.classList.remove('selected');
    });
    clip.classList.add('selected');
    
    // Check if a context menu already exists and remove it
    const existingMenu = document.querySelector('.clip-context-menu');
    if (existingMenu) {
        existingMenu.remove();
    }
    
    // Create context menu
    const menu = document.createElement('div');
    menu.className = 'clip-context-menu';
    menu.style.position = 'absolute';
    menu.style.left = `${event.pageX}px`;
    menu.style.top = `${event.pageY}px`;
    menu.style.backgroundColor = '#2a2a3c';
    menu.style.border = '1px solid #353545';
    menu.style.borderRadius = '4px';
    menu.style.padding = '4px 0';
    menu.style.zIndex = '1000';
    menu.style.boxShadow = '0 2px 10px rgba(0,0,0,0.3)';
    
    // Add menu items
    menu.innerHTML = `
        <div class="menu-item" data-action="split">
            <i class="bi bi-scissors me-2"></i> Split Clip
        </div>
        <div class="menu-item" data-action="duplicate">
            <i class="bi bi-files me-2"></i> Duplicate
        </div>
        <div class="menu-item" data-action="delete">
            <i class="bi bi-trash me-2"></i> Delete
        </div>
        <div class="menu-item" data-action="properties">
            <i class="bi bi-gear me-2"></i> Properties
        </div>
    `;
    
    // Style menu items
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
        .clip-context-menu .menu-item {
            padding: 8px 12px;
            cursor: pointer;
            color: #e0e0e0;
            font-size: 14px;
            white-space: nowrap;
            display: flex;
            align-items: center;
        }
        .clip-context-menu .menu-item:hover {
            background-color: #353545;
        }
    `;
    document.head.appendChild(styleSheet);
    
    // Add event listeners to menu items
    document.body.appendChild(menu);
    
    menu.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', function() {
            const action = item.dataset.action;
            
            switch(action) {
                case 'split':
                    // Get the playhead position
                    const playhead = document.querySelector('.timeline-playhead');
                    const playheadPos = parseInt(playhead.style.left) || 0;
                    
                    // Position playhead on the clip for splitting
                    const clipLeft = parseInt(clip.style.left) || 0;
                    const clipWidth = parseInt(clip.style.width) || 0;
                    const clipCenter = clipLeft + (clipWidth / 2);
                    playhead.style.left = `${clipCenter}px`;
                    
                    // Split the clip
                    splitClipAtPlayhead();
                    break;
                    
                case 'duplicate':
                    duplicateClip(clip);
                    break;
                    
                case 'delete':
                    deleteSelectedClip();
                    break;
                    
                case 'properties':
                    // Properties already shown when clip is selected
                    break;
            }
            
            // Remove the menu
            menu.remove();
        });
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function closeMenu(e) {
        if (!menu.contains(e.target)) {
            menu.remove();
            document.removeEventListener('click', closeMenu);
        }
    });
}

// Duplicate clip
function duplicateClip(clip) {
    console.log("Duplicating clip");
    
    const trackContent = clip.parentElement;
    const clipLeft = parseInt(clip.style.left) || 0;
    const clipWidth = parseInt(clip.style.width) || 0;
    
    // Create a duplicate clip
    const newClip = document.createElement('div');
    newClip.className = clip.className.replace('selected', '').trim();
    newClip.textContent = clip.textContent;
    newClip.style.left = `${clipLeft + clipWidth + 10}px`; // Place after original
    newClip.style.width = `${clipWidth}px`;
    newClip.dataset.clipId = `${clip.dataset.clipId}-copy`;
    newClip.dataset.assetId = clip.dataset.assetId;
    
    // Add the new clip
    trackContent.appendChild(newClip);
    
    // Set up dragging for the new clip
    initClipDragging([newClip]);
    
    // Select the new clip
    showClipProperties(newClip);
    
    // Save the project
    saveProject();
}

// Initialize media drag and drop
function initMediaDragAndDrop() {
    const mediaItems = document.querySelectorAll('.media-item');
    const trackContents = document.querySelectorAll('.track-content');
    
    mediaItems.forEach(item => {
        item.setAttribute('draggable', 'true');
        
        item.addEventListener('dragstart', function(e) {
            e.dataTransfer.setData('text/plain', item.dataset.assetId || 'demo-asset');
            e.dataTransfer.effectAllowed = 'copy';
        });
    });
    
    trackContents.forEach(track => {
        track.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
            track.classList.add('drag-over');
        });
        
        track.addEventListener('dragleave', function() {
            track.classList.remove('drag-over');
        });
        
        track.addEventListener('drop', function(e) {
            e.preventDefault();
            track.classList.remove('drag-over');
            
            const assetId = e.dataTransfer.getData('text/plain');
            const trackRect = track.getBoundingClientRect();
            const dropPos = e.clientX - trackRect.left;
            
            // Add clip to timeline
            addClipToTimeline(track, assetId, dropPos);
        });
    });
}

// Add clip to timeline
function addClipToTimeline(track, assetId, position) {
    console.log(`Adding clip ${assetId} to timeline at position ${position}`);
    
    // Find asset in project data
    let asset = projectData.assets.find(a => a.id === assetId);
    
    // If asset not found, use dummy data
    if (!asset) {
        asset = {
            id: `dummy-${Math.random().toString(36).substring(2, 9)}`,
            name: "New Clip",
            type: track.id.includes('audio') ? 'audio' : 'video'
        };
    }
    
    // Create clip element
    const clip = document.createElement('div');
    clip.className = 'clip';
    
    // Add audio class if needed
    if (asset.type === 'audio') {
        clip.classList.add('audio');
    }
    
    // Add effect class if needed
    if (track.id.includes('effect')) {
        clip.classList.add('effect');
    }
    
    // Set clip properties
    clip.textContent = asset.name;
    clip.style.left = `${position}px`;
    clip.style.width = '150px';
    clip.dataset.clipId = `clip-${Math.random().toString(36).substring(2, 9)}`;
    clip.dataset.assetId = asset.id;
    
    // Add clip to track
    track.appendChild(clip);
    
    // Initialize dragging for new clip
    let isDragging = false;
    let startX, startLeft;
    
    clip.addEventListener('mousedown', function(e) {
        isDragging = true;
        startX = e.clientX;
        startLeft = parseInt(clip.style.left) || 0;
        
        // Show properties for selected clip
        showClipProperties(clip);
        
        e.preventDefault();
    });
    
    document.addEventListener('mousemove', function(e) {
        if (!isDragging) return;
        
        const dx = e.clientX - startX;
        let newLeft = startLeft + dx;
        
        // Ensure we stay within bounds
        newLeft = Math.max(0, newLeft);
        
        // Update clip position
        clip.style.left = `${newLeft}px`;
    });
    
    document.addEventListener('mouseup', function() {
        isDragging = false;
    });
}

// Show clip properties
function showClipProperties(clip) {
    // Hide no selection message
    document.getElementById('no-selection').style.display = 'none';
    
    // Show clip properties
    document.getElementById('clip-properties').style.display = 'block';
    
    // Update form fields with clip data
    document.getElementById('clip-start-time').value = parseInt(clip.style.left) / 10 || 0;
    document.getElementById('clip-duration').value = parseInt(clip.style.width) / 10 || 15;
    
    // Highlight selected clip
    document.querySelectorAll('.clip').forEach(c => {
        c.classList.remove('selected');
    });
    clip.classList.add('selected');
}

// Format time (seconds to MM:SS:FF format)
function formatTime(seconds) {
    const min = Math.floor(seconds / 60).toString().padStart(2, '0');
    const sec = Math.floor(seconds % 60).toString().padStart(2, '0');
    const frames = Math.floor((seconds * 30) % 30).toString().padStart(2, '0');
    
    return `${min}:${sec}:${frames}`;
}

// Show success notification
function showSuccess(message) {
    // For now, just alert
    console.log("SUCCESS:", message);
}

// Show error notification
function showError(message) {
    // For now, just alert
    console.error("ERROR:", message);
}

// Initialize timeline tools
function initTimelineTools() {
    console.log("Initializing timeline tools...");
    
    // Split clip button
    const splitClipBtn = document.getElementById('split-clip-btn');
    if (splitClipBtn) {
        splitClipBtn.addEventListener('click', function() {
            splitClipAtPlayhead();
        });
    }
    
    // Delete clip button
    const deleteClipBtn = document.getElementById('delete-clip-btn');
    if (deleteClipBtn) {
        deleteClipBtn.addEventListener('click', function() {
            deleteSelectedClip();
        });
    }
    
    // Add track button
    const addTrackBtn = document.getElementById('add-track-btn');
    if (addTrackBtn) {
        addTrackBtn.addEventListener('click', function() {
            addNewTrack();
        });
    }
    
    // Delete track button
    const deleteTrackBtn = document.getElementById('delete-track-btn');
    if (deleteTrackBtn) {
        deleteTrackBtn.addEventListener('click', function() {
            deleteSelectedTrack();
        });
    }
    
    // Undo button
    const undoBtn = document.getElementById('undo-btn');
    if (undoBtn) {
        undoBtn.addEventListener('click', function() {
            undoLastAction();
        });
    }
    
    // Redo button
    const redoBtn = document.getElementById('redo-btn');
    if (redoBtn) {
        redoBtn.addEventListener('click', function() {
            redoLastUndo();
        });
    }
    
    // Snap to grid button
    const snapToGridBtn = document.getElementById('snap-to-grid-btn');
    if (snapToGridBtn) {
        snapToGridBtn.addEventListener('click', function() {
            toggleSnapToGrid();
        });
    }
}

// Split clip at playhead position
function splitClipAtPlayhead() {
    console.log("Splitting clip at playhead");
    
    // Get the playhead position
    const playhead = document.querySelector('.timeline-playhead');
    const playheadPos = parseInt(playhead.style.left) || 0;
    
    // Get the selected clip (if any)
    const selectedClip = document.querySelector('.clip.selected');
    if (!selectedClip) {
        showError("Please select a clip to split");
        return;
    }
    
    // Check if playhead is over the selected clip
    const clipLeft = parseInt(selectedClip.style.left) || 0;
    const clipWidth = parseInt(selectedClip.style.width) || 0;
    const clipRight = clipLeft + clipWidth;
    
    if (playheadPos < clipLeft || playheadPos > clipRight) {
        showError("Playhead must be positioned over the selected clip");
        return;
    }
    
    // Calculate split point
    const splitPoint = playheadPos - clipLeft;
    
    // Create two new clips from the original
    const trackContent = selectedClip.parentElement;
    const clipId = selectedClip.dataset.clipId;
    const assetId = selectedClip.dataset.assetId;
    
    // Create first part of split
    const firstClip = document.createElement('div');
    firstClip.className = selectedClip.className.replace('selected', '').trim();
    firstClip.textContent = selectedClip.textContent;
    firstClip.style.left = `${clipLeft}px`;
    firstClip.style.width = `${splitPoint}px`;
    firstClip.dataset.clipId = `${clipId}-part1`;
    firstClip.dataset.assetId = assetId;
    
    // Create second part of split
    const secondClip = document.createElement('div');
    secondClip.className = selectedClip.className.replace('selected', '').trim();
    secondClip.textContent = selectedClip.textContent;
    secondClip.style.left = `${playheadPos}px`;
    secondClip.style.width = `${clipRight - playheadPos}px`;
    secondClip.dataset.clipId = `${clipId}-part2`;
    secondClip.dataset.assetId = assetId;
    
    // Remove the original clip
    selectedClip.remove();
    
    // Add the new clips
    trackContent.appendChild(firstClip);
    trackContent.appendChild(secondClip);
    
    // Set up dragging for the new clips
    initClipDragging([firstClip, secondClip]);
    
    // Select the second part
    showClipProperties(secondClip);
    
    // Save the project
    saveProject();
}

// Delete selected clip
function deleteSelectedClip() {
    console.log("Deleting selected clip");
    
    const selectedClip = document.querySelector('.clip.selected');
    if (!selectedClip) {
        showError("Please select a clip to delete");
        return;
    }
    
    // Remove the clip
    selectedClip.remove();
    
    // Show "no selection" message
    document.getElementById('no-selection').style.display = 'block';
    document.getElementById('clip-properties').style.display = 'none';
    
    // Save the project
    saveProject();
}

// Add new track
function addNewTrack() {
    console.log("Adding new track");
    
    const tracksContainer = document.querySelector('.timeline-tracks');
    const tracks = tracksContainer.querySelectorAll('.track');
    const trackCount = tracks.length;
    
    // Determine track type (video, audio, effects)
    let trackType = 'Video';
    let trackId = 'video';
    
    // Count existing tracks by type
    const videoTracks = Array.from(tracks).filter(t => t.querySelector('.track-label').textContent.includes('Video')).length;
    const audioTracks = Array.from(tracks).filter(t => t.querySelector('.track-label').textContent.includes('Audio')).length;
    
    if (videoTracks <= audioTracks) {
        trackType = 'Video';
        trackId = 'video';
    } else {
        trackType = 'Audio';
        trackId = 'audio';
    }
    
    // Create new track
    const newTrack = document.createElement('div');
    newTrack.className = 'track';
    newTrack.innerHTML = `
        <div class="track-label">${trackType} ${videoTracks + 1}</div>
        <div class="track-content" id="${trackId}-track-${videoTracks + 1}">
            <!-- Empty track -->
        </div>
    `;
    
    // Add the track
    tracksContainer.appendChild(newTrack);
    
    // Set up drop handlers
    const trackContent = newTrack.querySelector('.track-content');
    initTrackDropHandlers(trackContent);
    
    // Save the project
    saveProject();
}

// Initialize track drop handlers
function initTrackDropHandlers(track) {
    track.addEventListener('dragover', function(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
        track.classList.add('drag-over');
    });
    
    track.addEventListener('dragleave', function() {
        track.classList.remove('drag-over');
    });
    
    track.addEventListener('drop', function(e) {
        e.preventDefault();
        track.classList.remove('drag-over');
        
        const assetId = e.dataTransfer.getData('text/plain');
        const trackRect = track.getBoundingClientRect();
        const dropPos = e.clientX - trackRect.left;
        
        // Add clip to timeline
        addClipToTimeline(track, assetId, dropPos);
    });
}

// Delete selected track
function deleteSelectedTrack() {
    console.log("Deleting selected track");
    
    // Check if a clip is selected to identify the track
    const selectedClip = document.querySelector('.clip.selected');
    if (!selectedClip) {
        showError("Please select a clip on the track you want to delete");
        return;
    }
    
    // Get the track containing the selected clip
    const trackContent = selectedClip.closest('.track-content');
    const track = trackContent.closest('.track');
    
    // Confirm deletion
    if (confirm("Are you sure you want to delete this track and all its clips?")) {
        // Remove the track
        track.remove();
        
        // Show "no selection" message
        document.getElementById('no-selection').style.display = 'block';
        document.getElementById('clip-properties').style.display = 'none';
        
        // Save the project
        saveProject();
    }
}

// Undo last action
function undoLastAction() {
    console.log("Undo last action");
    showError("Undo functionality will be implemented soon");
}

// Redo last undone action
function redoLastUndo() {
    console.log("Redo last undone action");
    showError("Redo functionality will be implemented soon");
}

// Toggle snap to grid
function toggleSnapToGrid() {
    console.log("Toggle snap to grid");
    
    const snapToGridBtn = document.getElementById('snap-to-grid-btn');
    const isActive = snapToGridBtn.classList.contains('active');
    
    if (isActive) {
        snapToGridBtn.classList.remove('active');
        projectData.timeline.snapToGrid = false;
    } else {
        snapToGridBtn.classList.add('active');
        projectData.timeline.snapToGrid = true;
    }
    
    showSuccess(`Snap to grid ${projectData.timeline.snapToGrid ? 'enabled' : 'disabled'}`);
}
import sqlite3
import json
import os
import logging
from datetime import datetime
from postgres_db import PostgresDatabase

class Database:
    def __init__(self, db_path='data/database.sqlite', use_postgres=False, 
                 host='localhost', port=5432, database='flux58',
                 user='postgres', password='postgres'):
        """Initialize database with either SQLite or PostgreSQL backend"""
        self.use_postgres = use_postgres
        
        if use_postgres:
            # Use PostgreSQL as the database backend
            self.pg_db = PostgresDatabase(
                host=host,
                port=port,
                database=database,
                user=user,
                password=password
            )
            self.db_path = None  # Not applicable for PostgreSQL
        else:
            # Use SQLite as the database backend (default)
            # Ensure directory exists
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            self.db_path = db_path
            self.pg_db = None
        
        self.connection = None
        self.cursor = None
        
        # Initialize database
        self._initialize_db()
    
    def _connect(self):
        """Connect to database"""
        if self.use_postgres:
            # For PostgreSQL, we'll use the connection methods from PostgresDatabase
            # This is a no-op since connection is managed in PostgresDatabase
            pass
        else:
            # SQLite connection
            self.connection = sqlite3.connect(self.db_path)
            # Enable foreign key constraints
            self.connection.execute('PRAGMA foreign_keys = ON')
            # Return dictionaries instead of tuples
            self.connection.row_factory = sqlite3.Row
            self.cursor = self.connection.cursor()
        
    def _disconnect(self):
        """Disconnect from database"""
        if self.use_postgres:
            # For PostgreSQL, we'll use the connection methods from PostgresDatabase
            # This is a no-op since connection is managed in PostgresDatabase
            pass
        elif self.connection:
            # SQLite disconnect
            self.connection.close()
            self.connection = None
            self.cursor = None
    
    def _initialize_db(self):
        """Initialize database tables if they don't exist"""
        if self.use_postgres:
            # For PostgreSQL, initialization is handled by the PostgresDatabase class
            pass
        else:
            # SQLite initialization
            self._connect()
            
            # Create users table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                email TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL,
                role TEXT NOT NULL
            )
            ''')
            
            # Create sessions table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                username TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                ip_address TEXT,
                user_agent TEXT,
                last_activity TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            ''')
            
            # Add index on expires_at for faster session cleanup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at)
            ''')
            
            # Add index on user_id for faster session lookup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id)
            ''')
            
            # Create credits table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS credits (
                user_id TEXT PRIMARY KEY,
                total INTEGER NOT NULL,
                used INTEGER NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            ''')
            
            # Create credit transactions table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS credit_transactions (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                amount INTEGER NOT NULL,
                timestamp TIMESTAMP NOT NULL,
                type TEXT NOT NULL,
                description TEXT,
                status TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            ''')
            
            # Add index on user_id and timestamp for faster transaction lookup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_transactions_user_timestamp 
            ON credit_transactions(user_id, timestamp DESC)
            ''')
            
            # Create projects table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                user_id TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL,
                updated_at TIMESTAMP NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            ''')
            
            # Add index on user_id and updated_at for faster project listing
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_projects_user_updated 
            ON projects(user_id, updated_at DESC)
            ''')
            
            # Create project_assets table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS project_assets (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                name TEXT NOT NULL,
                filename TEXT NOT NULL,
                path TEXT NOT NULL,
                type TEXT NOT NULL,
                added_at TIMESTAMP NOT NULL,
                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
            )
            ''')
            
            # Add index on project_id for faster asset lookup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_assets_project_id 
            ON project_assets(project_id)
            ''')
            
            # Add index on type for faster filtering by asset type
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_assets_type 
            ON project_assets(type)
            ''')
            
            # Create project_timeline table for timeline metadata
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS project_timeline (
                project_id TEXT PRIMARY KEY,
                duration REAL NOT NULL,
                width INTEGER NOT NULL,
                height INTEGER NOT NULL,
                fps_num INTEGER NOT NULL,
                fps_den INTEGER NOT NULL,
                sample_rate INTEGER NOT NULL,
                channels INTEGER NOT NULL,
                channel_layout INTEGER NOT NULL,
                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
            )
            ''')
            
            # Create timeline_tracks table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS timeline_tracks (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                name TEXT NOT NULL,
                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
            )
            ''')
            
            # Add index on project_id for faster track lookup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_tracks_project_id 
            ON timeline_tracks(project_id)
            ''')
            
            # Create timeline_clips table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS timeline_clips (
                id TEXT PRIMARY KEY,
                track_id TEXT NOT NULL,
                asset_id TEXT NOT NULL,
                position REAL NOT NULL,
                duration REAL NOT NULL,
                start REAL NOT NULL,
                end REAL NOT NULL,
                properties TEXT NOT NULL,
                FOREIGN KEY (track_id) REFERENCES timeline_tracks(id) ON DELETE CASCADE,
                FOREIGN KEY (asset_id) REFERENCES project_assets(id)
            )
            ''')
            
            # Add index on track_id for faster clip lookup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_clips_track_id 
            ON timeline_clips(track_id)
            ''')
            
            # Add index on asset_id for faster clip-asset lookup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_clips_asset_id 
            ON timeline_clips(asset_id)
            ''')
            
            # Create export_jobs table
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS export_jobs (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                output_path TEXT NOT NULL,
                format TEXT NOT NULL,
                width INTEGER NOT NULL,
                height INTEGER NOT NULL,
                fps INTEGER NOT NULL,
                video_bitrate TEXT NOT NULL,
                audio_bitrate TEXT NOT NULL,
                start_frame INTEGER NOT NULL,
                end_frame INTEGER,
                started_at TIMESTAMP NOT NULL,
                completed_at TIMESTAMP,
                status TEXT NOT NULL,
                priority INTEGER DEFAULT 0,
                progress REAL DEFAULT 0,
                error TEXT,
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            ''')
            
            # Add index on user_id and started_at for faster export history lookup
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_exports_user_started 
            ON export_jobs(user_id, started_at DESC)
            ''')
            
            # Add index on status for faster queue processing
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_exports_status 
            ON export_jobs(status)
            ''')
            
            # Add index on priority for export queue processing
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_exports_priority 
            ON export_jobs(priority DESC)
            ''')
            
            # Create a table for system settings
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TIMESTAMP NOT NULL
            )
            ''')
            
            # Create a table for logging
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP NOT NULL,
                level TEXT NOT NULL,
                module TEXT NOT NULL,
                message TEXT NOT NULL,
                user_id TEXT,
                ip_address TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            ''')
            
            # Add index on timestamp for faster log queries
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_logs_timestamp 
            ON system_logs(timestamp DESC)
            ''')
            
            # Add index on level for filtering logs by severity
            self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_logs_level 
            ON system_logs(level)
            ''')
            
            self.connection.commit()
            self._disconnect()
    
    # User Management Methods
    def create_user(self, user_id, username, password_hash, email, role="user"):
        """Create a new user"""
        if self.use_postgres:
            return self.pg_db.create_user(user_id, username, password_hash, email, role)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            self.cursor.execute(
                "INSERT INTO users (id, username, password_hash, email, created_at, role) VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, username, password_hash, email, now, role)
            )
            
            # Initialize credits
            self.cursor.execute(
                "INSERT INTO credits (user_id, total, used) VALUES (?, ?, ?)",
                (user_id, 0, 0)
            )
            
            self.connection.commit()
            return True
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def get_user_by_username(self, username):
        """Get user by username"""
        if self.use_postgres:
            return self.pg_db.get_user_by_username(username)
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
            row = self.cursor.fetchone()
            
            if row:
                return dict(row)
            return None
        finally:
            self._disconnect()
    
    def get_user_by_id(self, user_id):
        """Get user by ID"""
        if self.use_postgres:
            return self.pg_db.get_user_by_id(user_id)
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            row = self.cursor.fetchone()
            
            if row:
                return dict(row)
            return None
        finally:
            self._disconnect()
    
    def update_user(self, user_id, email=None, password_hash=None, role=None):
        """Update user details"""
        if self.use_postgres:
            return self.pg_db.update_user(user_id, email, password_hash, role)
        
        self._connect()
        
        try:
            update_parts = []
            params = []
            
            if email:
                update_parts.append("email = ?")
                params.append(email)
            
            if password_hash:
                update_parts.append("password_hash = ?")
                params.append(password_hash)
            
            if role:
                update_parts.append("role = ?")
                params.append(role)
            
            if not update_parts:
                return False
            
            # Add user_id to params
            params.append(user_id)
            
            # Execute update
            self.cursor.execute(
                f"UPDATE users SET {', '.join(update_parts)} WHERE id = ?",
                params
            )
            
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def delete_user(self, user_id):
        """Delete user"""
        if self.use_postgres:
            return self.pg_db.delete_user(user_id)
        
        self._connect()
        
        try:
            self.cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def list_all_users(self):
        """List all users"""
        if self.use_postgres:
            return self.pg_db.list_all_users()
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM users")
            rows = self.cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            self._disconnect()
    
    # Session Management Methods
    def create_session(self, token, user_id, username, expires_at):
        """Create a new session"""
        if self.use_postgres:
            return self.pg_db.create_session(token, user_id, username, expires_at)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            self.cursor.execute(
                "INSERT INTO sessions (token, user_id, username, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
                (token, user_id, username, now, expires_at)
            )
            
            self.connection.commit()
            return True
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def get_session(self, token):
        """Get session by token"""
        if self.use_postgres:
            return self.pg_db.get_session(token)
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM sessions WHERE token = ?", (token,))
            row = self.cursor.fetchone()
            
            if row:
                return dict(row)
            return None
        finally:
            self._disconnect()
    
    def delete_session(self, token):
        """Delete session"""
        if self.use_postgres:
            return self.pg_db.delete_session(token)
        
        self._connect()
        
        try:
            self.cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def cleanup_expired_sessions(self):
        """Delete expired sessions"""
        if self.use_postgres:
            return self.pg_db.cleanup_expired_sessions()
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            self.cursor.execute("DELETE FROM sessions WHERE expires_at < ?", (now,))
            self.connection.commit()
            return self.cursor.rowcount
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return 0
        finally:
            self._disconnect()
    
    # Credit Management Methods
    def get_user_credits(self, user_id):
        """Get user's credit information"""
        if self.use_postgres:
            return self.pg_db.get_user_credits(user_id)
        
        self._connect()
        
        try:
            # Get credit balance
            self.cursor.execute("SELECT * FROM credits WHERE user_id = ?", (user_id,))
            row = self.cursor.fetchone()
            
            if not row:
                return None
            
            credit_data = dict(row)
            
            # Get recent transactions
            self.cursor.execute(
                "SELECT * FROM credit_transactions WHERE user_id = ? ORDER BY timestamp DESC LIMIT 20",
                (user_id,)
            )
            
            transactions = [dict(row) for row in self.cursor.fetchall()]
            credit_data['transactions'] = transactions
            
            return credit_data
        finally:
            self._disconnect()
    
    def add_credits(self, user_id, amount, transaction_type, description="", status="completed"):
        """Add credits to user account"""
        if amount <= 0:
            return False
        
        if self.use_postgres:
            return self.pg_db.add_credits(user_id, amount, transaction_type, description, status)
        
        self._connect()
        
        try:
            # Start transaction
            self.connection.execute("BEGIN TRANSACTION")
            
            # Update credit balance
            self.cursor.execute(
                "UPDATE credits SET total = total + ? WHERE user_id = ?",
                (amount, user_id)
            )
            
            if self.cursor.rowcount == 0:
                # Insert new record if doesn't exist
                self.cursor.execute(
                    "INSERT INTO credits (user_id, total, used) VALUES (?, ?, ?)",
                    (user_id, amount, 0)
                )
            
            # Add transaction record
            transaction_id = str(os.urandom(16).hex())
            now = datetime.now().isoformat()
            
            self.cursor.execute(
                """INSERT INTO credit_transactions 
                   (id, user_id, amount, timestamp, type, description, status) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (transaction_id, user_id, amount, now, transaction_type, description, status)
            )
            
            # Commit transaction
            self.connection.commit()
            return transaction_id
        except sqlite3.Error as e:
            self.connection.rollback()
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def use_credits(self, user_id, amount, description="", transaction_type="usage", status="completed"):
        """Use credits from user account"""
        if amount <= 0:
            return False
        
        if self.use_postgres:
            return self.pg_db.use_credits(user_id, amount, description, transaction_type, status)
        
        self._connect()
        
        try:
            # Start transaction
            self.connection.execute("BEGIN TRANSACTION")
            
            # Check current balance
            self.cursor.execute("SELECT total, used FROM credits WHERE user_id = ?", (user_id,))
            row = self.cursor.fetchone()
            
            if not row:
                self.connection.rollback()
                return False
            
            available = row['total'] - row['used']
            
            if available < amount:
                self.connection.rollback()
                return False
            
            # Update used credits
            self.cursor.execute(
                "UPDATE credits SET used = used + ? WHERE user_id = ?",
                (amount, user_id)
            )
            
            # Add transaction record (negative amount for usage)
            transaction_id = str(os.urandom(16).hex())
            now = datetime.now().isoformat()
            
            self.cursor.execute(
                """INSERT INTO credit_transactions 
                   (id, user_id, amount, timestamp, type, description, status) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (transaction_id, user_id, -amount, now, transaction_type, description, status)
            )
            
            # Commit transaction
            self.connection.commit()
            return transaction_id
        except sqlite3.Error as e:
            self.connection.rollback()
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    # Project Management Methods
    def create_project(self, project_id, user_id, name, description=""):
        """Create a new project"""
        if self.use_postgres:
            return self.pg_db.create_project(project_id, user_id, name, description)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            
            # Add project
            self.cursor.execute(
                """INSERT INTO projects 
                   (id, name, description, user_id, created_at, updated_at) 
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (project_id, name, description, user_id, now, now)
            )
            
            # Add timeline defaults
            self.cursor.execute(
                """INSERT INTO project_timeline 
                   (project_id, duration, width, height, fps_num, fps_den, 
                    sample_rate, channels, channel_layout) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (project_id, 60.0, 1920, 1080, 30, 1, 48000, 2, 3)
            )
            
            self.connection.commit()
            
            # Return full project data
            return self.get_project(project_id)
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            self._disconnect()
    
    def get_project(self, project_id):
        """Get project by ID including all related data"""
        if self.use_postgres:
            return self.pg_db.get_project(project_id)
        
        self._connect()
        
        try:
            # Get project
            self.cursor.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
            project_row = self.cursor.fetchone()
            
            if not project_row:
                return None
            
            project = dict(project_row)
            
            # Get timeline
            self.cursor.execute("SELECT * FROM project_timeline WHERE project_id = ?", (project_id,))
            timeline_row = self.cursor.fetchone()
            
            timeline = {
                "duration": timeline_row['duration'],
                "width": timeline_row['width'],
                "height": timeline_row['height'],
                "fps": {
                    "num": timeline_row['fps_num'],
                    "den": timeline_row['fps_den']
                },
                "sample_rate": timeline_row['sample_rate'],
                "channels": timeline_row['channels'],
                "channel_layout": timeline_row['channel_layout'],
                "tracks": []
            }
            
            # Get tracks
            self.cursor.execute("SELECT * FROM timeline_tracks WHERE project_id = ?", (project_id,))
            track_rows = self.cursor.fetchall()
            
            tracks = []
            for track_row in track_rows:
                track = dict(track_row)
                
                # Get clips for this track
                self.cursor.execute("SELECT * FROM timeline_clips WHERE track_id = ?", (track['id'],))
                clip_rows = self.cursor.fetchall()
                
                clips = []
                for clip_row in clip_rows:
                    clip = dict(clip_row)
                    clip['properties'] = json.loads(clip['properties'])
                    clips.append(clip)
                
                track['clips'] = clips
                tracks.append(track)
            
            timeline['tracks'] = tracks
            
            # Get assets
            self.cursor.execute("SELECT * FROM project_assets WHERE project_id = ?", (project_id,))
            asset_rows = self.cursor.fetchall()
            
            assets = [dict(row) for row in asset_rows]
            
            # Compose final project object
            project['timeline'] = timeline
            project['assets'] = assets
            
            return project
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            self._disconnect()
    
    def update_project(self, project_id, name=None, description=None):
        """Update project metadata"""
        if self.use_postgres:
            return self.pg_db.update_project(project_id, name, description)
        
        self._connect()
        
        try:
            update_parts = []
            params = []
            
            if name:
                update_parts.append("name = ?")
                params.append(name)
            
            if description is not None:  # Allow empty description
                update_parts.append("description = ?")
                params.append(description)
            
            if not update_parts:
                return False
            
            # Always update timestamp
            update_parts.append("updated_at = ?")
            params.append(datetime.now().isoformat())
            
            # Add project_id to params
            params.append(project_id)
            
            # Execute update
            self.cursor.execute(
                f"UPDATE projects SET {', '.join(update_parts)} WHERE id = ?",
                params
            )
            
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def delete_project(self, project_id):
        """Delete project and all related data"""
        if self.use_postgres:
            return self.pg_db.delete_project(project_id)
        
        self._connect()
        
        try:
            self.cursor.execute("DELETE FROM projects WHERE id = ?", (project_id,))
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def list_user_projects(self, user_id):
        """List projects for a user"""
        if self.use_postgres:
            return self.pg_db.list_user_projects(user_id)
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC", (user_id,))
            rows = self.cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            self._disconnect()
    
    # Asset Management Methods
    def add_asset(self, asset_id, project_id, name, filename, path, asset_type):
        """Add an asset to a project"""
        if self.use_postgres:
            return self.pg_db.add_asset(asset_id, project_id, name, filename, path, asset_type)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            
            self.cursor.execute(
                """INSERT INTO project_assets
                   (id, project_id, name, filename, path, type, added_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (asset_id, project_id, name, filename, path, asset_type, now)
            )
            
            self.connection.commit()
            
            self.cursor.execute("SELECT * FROM project_assets WHERE id = ?", (asset_id,))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            self._disconnect()
    
    def get_asset(self, asset_id):
        """Get asset by ID"""
        if self.use_postgres:
            return self.pg_db.get_asset(asset_id)
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM project_assets WHERE id = ?", (asset_id,))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        finally:
            self._disconnect()
    
    # Timeline Management Methods
    def add_track(self, track_id, project_id, name):
        """Add a track to a project timeline"""
        if self.use_postgres:
            return self.pg_db.add_track(track_id, project_id, name)
        
        self._connect()
        
        try:
            self.cursor.execute(
                "INSERT INTO timeline_tracks (id, project_id, name) VALUES (?, ?, ?)",
                (track_id, project_id, name)
            )
            
            self.connection.commit()
            
            self.cursor.execute("SELECT * FROM timeline_tracks WHERE id = ?", (track_id,))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            self._disconnect()
    
    def add_clip(self, clip_id, track_id, asset_id, position, duration, start=0, end=None, properties=None):
        """Add a clip to a timeline track"""
        if self.use_postgres:
            return self.pg_db.add_clip(clip_id, track_id, asset_id, position, duration, start, end, properties)
        
        self._connect()
        
        try:
            if end is None:
                end = duration
                
            if properties is None:
                properties = {
                    "volume": 1.0,
                    "position_x": 0,
                    "position_y": 0,
                    "scale_x": 1.0,
                    "scale_y": 1.0,
                    "rotation": 0,
                    "alpha": 1.0
                }
            
            properties_json = json.dumps(properties)
            
            self.cursor.execute(
                """INSERT INTO timeline_clips
                   (id, track_id, asset_id, position, duration, start, end, properties)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (clip_id, track_id, asset_id, position, duration, start, end, properties_json)
            )
            
            self.connection.commit()
            
            self.cursor.execute("SELECT * FROM timeline_clips WHERE id = ?", (clip_id,))
            row = self.cursor.fetchone()
            
            if row:
                clip = dict(row)
                clip['properties'] = json.loads(clip['properties'])
                return clip
            return None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            self._disconnect()
    
    # Export Management Methods
    def create_export_job(self, export_id, project_id, user_id, output_path, 
                          format="mp4", width=1920, height=1080, fps=30,
                          video_bitrate="8000k", audio_bitrate="192k",
                          start_frame=1, end_frame=None):
        """Create a new export job"""
        if self.use_postgres:
            return self.pg_db.create_export_job(
                export_id, project_id, user_id, output_path, format, 
                width, height, fps, video_bitrate, audio_bitrate,
                start_frame, end_frame
            )
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            
            self.cursor.execute(
                """INSERT INTO export_jobs
                   (id, project_id, user_id, output_path, format, width, height,
                    fps, video_bitrate, audio_bitrate, start_frame, end_frame,
                    started_at, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (export_id, project_id, user_id, output_path, format, width, height,
                 fps, video_bitrate, audio_bitrate, start_frame, end_frame,
                 now, "pending")
            )
            
            self.connection.commit()
            
            self.cursor.execute("SELECT * FROM export_jobs WHERE id = ?", (export_id,))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            self._disconnect()
    
    def update_export_status(self, export_id, status, completed_at=None):
        """Update export job status"""
        if self.use_postgres:
            return self.pg_db.update_export_status(export_id, status, completed_at)
        
        self._connect()
        
        try:
            if completed_at:
                self.cursor.execute(
                    "UPDATE export_jobs SET status = ?, completed_at = ? WHERE id = ?",
                    (status, completed_at, export_id)
                )
            else:
                self.cursor.execute(
                    "UPDATE export_jobs SET status = ? WHERE id = ?",
                    (status, export_id)
                )
            
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def get_export_job(self, export_id):
        """Get export job by ID"""
        if self.use_postgres:
            return self.pg_db.get_export_job(export_id)
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM export_jobs WHERE id = ?", (export_id,))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        finally:
            self._disconnect()
    
    def list_user_exports(self, user_id):
        """List export jobs for a user"""
        if self.use_postgres:
            return self.pg_db.list_user_exports(user_id)
        
        self._connect()
        
        try:
            self.cursor.execute(
                "SELECT * FROM export_jobs WHERE user_id = ? ORDER BY started_at DESC",
                (user_id,)
            )
            rows = self.cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            self._disconnect()
    
    #-----------------
    # Session Management Extensions
    #-----------------
    
    def create_session_extended(self, token, user_id, username, expires_at, ip_address=None, user_agent=None):
        """Create a new session with extended information"""
        if self.use_postgres:
            return self.pg_db.create_session_extended(token, user_id, username, expires_at, ip_address, user_agent)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            self.cursor.execute(
                """INSERT INTO sessions 
                   (token, user_id, username, created_at, expires_at, ip_address, user_agent, last_activity) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (token, user_id, username, now, expires_at, ip_address, user_agent, now)
            )
            
            self.connection.commit()
            return True
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def update_session_activity(self, token, ip_address=None):
        """Update session last activity time"""
        if self.use_postgres:
            return self.pg_db.update_session_activity(token, ip_address)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            
            if ip_address:
                self.cursor.execute(
                    "UPDATE sessions SET last_activity = ?, ip_address = ? WHERE token = ?",
                    (now, ip_address, token)
                )
            else:
                self.cursor.execute(
                    "UPDATE sessions SET last_activity = ? WHERE token = ?",
                    (now, token)
                )
            
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def get_user_sessions(self, user_id):
        """Get all active sessions for a user"""
        if self.use_postgres:
            return self.pg_db.get_user_sessions(user_id)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            self.cursor.execute(
                "SELECT * FROM sessions WHERE user_id = ? AND expires_at > ? ORDER BY last_activity DESC",
                (user_id, now)
            )
            
            rows = self.cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            self._disconnect()
    
    def invalidate_all_user_sessions(self, user_id, except_token=None):
        """Invalidate all sessions for a user except the current one"""
        if self.use_postgres:
            return self.pg_db.invalidate_all_user_sessions(user_id, except_token)
        
        self._connect()
        
        try:
            if except_token:
                self.cursor.execute(
                    "DELETE FROM sessions WHERE user_id = ? AND token != ?",
                    (user_id, except_token)
                )
            else:
                self.cursor.execute(
                    "DELETE FROM sessions WHERE user_id = ?",
                    (user_id,)
                )
            
            self.connection.commit()
            return self.cursor.rowcount
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return 0
        finally:
            self._disconnect()
    
    #-----------------
    # Export Queue System
    #-----------------
    
    def create_export_job_with_priority(self, export_id, project_id, user_id, output_path, 
                                       format="mp4", width=1920, height=1080, fps=30,
                                       video_bitrate="8000k", audio_bitrate="192k",
                                       start_frame=1, end_frame=None, priority=0):
        """Create a new export job with priority"""
        if self.use_postgres:
            return self.pg_db.create_export_job_with_priority(
                export_id, project_id, user_id, output_path, format, 
                width, height, fps, video_bitrate, audio_bitrate,
                start_frame, end_frame, priority
            )
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            
            self.cursor.execute(
                """INSERT INTO export_jobs
                   (id, project_id, user_id, output_path, format, width, height,
                    fps, video_bitrate, audio_bitrate, start_frame, end_frame,
                    started_at, status, priority, progress)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (export_id, project_id, user_id, output_path, format, width, height,
                 fps, video_bitrate, audio_bitrate, start_frame, end_frame,
                 now, "pending", priority, 0.0)
            )
            
            self.connection.commit()
            
            self.cursor.execute("SELECT * FROM export_jobs WHERE id = ?", (export_id,))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            self._disconnect()
    
    def update_export_progress(self, export_id, progress, status=None):
        """Update export job progress"""
        if self.use_postgres:
            return self.pg_db.update_export_progress(export_id, progress, status)
        
        self._connect()
        
        try:
            if status:
                self.cursor.execute(
                    "UPDATE export_jobs SET progress = ?, status = ? WHERE id = ?",
                    (progress, status, export_id)
                )
            else:
                self.cursor.execute(
                    "UPDATE export_jobs SET progress = ? WHERE id = ?",
                    (progress, export_id)
                )
            
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def get_next_pending_export(self):
        """Get the next pending export job with highest priority"""
        if self.use_postgres:
            return self.pg_db.get_next_pending_export()
        
        self._connect()
        
        try:
            self.cursor.execute(
                """SELECT * FROM export_jobs 
                   WHERE status = 'pending' 
                   ORDER BY priority DESC, started_at ASC 
                   LIMIT 1"""
            )
            
            row = self.cursor.fetchone()
            return dict(row) if row else None
        finally:
            self._disconnect()
    
    def cancel_export_job(self, export_id):
        """Cancel an export job"""
        if self.use_postgres:
            return self.pg_db.cancel_export_job(export_id)
        
        self._connect()
        
        try:
            self.cursor.execute(
                "UPDATE export_jobs SET status = 'cancelled' WHERE id = ? AND status IN ('pending', 'processing')",
                (export_id,)
            )
            
            self.connection.commit()
            return self.cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def get_active_exports(self):
        """Get all currently processing export jobs"""
        if self.use_postgres:
            return self.pg_db.get_active_exports()
        
        self._connect()
        
        try:
            self.cursor.execute(
                "SELECT * FROM export_jobs WHERE status = 'processing'"
            )
            
            rows = self.cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            self._disconnect()
    
    #-----------------
    # Logging System
    #-----------------
    
    def add_log(self, level, module, message, user_id=None, ip_address=None):
        """Add a log entry to the system log"""
        if self.use_postgres:
            return self.pg_db.add_log(level, module, message, user_id, ip_address)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            
            self.cursor.execute(
                """INSERT INTO system_logs 
                   (timestamp, level, module, message, user_id, ip_address) 
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (now, level, module, message, user_id, ip_address)
            )
            
            self.connection.commit()
            return self.cursor.lastrowid
        except sqlite3.Error as e:
            print(f"Error logging to database: {e}")
            return None
        finally:
            self._disconnect()
    
    def get_logs(self, limit=100, offset=0, level=None, module=None, user_id=None):
        """Get system logs with filtering options"""
        if self.use_postgres:
            return self.pg_db.get_logs(limit, offset, level, module, user_id)
        
        self._connect()
        
        try:
            query = "SELECT * FROM system_logs WHERE 1=1"
            params = []
            
            # Add filters
            if level:
                query += " AND level = ?"
                params.append(level)
            
            if module:
                query += " AND module = ?"
                params.append(module)
            
            if user_id:
                query += " AND user_id = ?"
                params.append(user_id)
            
            # Add ordering and limits
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            self.cursor.execute(query, params)
            rows = self.cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            self._disconnect()
    
    def clear_old_logs(self, days=30):
        """Clear logs older than specified days"""
        if self.use_postgres:
            return self.pg_db.clear_old_logs(days)
        
        self._connect()
        
        try:
            # Calculate cutoff date
            cutoff_date = (datetime.now() - timedelta(days=days)).isoformat()
            
            self.cursor.execute(
                "DELETE FROM system_logs WHERE timestamp < ?",
                (cutoff_date,)
            )
            
            self.connection.commit()
            return self.cursor.rowcount
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return 0
        finally:
            self._disconnect()
    
    #-----------------
    # System Settings
    #-----------------
    
    def set_system_setting(self, key, value):
        """Set or update a system setting"""
        if self.use_postgres:
            return self.pg_db.set_system_setting(key, value)
        
        self._connect()
        
        try:
            now = datetime.now().isoformat()
            
            # Try to update first
            self.cursor.execute(
                "UPDATE system_settings SET value = ?, updated_at = ? WHERE key = ?",
                (value, now, key)
            )
            
            # If no rows affected, insert new setting
            if self.cursor.rowcount == 0:
                self.cursor.execute(
                    "INSERT INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)",
                    (key, value, now)
                )
            
            self.connection.commit()
            return True
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return False
        finally:
            self._disconnect()
    
    def get_system_setting(self, key, default=None):
        """Get a system setting value"""
        if self.use_postgres:
            return self.pg_db.get_system_setting(key, default)
        
        self._connect()
        
        try:
            self.cursor.execute(
                "SELECT value FROM system_settings WHERE key = ?",
                (key,)
            )
            
            row = self.cursor.fetchone()
            return row['value'] if row else default
        finally:
            self._disconnect()
    
    def get_all_system_settings(self):
        """Get all system settings"""
        if self.use_postgres:
            return self.pg_db.get_all_system_settings()
        
        self._connect()
        
        try:
            self.cursor.execute("SELECT * FROM system_settings")
            rows = self.cursor.fetchall()
            
            # Convert to dictionary with key as index
            settings = {}
            for row in rows:
                settings[row['key']] = {
                    'value': row['value'],
                    'updated_at': row['updated_at']
                }
            
            return settings
        finally:
            self._disconnect()
            
    def backup_database(self, backup_path):
        """Create a backup of the database"""
        if self.use_postgres:
            # For PostgreSQL, backups are handled differently
            # We'll use pg_dump via the PostgresDatabase class
            backup_result = self.pg_db.backup_database()
            
            # If backup was successful and we want to store it at a specific path,
            # we could copy the file from the default location
            if backup_result.get('success') and 'file' in backup_result:
                import shutil
                shutil.copy2(backup_result['file'], backup_path)
            
            return backup_result.get('success', False)
        
        self._connect()
        
        try:
            # Create a backup using SQLite's backup API
            backup_conn = sqlite3.connect(backup_path)
            self.connection.backup(backup_conn)
            backup_conn.close()
            return True
        except sqlite3.Error as e:
            print(f"Backup error: {e}")
            return False
        finally:
            self._disconnect()
# Using PostgreSQL with OpenShot Web App

This document explains how to configure the OpenShot Web App to use PostgreSQL instead of SQLite.

## Prerequisites

1. PostgreSQL (version 12 or newer) installed on your system
2. Python package `psycopg2-binary` installed:
   ```
   pip install psycopg2-binary
   ```

## Configuration

The application now uses PostgreSQL as the primary database backend with SQLite available as a fallback. To configure PostgreSQL, set the following environment variables:

```bash
# Database type (set to 'postgres' to use PostgreSQL)
export DB_TYPE=postgres

# PostgreSQL connection parameters
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=flux58
export DB_USER=postgres
export DB_PASS=postgres
```

## Creating the PostgreSQL Database

Before running the application with PostgreSQL, you need to create the database:

```bash
# Connect to PostgreSQL
sudo -u postgres psql

# Create the database
CREATE DATABASE flux58;

# Create a user (if needed) and grant permissions
CREATE USER flux58_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE flux58 TO flux58_user;

# Exit PostgreSQL
\q
```

If you use a non-default user, update the `DB_USER` and `DB_PASS` environment variables accordingly.

## Running the Application with PostgreSQL

Start the application with PostgreSQL:

```bash
# Set environment variables
export DB_TYPE=postgres
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=flux58
export DB_USER=postgres
export DB_PASS=postgres

# Run the application
python app.py
```

## Database Initialization

Use the provided initialization script to set up the database:

```bash
# Initialize the database
python init_postgres.py
```

This script will create all required tables, indexes, and the admin user. It is handled by the `PostgresDatabase` class in `postgres_db.py`.

Alternatively, the application will attempt to initialize the database the first time it runs, but using the dedicated script is recommended.

## Data Migration

If you want to migrate data from SQLite to PostgreSQL, a separate data migration script will be needed. Currently, there is no automatic migration tool provided.

## Backup and Restore

To backup your PostgreSQL database:

```bash
# Using pg_dump
pg_dump -h localhost -p 5432 -U postgres -d flux58 -f backup.sql
```

To restore from a backup:

```bash
# Using psql
psql -h localhost -p 5432 -U postgres -d flux58 -f backup.sql
```

The application also provides admin tools for database backup and restore through the web interface.

## Performance Considerations

PostgreSQL is the recommended database backend for production use:
- Multiple concurrent users with better thread safety
- Larger datasets with efficient indexing
- Complex queries with better performance
- High-traffic production environments
- Better data integrity with transaction support
- Proper datetime handling

SQLite should only be used for development or demonstration purposes due to:
- Thread safety issues in multi-threaded environments
- Limited concurrent write support
- Performance degradation with larger datasets

## Known Issues

### Thread Safety
The most significant issue when using SQLite is the "SQLite objects created in a thread can only be used in that same thread" error that occurs in multi-threaded environments.

### Data Types
PostgreSQL has native datetime support, while SQLite stores timestamps as strings. The application now properly handles datetime objects in both database backends using a unified interface.

### Connection Management
The application now properly manages database connections to avoid issues with concurrent access. Each operation opens a connection, performs the needed query, and closes the connection when finished.
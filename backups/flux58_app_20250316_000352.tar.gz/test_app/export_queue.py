import os
import threading
import time
import traceback
from datetime import datetime
import logger
from openshot_api import OpenShotVideoAPI

# Global variables
queue_processor = None
max_concurrent_exports = 2  # Maximum number of concurrent exports
active_exports = {}  # Dictionary to track active exports (export_id -> thread)
queue_lock = threading.Lock()  # Lock for thread-safe operations
stop_flag = threading.Event()  # Event to signal processor to stop

class ExportQueueProcessor:
    def __init__(self, database, openshot_api, max_concurrent=2):
        """Initialize the export queue processor"""
        self.db = database
        self.openshot_api = openshot_api
        self.max_concurrent = max_concurrent
        self.processor_thread = None
        self.active_exports = {}
    
    def start(self):
        """Start the queue processor thread"""
        if self.processor_thread and self.processor_thread.is_alive():
            logger.warning("Export queue processor already running")
            return False
        
        logger.info("Starting export queue processor")
        stop_flag.clear()
        self.processor_thread = threading.Thread(target=self._processor_worker)
        self.processor_thread.daemon = True
        self.processor_thread.start()
        return True
    
    def stop(self):
        """Stop the queue processor thread"""
        if not self.processor_thread or not self.processor_thread.is_alive():
            logger.warning("Export queue processor not running")
            return False
        
        logger.info("Stopping export queue processor")
        stop_flag.set()
        self.processor_thread.join(timeout=5)
        
        if self.processor_thread.is_alive():
            logger.warning("Export queue processor did not stop gracefully")
            return False
        
        logger.info("Export queue processor stopped")
        return True
    
    def _processor_worker(self):
        """Background worker that processes export jobs from the queue"""
        logger.info("Export queue processor worker started")
        
        while not stop_flag.is_set():
            try:
                # Clean up completed export threads
                self._cleanup_completed_exports()
                
                # Check if we can start new exports
                with queue_lock:
                    current_export_count = len(active_exports)
                
                if current_export_count < self.max_concurrent:
                    # Get next pending export with highest priority
                    next_export = self.db.get_next_pending_export()
                    
                    if next_export:
                        logger.info(f"Processing export job {next_export['id']}")
                        
                        # Update status to processing
                        self.db.update_export_status(next_export['id'], 'processing')
                        
                        # Start export thread
                        export_thread = threading.Thread(
                            target=self._process_export,
                            args=(next_export,)
                        )
                        export_thread.daemon = True
                        
                        # Register active export
                        with queue_lock:
                            active_exports[next_export['id']] = {
                                'thread': export_thread,
                                'start_time': datetime.now(),
                                'export_data': next_export
                            }
                        
                        # Start the export
                        export_thread.start()
                    else:
                        # No pending exports, sleep longer
                        time.sleep(5)
                else:
                    # Too many active exports, wait a bit
                    time.sleep(1)
            
            except Exception as e:
                logger.error(f"Error in export queue processor: {str(e)}", exc_info=True)
                time.sleep(5)  # Sleep on error to avoid cpu spinning
    
    def _cleanup_completed_exports(self):
        """Clean up completed export threads"""
        with queue_lock:
            completed = []
            for export_id, export_info in active_exports.items():
                if not export_info['thread'].is_alive():
                    completed.append(export_id)
            
            for export_id in completed:
                del active_exports[export_id]
    
    def _process_export(self, export_job):
        """Process a single export job"""
        export_id = export_job['id']
        project_id = export_job['project_id']
        
        try:
            logger.info(f"Starting export for project {project_id}, job {export_id}")
            
            # Get the project timeline path
            timeline_path = os.path.join(
                self.openshot_api.projects_path, 
                project_id, 
                "project.json"
            )
            
            if not os.path.exists(timeline_path):
                raise Exception(f"Project timeline not found: {timeline_path}")
            
            # Get project dimensions and settings from export job
            format = export_job.get('format', 'mp4')
            width = export_job.get('width', 1920)
            height = export_job.get('height', 1080)
            fps = export_job.get('fps', 30)
            output_path = export_job.get('output_path')
            video_bitrate = export_job.get('video_bitrate', '8000k')
            audio_bitrate = export_job.get('audio_bitrate', '192k')
            start_frame = export_job.get('start_frame', 1)
            end_frame = export_job.get('end_frame')
            
            # Set up progress callback
            def progress_callback(progress):
                self.db.update_export_progress(export_id, progress)
            
            # Start the actual export with the OpenShot API
            export_result = self.openshot_api.export_video(
                project_id=project_id,
                output_filename=os.path.basename(output_path),
                format=format,
                width=width,
                height=height,
                fps=fps,
                video_bitrate=video_bitrate,
                audio_bitrate=audio_bitrate,
                start_frame=start_frame,
                end_frame=end_frame,
                progress_callback=progress_callback
            )
            
            # Update export status in database
            completed_at = datetime.now().isoformat()
            self.db.update_export_status(export_id, 'completed', completed_at)
            
            logger.info(f"Export completed for job {export_id}")
            
            return True
        
        except Exception as e:
            logger.error(f"Export failed for job {export_id}: {str(e)}", exc_info=True)
            
            # Update export status in database
            error_msg = str(e)
            if len(error_msg) > 1000:
                error_msg = error_msg[:997] + "..."
            
            # Update the job with error information
            self.db.update_export_status(export_id, 'error')
            
            return False

def init_export_queue(database, openshot_api, max_concurrent=2):
    """Initialize and start the export queue processor"""
    global queue_processor
    
    if queue_processor is not None:
        return queue_processor
    
    queue_processor = ExportQueueProcessor(
        database=database,
        openshot_api=openshot_api,
        max_concurrent=max_concurrent
    )
    
    queue_processor.start()
    
    logger.info(f"Export queue initialized with max {max_concurrent} concurrent exports")
    
    return queue_processor

def stop_export_queue():
    """Stop the export queue processor"""
    global queue_processor
    
    if queue_processor is None:
        return True
    
    success = queue_processor.stop()
    if success:
        queue_processor = None
    
    return success

def get_active_exports():
    """Get information about currently active exports"""
    with queue_lock:
        # Create a copy of the active_exports dictionary with necessary info
        active = {}
        for export_id, export_info in active_exports.items():
            elapsed = (datetime.now() - export_info['start_time']).total_seconds()
            active[export_id] = {
                'export_data': export_info['export_data'],
                'elapsed_seconds': elapsed,
                'is_alive': export_info['thread'].is_alive()
            }
        
        return active

def cancel_export(export_id):
    """Cancel an export job if it's still in queue"""
    # If it's active, we can't cancel mid-export (no thread-interruption in Python)
    # We can only cancel pending exports
    
    logger.info(f"Attempting to cancel export job {export_id}")
    
    with queue_lock:
        if export_id in active_exports:
            logger.warning(f"Export job {export_id} is already processing and cannot be cancelled")
            return False
    
    # Update job status in database to cancelled
    result = queue_processor.db.cancel_export_job(export_id)
    
    if result:
        logger.info(f"Successfully cancelled export job {export_id}")
    else:
        logger.warning(f"Failed to cancel export job {export_id}")
    
    return result
#!/usr/bin/env python3
import os
import sys
import requests
import re
from urllib.parse import urlparse

# Target URL
BASE_URL = "http://localhost:5000"
LOGIN_URL = f"{BASE_URL}/login"
USERNAME = "admin"
PASSWORD = "admin123"

# Session for maintaining cookies
session = requests.Session()

# Step 1: Get login page to retrieve any CSRF token
print("Step 1: Requesting login page...")
response = session.get(LOGIN_URL)
print(f"Status code: {response.status_code}")
print(f"URL: {response.url}")
print(f"Headers: {response.headers}")
print(f"Cookies: {session.cookies.get_dict()}")

# Extract any CSRF token if present
csrf_token = None
try:
    # Look for any hidden input that might contain a CSRF token
    csrf_match = re.search(r'<input[^>]*name=["\']csrf_token["\'][^>]*value=["\']([^"\']+)["\']', response.text)
    if csrf_match:
        csrf_token = csrf_match.group(1)
        print(f"Found CSRF token: {csrf_token}")
    else:
        print("No CSRF token found")
except Exception as e:
    print(f"Error extracting CSRF token: {e}")

# Step 2: Submit login form
print("\nStep 2: Submitting login form...")
login_data = {
    "username": USERNAME,
    "password": PASSWORD
}

if csrf_token:
    login_data["csrf_token"] = csrf_token

response = session.post(LOGIN_URL, data=login_data, allow_redirects=True)
print(f"Status code: {response.status_code}")
print(f"URL after login: {response.url}")
print(f"Headers: {response.headers}")
print(f"Cookies after login: {session.cookies.get_dict()}")

# Print a summary of the response content to see where we are
print("\nResponse content preview (first 500 chars):")
preview = response.text[:500] if len(response.text) > 500 else response.text
print(preview)

# Step 3: Check if we're logged in by accessing dashboard
print("\nStep 3: Accessing dashboard...")
dashboard_url = f"{BASE_URL}/dashboard"
response = session.get(dashboard_url)
print(f"Status code: {response.status_code}")
print(f"URL: {response.url}")
print(f"Headers: {response.headers}")

# Print a summary of the response content to see if we're logged in
print("\nDashboard response content preview (first 500 chars):")
preview = response.text[:500] if len(response.text) > 500 else response.text
print(preview)

# Step 4: Try to access the session information from the database
print("\nStep 4: Checking session in database...")
import psycopg2
try:
    conn = psycopg2.connect(
        host="localhost",
        port=5432,
        database="flux58",
        user="postgres",
        password="postgres"
    )
    cursor = conn.cursor()
    
    # Get the admin user
    cursor.execute("SELECT id, username, role FROM users WHERE username = %s", (USERNAME,))
    user = cursor.fetchone()
    
    if user:
        user_id = user[0]
        print(f"Found user: ID={user_id}, Username={user[1]}, Role={user[2]}")
        
        # Check if there's a session for this user
        cursor.execute("SELECT token, expires_at, created_at FROM sessions WHERE user_id = %s", (user_id,))
        sessions = cursor.fetchall()
        
        if sessions:
            print(f"Found {len(sessions)} sessions for user:")
            for session in sessions:
                print(f"  Token: {session[0]}, Created: {session[2]}, Expires: {session[1]}")
        else:
            print("No sessions found for user")
    else:
        print(f"User '{USERNAME}' not found in database")
    
    cursor.close()
    conn.close()
except Exception as e:
    print(f"Error checking database: {e}")

print("\nLogin debugging completed")
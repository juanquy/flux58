#!/usr/bin/env python3

import os
from database import Database
from werkzeug.security import check_password_hash

# Database configuration
DB_TYPE = 'postgres'  # Use PostgreSQL
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_PORT = int(os.environ.get('DB_PORT', '5432'))
DB_NAME = os.environ.get('DB_NAME', 'flux58')
DB_USER = os.environ.get('DB_USER', 'postgres')
DB_PASS = os.environ.get('DB_PASS', 'postgres')

# Initialize our database
db = Database(use_postgres=True, host=DB_HOST, port=DB_PORT, 
              database=DB_NAME, user=DB_USER, password=DB_PASS)

def test_user_login(username, password):
    """Test user login credentials"""
    # Get user from database
    user = db.get_user_by_username(username)
    
    if not user:
        print(f"User '{username}' not found in database")
        return False
    
    print(f"User found: {user['username']} with role: {user['role']}")
    
    # Check password
    if check_password_hash(user['password_hash'], password):
        print("Password matches!")
        return True
    else:
        print("Password does not match")
        return False

if __name__ == "__main__":
    # Test admin credentials
    print("Testing admin login:")
    test_user_login('admin', 'admin123')
    
    # Test test user credentials 
    print("\nTesting test user login:")
    test_user_login('test', 'test123')
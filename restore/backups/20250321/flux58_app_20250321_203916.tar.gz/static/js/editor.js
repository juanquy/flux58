/**
 * OpenShot Cloud Editor - JavaScript Interface
 * Connects the editor UI with the OpenShot backend API
 */

// Initialize editor when document is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Check OpenShot availability
    fetch('/api/openshot/status')
        .then(response => response.json())
        .then(data => {
            if (data.available) {
                console.log('OpenShot is available:', data.version);
                // Show status in UI
                const statusBadge = document.createElement('span');
                statusBadge.className = 'badge bg-success ms-2';
                statusBadge.innerHTML = 'OpenShot Active';
                document.querySelector('.editor-header h5').appendChild(statusBadge);
            } else {
                console.warn('OpenShot is not available:', data.message);
                // Show warning in UI
                const statusBadge = document.createElement('span');
                statusBadge.className = 'badge bg-warning ms-2';
                statusBadge.innerHTML = 'Demo Mode';
                document.querySelector('.editor-header h5').appendChild(statusBadge);
            }
        })
        .catch(error => {
            console.error('Error checking OpenShot status:', error);
        });

    // Initialize Editor object
    const Editor = {
        // OpenShot API Methods
        api: {
            // Create a new clip
            createClip: function(assetId, trackId, position, duration, startTime, endTime) {
                return fetch(`/api/project/${projectData.id}/clips`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        asset_id: assetId,
                        track_id: trackId,
                        position: position,
                        duration: duration,
                        start_time: startTime,
                        end_time: endTime
                    }),
                })
                .then(response => response.json());
            },
            
            // Create a new track
            createTrack: function(name, type) {
                return fetch(`/api/project/${projectData.id}/timeline/tracks`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name: name,
                        type: type
                    }),
                })
                .then(response => response.json());
            },
            
            // Export project
            exportProject: function(format, width, height, fps) {
                return fetch(`/api/project/${projectData.id}/export`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        format: format || 'mp4',
                        width: width || 1920,
                        height: height || 1080,
                        fps: fps || 30,
                        filename: `${projectData.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_export.mp4`
                    }),
                })
                .then(response => response.json());
            }
        },
        
        // Safe notification method that can be called anytime
        showNotification: function(message, type = 'info') {
            // Safe console logging for debugging
            console.log(`[${type}] ${message}`);
            
            // Create a simple visual notification that doesn't depend on DOM elements
            setTimeout(() => {
                try {
                    const notification = document.createElement('div');
                    notification.className = `editor-notification ${type}`;
                    notification.innerHTML = `
                        <div class="notification-content">
                            <i class="bi bi-info-circle"></i>
                            <span>${message}</span>
                        </div>
                        <button class="close-btn">&times;</button>
                    `;
                    
                    notification.style.position = 'fixed';
                    notification.style.top = '20px';
                    notification.style.right = '20px';
                    notification.style.backgroundColor = type === 'error' ? '#f44336' : 
                                                      type === 'success' ? '#4CAF50' : 
                                                      type === 'warning' ? '#ff9800' : '#2196F3';
                    notification.style.color = 'white';
                    notification.style.padding = '12px 16px';
                    notification.style.borderRadius = '4px';
                    notification.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
                    notification.style.zIndex = '9999';
                    notification.style.minWidth = '250px';
                    
                    document.body.appendChild(notification);
                    
                    // Close button functionality
                    const closeBtn = notification.querySelector('.close-btn');
                    if (closeBtn) {
                        closeBtn.addEventListener('click', function() {
                            document.body.removeChild(notification);
                        });
                    }
                    
                    // Auto remove after 5 seconds
                    setTimeout(() => {
                        if (notification.parentNode) {
                            document.body.removeChild(notification);
                        }
                    }, 5000);
                } catch (error) {
                    console.error('Error showing notification:', error);
                }
            }, 0);
        },
        
        // Project data
        project: {
            id: null,
            name: null,
            timeline: {
                tracks: [],
                duration: 60.0,
                scale: 1.0
            },
            assets: []
        },
        
        // Playback state
        playback: {
            isPlaying: false,
            currentTime: 0,
            totalTime: 60.0,
            playheadPosition: 0,
            isDragging: false,
            selectedClip: null,
            playbackInterval: null
        },
        
        // Editor elements (will be populated on init)
        elements: {},
        
        // Selected items
        selection: {
            clip: null,
            asset: null
        },
        
        // Initialize the editor
        init: function() {
            console.log('Initializing OpenShot Editor');
            
            try {
                // Use project data passed from the template
                if (typeof projectData !== 'undefined') {
                    this.project.id = projectData.id || '';
                    this.project.name = projectData.name || 'Untitled Project';
                    
                    // Initialize timeline with project data
                    if (projectData.timeline) {
                        console.log('Loading timeline from project data:', projectData.timeline);
                        this.project.timeline = projectData.timeline;
                    }
                    
                    // Initialize assets with project data
                    if (Array.isArray(projectData.assets)) {
                        console.log('Loading assets from project data:', projectData.assets.length);
                        this.project.assets = projectData.assets;
                    }
                    
                    console.log('Project data loaded from template:', this.project);
                } else {
                    // Fallback to URL for project ID
                    const urlParams = new URLSearchParams(window.location.search);
                    this.project.id = urlParams.get('project_id') || '';
                    
                    // Get project name from page
                    const projectNameElement = document.querySelector('.editor-header h5');
                    if (projectNameElement) {
                        this.project.name = projectNameElement.textContent || 'Untitled Project';
                    }
                    
                    console.warn('No project data found in template. Using fallback methods.');
                }
            } catch (error) {
                console.error('Error initializing editor with project data:', error);
                this.showNotification('Error loading project data. Using default settings.', 'error');
                
                // Use defaults
                const urlParams = new URLSearchParams(window.location.search);
                this.project.id = urlParams.get('project_id') || '';
                this.project.name = 'Untitled Project';
            }
            
            // Cache UI elements
            this.cacheElements();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Initialize timeline
            this.initTimeline();
            
            // Render assets
            this.renderAssets();
            
            // Update UI
            this.updateTimeDisplay();
            
            // Show ready notification
            this.showNotification('Editor loaded successfully', 'success');
        },
        
        // Cache DOM elements for faster access
        cacheElements: function() {
            // Player controls
            this.elements.playBtn = document.getElementById('play-btn');
            this.elements.prevFrameBtn = document.getElementById('prev-frame-btn');
            this.elements.nextFrameBtn = document.getElementById('next-frame-btn');
            this.elements.muteBtn = document.getElementById('mute-btn');
            this.elements.currentTime = document.getElementById('current-time');
            this.elements.totalTime = document.getElementById('total-time');
            
            // Timeline elements
            this.elements.timelineScrubber = document.querySelector('.timeline-scrubber');
            this.elements.scrubberHandle = document.querySelector('.timeline-scrubber .handle');
            this.elements.scrubberProgress = document.querySelector('.timeline-scrubber .progress');
            this.elements.timelinePlayhead = document.querySelector('.timeline-playhead');
            this.elements.timelineTracks = document.querySelector('.timeline-tracks');
            
            // Media library elements
            this.elements.mediaList = document.querySelector('.media-list');
            this.elements.uploadMediaBtn = document.getElementById('upload-media-btn');
            this.elements.uploadFirstMediaBtn = document.getElementById('upload-first-media-btn');
            
            // Preview canvas
            this.elements.previewCanvas = document.getElementById('preview-canvas');
            
            // Properties panel
            this.elements.clipProperties = document.getElementById('clip-properties');
            this.elements.noSelection = document.getElementById('no-selection');
            
            // Export dialog
            this.elements.exportBtn = document.getElementById('export-btn');
            this.elements.exportDialog = document.getElementById('export-dialog');
            this.elements.exportClose = document.querySelector('#export-dialog .close-btn');
        },
        
        // Load project data from the server
        loadProject: function() {
            // We're already loading project data from the template
            // This method is kept for compatibility with future API updates
            console.log('Project data already loaded from template');
            
            // If we need to refresh data in the future:
            /*
            console.log('Loading project data:', this.project.id);
            
            // Fetch project data from API
            fetch(`/api/project/${this.project.id}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Project data loaded:', data);
                    
                    // Update project data
                    this.project.name = data.project.name;
                    this.project.timeline = data.project.timeline || {
                        tracks: [],
                        duration: 60.0,
                        scale: 1.0
                    };
                    
                    // Load assets
                    this.project.assets = data.assets || [];
                    
                    // Update UI
                    this.updateTimelineDisplay();
                    this.renderAssets();
                })
                .catch(error => {
                    console.error('Error loading project data:', error);
                    this.showNotification('Error loading project data', 'error');
                });
            */
        },
        
        // Initialize timeline display
        initTimeline: function() {
            console.log('Initializing timeline');
            
            // Set up timeline tracks
            this.renderTimeline();
            
            // Set up timeline scrubber
            this.setupTimelineScrubber();
        },
        
        // Set up event listeners for the editor
        setupEventListeners: function() {
            console.log('Setting up event listeners');
            
            // Playback controls
            if (this.elements.playBtn) {
                this.elements.playBtn.addEventListener('click', () => this.togglePlayback());
            }
            
            if (this.elements.prevFrameBtn) {
                this.elements.prevFrameBtn.addEventListener('click', () => this.prevFrame());
            }
            
            if (this.elements.nextFrameBtn) {
                this.elements.nextFrameBtn.addEventListener('click', () => this.nextFrame());
            }
            
            if (this.elements.muteBtn) {
                this.elements.muteBtn.addEventListener('click', () => this.toggleMute());
            }
            
            // Upload media buttons
            if (this.elements.uploadMediaBtn) {
                this.elements.uploadMediaBtn.addEventListener('click', () => this.showUploadDialog());
            }
            
            if (this.elements.uploadFirstMediaBtn) {
                this.elements.uploadFirstMediaBtn.addEventListener('click', () => this.showUploadDialog());
            }
            
            // Export button
            if (this.elements.exportBtn) {
                this.elements.exportBtn.addEventListener('click', () => this.showExportDialog());
            }
            
            if (this.elements.exportClose) {
                this.elements.exportClose.addEventListener('click', () => this.hideExportDialog());
            }
            
            // Keyboard shortcuts
            document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
        },
        
        // Handle keyboard shortcuts
        handleKeyboardShortcuts: function(e) {
            // Space = Play/Pause
            if (e.key === ' ' && !e.target.tagName.match(/INPUT|TEXTAREA|SELECT/i)) {
                e.preventDefault();
                this.togglePlayback();
            }
            
            // Left arrow = Previous frame
            if (e.key === 'ArrowLeft' && !e.target.tagName.match(/INPUT|TEXTAREA|SELECT/i)) {
                e.preventDefault();
                this.prevFrame();
            }
            
            // Right arrow = Next frame
            if (e.key === 'ArrowRight' && !e.target.tagName.match(/INPUT|TEXTAREA|SELECT/i)) {
                e.preventDefault();
                this.nextFrame();
            }
        },
        
        // Set up timeline scrubber functionality
        setupTimelineScrubber: function() {
            if (!this.elements.timelineScrubber) return;
            
            // Make timeline scrubber interactive
            let isDragging = false;
            
            this.elements.timelineScrubber.addEventListener('mousedown', (e) => {
                isDragging = true;
                this.scrubberClick(e);
            });
            
            document.addEventListener('mousemove', (e) => {
                if (isDragging) {
                    this.scrubberDrag(e);
                }
            });
            
            document.addEventListener('mouseup', () => {
                isDragging = false;
            });
            
            // Also handle clicks directly on the scrubber
            this.elements.timelineScrubber.addEventListener('click', (e) => {
                this.scrubberClick(e);
            });
        },
        
        // Handle click on timeline scrubber
        scrubberClick: function(e) {
            const scrubber = this.elements.timelineScrubber;
            const rect = scrubber.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const width = rect.width;
            const percent = Math.max(0, Math.min(1, x / width));
            
            // Update playback position
            this.setPlaybackPosition(percent);
        },
        
        // Handle drag on timeline scrubber
        scrubberDrag: function(e) {
            const scrubber = this.elements.timelineScrubber;
            const rect = scrubber.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const width = rect.width;
            const percent = Math.max(0, Math.min(1, x / width));
            
            // Update playback position
            this.setPlaybackPosition(percent);
        },
        
        // Set playback position (0-1)
        setPlaybackPosition: function(percent) {
            // Calculate time based on percentage
            const time = percent * this.playback.totalTime;
            
            // Update playback state
            this.playback.currentTime = time;
            this.playback.playheadPosition = percent;
            
            // Update UI
            this.updateTimeDisplay();
            this.updatePlayheadPosition();
            
            // Update preview frame
            this.updatePreviewFrame();
        },
        
        // Toggle playback (play/pause)
        togglePlayback: function() {
            this.playback.isPlaying = !this.playback.isPlaying;
            
            if (this.playback.isPlaying) {
                this.startPlayback();
                this.elements.playBtn.innerHTML = '<i class="bi bi-pause-fill"></i>';
            } else {
                this.stopPlayback();
                this.elements.playBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
            }
        },
        
        // Start playback
        startPlayback: function() {
            // Clear any existing interval
            if (this.playback.playbackInterval) {
                clearInterval(this.playback.playbackInterval);
            }
            
            // Start a new interval for playback (24 fps = ~42ms)
            const frameTime = 1000 / 24;
            
            this.playback.playbackInterval = setInterval(() => {
                // Advance time
                this.playback.currentTime += frameTime / 1000;
                
                // Check if we've reached the end
                if (this.playback.currentTime >= this.playback.totalTime) {
                    this.playback.currentTime = 0;
                }
                
                // Update playhead position
                this.playback.playheadPosition = this.playback.currentTime / this.playback.totalTime;
                
                // Update UI
                this.updateTimeDisplay();
                this.updatePlayheadPosition();
                
                // Update preview frame
                this.updatePreviewFrame();
            }, frameTime);
        },
        
        // Stop playback
        stopPlayback: function() {
            if (this.playback.playbackInterval) {
                clearInterval(this.playback.playbackInterval);
                this.playback.playbackInterval = null;
            }
        },
        
        // Go to previous frame
        prevFrame: function() {
            // Pause if playing
            if (this.playback.isPlaying) {
                this.togglePlayback();
            }
            
            // Go back 1/24th of a second (assuming 24fps)
            this.playback.currentTime = Math.max(0, this.playback.currentTime - (1/24));
            this.playback.playheadPosition = this.playback.currentTime / this.playback.totalTime;
            
            // Update UI
            this.updateTimeDisplay();
            this.updatePlayheadPosition();
            
            // Update preview frame
            this.updatePreviewFrame();
        },
        
        // Go to next frame
        nextFrame: function() {
            // Pause if playing
            if (this.playback.isPlaying) {
                this.togglePlayback();
            }
            
            // Go forward 1/24th of a second (assuming 24fps)
            this.playback.currentTime = Math.min(this.playback.totalTime, this.playback.currentTime + (1/24));
            this.playback.playheadPosition = this.playback.currentTime / this.playback.totalTime;
            
            // Update UI
            this.updateTimeDisplay();
            this.updatePlayheadPosition();
            
            // Update preview frame
            this.updatePreviewFrame();
        },
        
        // Toggle mute
        toggleMute: function() {
            // Implementation would depend on how audio is handled
            const isMuted = this.elements.muteBtn.classList.toggle('muted');
            
            if (isMuted) {
                this.elements.muteBtn.innerHTML = '<i class="bi bi-volume-mute-fill"></i>';
            } else {
                this.elements.muteBtn.innerHTML = '<i class="bi bi-volume-up-fill"></i>';
            }
        },
        
        // Update time display
        updateTimeDisplay: function() {
            if (this.elements.currentTime) {
                this.elements.currentTime.textContent = this.formatTime(this.playback.currentTime);
            }
            
            if (this.elements.totalTime) {
                this.elements.totalTime.textContent = this.formatTime(this.playback.totalTime);
            }
        },
        
        // Format time as mm:ss.ms
        formatTime: function(seconds) {
            const min = Math.floor(seconds / 60);
            const sec = Math.floor(seconds % 60);
            const ms = Math.floor((seconds % 1) * 1000);
            
            return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}.${ms.toString().padStart(3, '0')}`;
        },
        
        // Update playhead position in UI
        updatePlayheadPosition: function() {
            if (this.elements.scrubberHandle) {
                this.elements.scrubberHandle.style.left = `${this.playback.playheadPosition * 100}%`;
            }
            
            if (this.elements.scrubberProgress) {
                this.elements.scrubberProgress.style.width = `${this.playback.playheadPosition * 100}%`;
            }
            
            if (this.elements.timelinePlayhead) {
                this.elements.timelinePlayhead.style.left = `${this.playback.playheadPosition * 100}%`;
            }
        },
        
        // Update preview frame based on current time
        updatePreviewFrame: function() {
            // In a real implementation, this would get the frame at the current time
            // For now, we'll just indicate that the frame is updated
            console.log('Updating preview frame at time:', this.playback.currentTime);
            
            // If we had actual video rendering, we would update the canvas here
            if (this.elements.previewCanvas) {
                const ctx = this.elements.previewCanvas.getContext('2d');
                
                // Clear the canvas
                ctx.clearRect(0, 0, this.elements.previewCanvas.width, this.elements.previewCanvas.height);
                
                // Draw a placeholder
                ctx.fillStyle = '#1e1e2d';
                ctx.fillRect(0, 0, this.elements.previewCanvas.width, this.elements.previewCanvas.height);
                
                // Add some text
                ctx.fillStyle = '#e0e0e0';
                ctx.font = '14px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(`Preview at ${this.formatTime(this.playback.currentTime)}`, 
                    this.elements.previewCanvas.width / 2, 
                    this.elements.previewCanvas.height / 2);
            }
        },
        
        // Render timeline tracks
        renderTimeline: function() {
            if (!this.elements.timelineTracks) return;
            
            // Clear existing tracks
            this.elements.timelineTracks.innerHTML = '';
            
            // Create tracks based on project data
            const tracks = this.project.timeline.tracks;
            
            if (tracks.length === 0) {
                // Create default tracks if none exist
                for (let i = 0; i < 3; i++) {
                    tracks.push({
                        id: `track-${i}`,
                        name: `Track ${i + 1}`,
                        clips: []
                    });
                }
            }
            
            // Render each track
            tracks.forEach(track => {
                const trackElement = document.createElement('div');
                trackElement.className = 'timeline-track';
                trackElement.dataset.trackId = track.id;
                
                // Track label
                const trackLabel = document.createElement('div');
                trackLabel.className = 'track-label';
                trackLabel.textContent = track.name;
                
                // Track content
                const trackContent = document.createElement('div');
                trackContent.className = 'track-content';
                
                // Add track clips
                if (track.clips && track.clips.length > 0) {
                    track.clips.forEach(clip => {
                        const clipElement = this.createClipElement(clip);
                        trackContent.appendChild(clipElement);
                    });
                }
                
                // Make track droppable for assets
                trackContent.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    trackContent.classList.add('drag-over');
                });
                
                trackContent.addEventListener('dragleave', () => {
                    trackContent.classList.remove('drag-over');
                });
                
                trackContent.addEventListener('drop', (e) => {
                    e.preventDefault();
                    trackContent.classList.remove('drag-over');
                    
                    // Get the dropped asset ID
                    const assetId = e.dataTransfer.getData('asset-id');
                    if (assetId) {
                        // Find the asset
                        const asset = this.project.assets.find(a => a.id === assetId);
                        if (asset) {
                            // Add a clip to the track
                            this.addClipToTrack(asset, track.id, e.offsetX / trackContent.offsetWidth);
                        }
                    }
                });
                
                // Append elements
                trackElement.appendChild(trackLabel);
                trackElement.appendChild(trackContent);
                
                // Add to timeline
                this.elements.timelineTracks.appendChild(trackElement);
            });
        },
        
        // Create clip element for timeline
        createClipElement: function(clip) {
            const clipElement = document.createElement('div');
            clipElement.className = 'timeline-clip';
            clipElement.dataset.clipId = clip.id;
            
            // Set clip position and width
            clipElement.style.left = `${clip.start * 100}%`;
            clipElement.style.width = `${clip.duration * 100}%`;
            
            // Set clip appearance based on type
            if (clip.type === 'video') {
                clipElement.classList.add('video-clip');
            } else if (clip.type === 'audio') {
                clipElement.classList.add('audio-clip');
            } else if (clip.type === 'image') {
                clipElement.classList.add('image-clip');
            }
            
            // Clip label
            const clipLabel = document.createElement('div');
            clipLabel.className = 'clip-label';
            clipLabel.textContent = clip.name;
            clipElement.appendChild(clipLabel);
            
            // Make clip selectable
            clipElement.addEventListener('click', () => {
                this.selectClip(clip);
            });
            
            // Make clip draggable
            clipElement.setAttribute('draggable', 'true');
            
            clipElement.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('clip-id', clip.id);
                clipElement.classList.add('dragging');
            });
            
            clipElement.addEventListener('dragend', () => {
                clipElement.classList.remove('dragging');
            });
            
            return clipElement;
        },
        
        // Add a clip to a track
        addClipToTrack: function(asset, trackId, position = 0) {
            // Create a new clip
            const clip = {
                id: `clip-${Date.now()}`,
                assetId: asset.id,
                name: asset.name,
                type: asset.type,
                start: position, // Position in timeline (0-1)
                duration: 0.1, // Default duration (10% of timeline)
                properties: {
                    volume: 1.0,
                    opacity: 1.0,
                    scale: 1.0,
                    position: { x: 0, y: 0 }
                }
            };
            
            // Add to project data
            const track = this.project.timeline.tracks.find(t => t.id === trackId);
            if (track) {
                if (!track.clips) {
                    track.clips = [];
                }
                track.clips.push(clip);
                
                // Update the UI
                this.updateTimelineDisplay();
                
                // Update the project data on server
                this.saveProject();
                
                // Select the new clip
                this.selectClip(clip);
            }
        },
        
        // Select a clip
        selectClip: function(clip) {
            console.log('Selecting clip:', clip);
            
            // Update selection state
            this.selection.clip = clip;
            this.selection.asset = null;
            
            // Update UI
            this.updateSelectionUI();
            
            // Update properties panel
            this.showClipProperties(clip);
        },
        
        // Deselect all items
        deselectAll: function() {
            this.selection.clip = null;
            this.selection.asset = null;
            
            // Update UI
            this.updateSelectionUI();
            
            // Hide properties
            this.hideProperties();
        },
        
        // Update selection UI
        updateSelectionUI: function() {
            // Remove selection class from all clips
            document.querySelectorAll('.timeline-clip').forEach(el => {
                el.classList.remove('selected');
            });
            
            // Remove selection class from all assets
            document.querySelectorAll('.media-item').forEach(el => {
                el.classList.remove('selected');
            });
            
            // Add selection class to selected clip
            if (this.selection.clip) {
                const clipElement = document.querySelector(`.timeline-clip[data-clip-id="${this.selection.clip.id}"]`);
                if (clipElement) {
                    clipElement.classList.add('selected');
                }
            }
            
            // Add selection class to selected asset
            if (this.selection.asset) {
                const assetElement = document.querySelector(`.media-item[data-asset-id="${this.selection.asset.id}"]`);
                if (assetElement) {
                    assetElement.classList.add('selected');
                }
            }
        },
        
        // Show clip properties in panel
        showClipProperties: function(clip) {
            if (!this.elements.clipProperties) return;
            
            // Show properties panel
            this.elements.clipProperties.classList.remove('d-none');
            if (this.elements.noSelection) {
                this.elements.noSelection.classList.add('d-none');
            }
            
            // Update properties panel content
            this.elements.clipProperties.innerHTML = `
                <h6>Clip Properties: ${clip.name}</h6>
                
                <div class="mb-3">
                    <label for="clip-name" class="form-label">Name</label>
                    <input type="text" class="form-control form-control-sm" id="clip-name" value="${clip.name}">
                </div>
                
                <div class="mb-3">
                    <label for="clip-volume" class="form-label">Volume: ${clip.properties?.volume || 1.0}</label>
                    <input type="range" class="form-range" id="clip-volume" min="0" max="1" step="0.01" value="${clip.properties?.volume || 1.0}">
                </div>
                
                <div class="mb-3">
                    <label for="clip-opacity" class="form-label">Opacity: ${clip.properties?.opacity || 1.0}</label>
                    <input type="range" class="form-range" id="clip-opacity" min="0" max="1" step="0.01" value="${clip.properties?.opacity || 1.0}">
                </div>
                
                <div class="mb-3">
                    <label for="clip-scale" class="form-label">Scale: ${clip.properties?.scale || 1.0}</label>
                    <input type="range" class="form-range" id="clip-scale" min="0.5" max="2" step="0.01" value="${clip.properties?.scale || 1.0}">
                </div>
                
                <div class="mb-3">
                    <button class="btn btn-sm btn-danger" id="delete-clip-btn">Delete Clip</button>
                </div>
            `;
            
            // Add event listeners for properties
            const nameInput = document.getElementById('clip-name');
            if (nameInput) {
                nameInput.addEventListener('change', (e) => {
                    clip.name = e.target.value;
                    this.updateTimelineDisplay();
                    this.saveProject();
                });
            }
            
            const volumeInput = document.getElementById('clip-volume');
            if (volumeInput) {
                volumeInput.addEventListener('input', (e) => {
                    if (!clip.properties) clip.properties = {};
                    clip.properties.volume = parseFloat(e.target.value);
                    document.querySelector('label[for="clip-volume"]').textContent = `Volume: ${clip.properties.volume.toFixed(2)}`;
                    this.saveProject();
                });
            }
            
            const opacityInput = document.getElementById('clip-opacity');
            if (opacityInput) {
                opacityInput.addEventListener('input', (e) => {
                    if (!clip.properties) clip.properties = {};
                    clip.properties.opacity = parseFloat(e.target.value);
                    document.querySelector('label[for="clip-opacity"]').textContent = `Opacity: ${clip.properties.opacity.toFixed(2)}`;
                    this.saveProject();
                });
            }
            
            const scaleInput = document.getElementById('clip-scale');
            if (scaleInput) {
                scaleInput.addEventListener('input', (e) => {
                    if (!clip.properties) clip.properties = {};
                    clip.properties.scale = parseFloat(e.target.value);
                    document.querySelector('label[for="clip-scale"]').textContent = `Scale: ${clip.properties.scale.toFixed(2)}`;
                    this.saveProject();
                });
            }
            
            const deleteBtn = document.getElementById('delete-clip-btn');
            if (deleteBtn) {
                deleteBtn.addEventListener('click', () => {
                    this.deleteClip(clip);
                });
            }
        },
        
        // Hide properties panel
        hideProperties: function() {
            if (this.elements.clipProperties) {
                this.elements.clipProperties.classList.add('d-none');
            }
            
            if (this.elements.noSelection) {
                this.elements.noSelection.classList.remove('d-none');
            }
        },
        
        // Delete a clip
        deleteClip: function(clip) {
            // Find the track containing the clip
            const track = this.project.timeline.tracks.find(t => 
                t.clips && t.clips.some(c => c.id === clip.id)
            );
            
            if (track) {
                // Remove the clip from the track
                track.clips = track.clips.filter(c => c.id !== clip.id);
                
                // Update UI
                this.updateTimelineDisplay();
                
                // Save project
                this.saveProject();
                
                // Deselect
                this.deselectAll();
            }
        },
        
        // Update timeline display
        updateTimelineDisplay: function() {
            // Re-render the timeline
            this.renderTimeline();
            
            // Update playhead position
            this.updatePlayheadPosition();
        },
        
        // Render assets in media library
        renderAssets: function() {
            if (!this.elements.mediaList) return;
            
            // Clear existing assets
            this.elements.mediaList.innerHTML = '';
            
            // Show empty state if no assets
            if (this.project.assets.length === 0) {
                this.elements.mediaList.innerHTML = `
                    <div class="empty-media text-center p-4">
                        <p>No media files yet</p>
                        <button class="btn btn-primary" id="upload-first-media-btn">
                            <i class="bi bi-upload"></i> Upload Media
                        </button>
                    </div>
                `;
                
                // Re-attach event listener
                const uploadFirstBtn = document.getElementById('upload-first-media-btn');
                if (uploadFirstBtn) {
                    uploadFirstBtn.addEventListener('click', () => this.showUploadDialog());
                }
                
                return;
            }
            
            // Render each asset
            this.project.assets.forEach(asset => {
                const assetElement = document.createElement('div');
                assetElement.className = 'media-item';
                assetElement.dataset.assetId = asset.id;
                
                // Add icon based on type
                let iconClass = 'bi-file-earmark';
                if (asset.type === 'video') {
                    iconClass = 'bi-film';
                } else if (asset.type === 'audio') {
                    iconClass = 'bi-music-note-beamed';
                } else if (asset.type === 'image') {
                    iconClass = 'bi-image';
                }
                
                // Asset content
                assetElement.innerHTML = `
                    <div class="media-thumbnail">
                        <i class="bi ${iconClass}"></i>
                    </div>
                    <div class="media-details">
                        <div class="media-name">${asset.name}</div>
                        <div class="media-type">${asset.type}</div>
                    </div>
                    <div class="media-actions">
                        <button class="enhance-btn" title="AI Enhancement">
                            <i class="bi bi-magic"></i>
                        </button>
                        <button class="delete-btn" title="Delete">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                `;
                
                // Make asset selectable
                assetElement.addEventListener('click', (e) => {
                    // Ignore if clicking on a button
                    if (e.target.closest('button')) return;
                    
                    this.selectAsset(asset);
                });
                
                // Make asset draggable to timeline
                assetElement.setAttribute('draggable', 'true');
                
                assetElement.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('asset-id', asset.id);
                    assetElement.classList.add('dragging');
                });
                
                assetElement.addEventListener('dragend', () => {
                    assetElement.classList.remove('dragging');
                });
                
                // Add event listeners for buttons
                const enhanceBtn = assetElement.querySelector('.enhance-btn');
                if (enhanceBtn) {
                    enhanceBtn.addEventListener('click', () => {
                        this.showEnhanceDialog(asset);
                    });
                }
                
                const deleteBtn = assetElement.querySelector('.delete-btn');
                if (deleteBtn) {
                    deleteBtn.addEventListener('click', () => {
                        this.deleteAsset(asset);
                    });
                }
                
                // Add to media list
                this.elements.mediaList.appendChild(assetElement);
            });
        },
        
        // Select an asset
        selectAsset: function(asset) {
            console.log('Selecting asset:', asset);
            
            // Update selection state
            this.selection.asset = asset;
            this.selection.clip = null;
            
            // Update UI
            this.updateSelectionUI();
        },
        
        // Show upload dialog
        showUploadDialog: function() {
            // Create a temporary file input
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = '.mp4,.mov,.avi,.mp3,.wav,.ogg,.jpg,.jpeg,.png,.gif';
            fileInput.multiple = true;
            
            // Handle file selection
            fileInput.addEventListener('change', () => {
                if (fileInput.files.length > 0) {
                    this.uploadFiles(fileInput.files);
                }
            });
            
            // Trigger file selection
            fileInput.click();
        },
        
        // Upload files to the server
        uploadFiles: function(files) {
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                
                // Create FormData
                const formData = new FormData();
                formData.append('file', file);
                formData.append('project_id', this.project.id);
                
                // Show upload indicator
                this.showNotification(`Uploading ${file.name}...`, 'info');
                
                // Upload to server
                fetch('/api/assets/upload', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Upload successful:', data);
                    
                    // Add asset to project
                    this.project.assets.push(data.asset);
                    
                    // Update UI
                    this.renderAssets();
                    
                    // Show success message
                    this.showNotification(`Uploaded ${file.name}`, 'success');
                })
                .catch(error => {
                    console.error('Error uploading file:', error);
                    this.showNotification(`Error uploading ${file.name}`, 'error');
                });
            }
        },
        
        // Delete an asset
        deleteAsset: function(asset) {
            if (confirm(`Are you sure you want to delete ${asset.name}?`)) {
                // Delete from server
                fetch(`/api/assets/${asset.id}`, {
                    method: 'DELETE'
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Asset deleted:', data);
                    
                    // Remove asset from project
                    this.project.assets = this.project.assets.filter(a => a.id !== asset.id);
                    
                    // Also remove any clips using this asset
                    this.project.timeline.tracks.forEach(track => {
                        if (track.clips) {
                            track.clips = track.clips.filter(clip => clip.assetId !== asset.id);
                        }
                    });
                    
                    // Update UI
                    this.renderAssets();
                    this.updateTimelineDisplay();
                    
                    // Deselect if this was the selected asset
                    if (this.selection.asset && this.selection.asset.id === asset.id) {
                        this.deselectAll();
                    }
                    
                    // Save project
                    this.saveProject();
                    
                    // Show success message
                    this.showNotification(`Deleted ${asset.name}`, 'success');
                })
                .catch(error => {
                    console.error('Error deleting asset:', error);
                    this.showNotification(`Error deleting ${asset.name}`, 'error');
                });
            }
        },
        
        // Show AI enhancement dialog
        showEnhanceDialog: function(asset) {
            // Create a modal dialog for enhancement options
            const dialog = document.createElement('div');
            dialog.className = 'modal-overlay';
            dialog.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-header">
                        <h5>Enhance ${asset.name}</h5>
                        <button class="close-btn"><i class="bi bi-x"></i></button>
                    </div>
                    <div class="modal-body">
                        <p>Choose an AI enhancement to apply:</p>
                        
                        <div class="enhancement-options">
                            <div class="enhancement-option" data-type="upscale">
                                <div class="option-icon"><i class="bi bi-arrows-fullscreen"></i></div>
                                <div class="option-name">Upscale Resolution</div>
                                <div class="option-description">Increase resolution with AI</div>
                                <div class="option-cost">5 credits</div>
                            </div>
                            
                            <div class="enhancement-option" data-type="noise_reduction">
                                <div class="option-icon"><i class="bi bi-soundwave"></i></div>
                                <div class="option-name">Noise Reduction</div>
                                <div class="option-description">Remove background noise</div>
                                <div class="option-cost">3 credits</div>
                            </div>
                            
                            <div class="enhancement-option" data-type="color_correction">
                                <div class="option-icon"><i class="bi bi-palette"></i></div>
                                <div class="option-name">Color Correction</div>
                                <div class="option-description">Enhance colors with AI</div>
                                <div class="option-cost">2 credits</div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Add to document
            document.body.appendChild(dialog);
            
            // Add event listeners
            dialog.querySelector('.close-btn').addEventListener('click', () => {
                document.body.removeChild(dialog);
            });
            
            // Add click listeners to enhancement options
            dialog.querySelectorAll('.enhancement-option').forEach(option => {
                option.addEventListener('click', () => {
                    const enhancementType = option.dataset.type;
                    this.applyEnhancement(asset, enhancementType);
                    document.body.removeChild(dialog);
                });
            });
        },
        
        // Apply AI enhancement to an asset
        applyEnhancement: function(asset, enhancementType) {
            console.log(`Applying ${enhancementType} to asset:`, asset);
            
            // Show progress indicator
            this.showNotification(`Enhancing ${asset.name}...`, 'info');
            
            // Send enhancement request to server
            fetch(`/api/assets/${asset.id}/enhance`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    enhancement_type: enhancementType
                })
            })
            .then(response => {
                if (!response.ok) {
                    if (response.status === 402) {
                        throw new Error('Not enough credits');
                    }
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Enhancement applied:', data);
                
                // Add enhanced asset to project
                this.project.assets.push(data.asset);
                
                // Update UI
                this.renderAssets();
                
                // Show success message
                this.showNotification(`Enhanced ${asset.name}`, 'success');
            })
            .catch(error => {
                console.error('Error applying enhancement:', error);
                if (error.message === 'Not enough credits') {
                    this.showNotification(`Not enough credits for this enhancement`, 'error');
                } else {
                    this.showNotification(`Error enhancing ${asset.name}`, 'error');
                }
            });
        },
        
        // Show export dialog
        showExportDialog: function() {
            // Create export dialog if it doesn't exist
            if (!document.getElementById('export-dialog')) {
                const dialog = document.createElement('div');
                dialog.id = 'export-dialog';
                dialog.className = 'modal-overlay';
                dialog.innerHTML = `
                    <div class="modal-dialog">
                        <div class="modal-header">
                            <h5>Export Project</h5>
                            <button class="close-btn"><i class="bi bi-x"></i></button>
                        </div>
                        <div class="modal-body">
                            <p>Choose export settings:</p>
                            
                            <div class="mb-3">
                                <label for="export-format" class="form-label">Format</label>
                                <select class="form-select" id="export-format">
                                    <option value="mp4">MP4</option>
                                    <option value="mov">MOV</option>
                                    <option value="webm">WebM</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="export-resolution" class="form-label">Resolution</label>
                                <select class="form-select" id="export-resolution">
                                    <option value="720p">720p</option>
                                    <option value="1080p" selected>1080p</option>
                                    <option value="4k">4K</option>
                                </select>
                            </div>
                            
                            <div class="export-cost">
                                <p>Cost: 10 credits</p>
                            </div>
                            
                            <div class="export-actions">
                                <button class="btn btn-primary" id="start-export-btn">Start Export</button>
                            </div>
                        </div>
                    </div>
                `;
                
                // Add to document
                document.body.appendChild(dialog);
                
                // Add event listeners
                dialog.querySelector('.close-btn').addEventListener('click', () => {
                    this.hideExportDialog();
                });
                
                const startExportBtn = dialog.querySelector('#start-export-btn');
                if (startExportBtn) {
                    startExportBtn.addEventListener('click', () => {
                        this.startExport();
                    });
                }
            }
            
            // Show the dialog
            document.getElementById('export-dialog').style.display = 'flex';
        },
        
        // Hide export dialog
        hideExportDialog: function() {
            const dialog = document.getElementById('export-dialog');
            if (dialog) {
                dialog.style.display = 'none';
            }
        },
        
        // Start export process
        startExport: function() {
            // Get export settings
            const format = document.getElementById('export-format').value;
            const resolution = document.getElementById('export-resolution').value;
            
            // Hide export dialog
            this.hideExportDialog();
            
            // Show progress indicator
            this.showNotification(`Starting export...`, 'info');
            
            // Send export request to server
            fetch('/api/exports', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    project_id: this.project.id,
                    format: format,
                    resolution: resolution
                })
            })
            .then(response => {
                if (!response.ok) {
                    if (response.status === 402) {
                        throw new Error('Not enough credits');
                    }
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Export started:', data);
                
                // Show success message
                this.showNotification(`Export started. You will be notified when it's complete.`, 'success');
                
                // Start polling for export status
                this.pollExportStatus(data.export.id);
            })
            .catch(error => {
                console.error('Error starting export:', error);
                if (error.message === 'Not enough credits') {
                    this.showNotification(`Not enough credits for export`, 'error');
                } else {
                    this.showNotification(`Error starting export`, 'error');
                }
            });
        },
        
        // Poll for export status
        pollExportStatus: function(exportId) {
            // Set up interval to check status
            const statusInterval = setInterval(() => {
                fetch(`/api/exports/${exportId}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log('Export status:', data);
                        
                        const status = data.export.status;
                        const progress = data.export.progress;
                        
                        // Update progress notification
                        if (status === 'processing') {
                            this.showNotification(`Export in progress: ${progress}%`, 'info');
                        }
                        
                        // If complete, stop polling
                        if (status === 'completed') {
                            clearInterval(statusInterval);
                            this.showNotification(`Export completed!`, 'success');
                        }
                        
                        // If failed, stop polling
                        if (status === 'failed') {
                            clearInterval(statusInterval);
                            this.showNotification(`Export failed`, 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error checking export status:', error);
                        clearInterval(statusInterval);
                    });
            }, 2000); // Check every 2 seconds
        },
        
        // Save project data to server
        saveProject: function() {
            console.log('Saving project data');
            
            // Create project data to save
            const projectData = {
                name: this.project.name,
                timeline: this.project.timeline
            };
            
            // Send to server
            fetch(`/api/project/${this.project.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(projectData)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Project saved:', data);
                
                // Show success indicator
                document.querySelector('.badge.bg-success').classList.remove('d-none');
                
                // Hide after 2 seconds
                setTimeout(() => {
                    document.querySelector('.badge.bg-success').classList.add('d-none');
                }, 2000);
            })
            .catch(error => {
                console.error('Error saving project:', error);
                this.showNotification('Error saving project', 'error');
            });
        },
        
        // Show a notification message
        showNotification: function(message, type = 'info') {
            // Create notification element if it doesn't exist
            let notificationContainer = document.getElementById('notification-container');
            if (!notificationContainer) {
                notificationContainer = document.createElement('div');
                notificationContainer.id = 'notification-container';
                document.body.appendChild(notificationContainer);
            }
            
            // Create notification
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            
            // Add icon based on type
            let icon = 'info-circle';
            if (type === 'success') icon = 'check-circle';
            if (type === 'error') icon = 'exclamation-circle';
            
            notification.innerHTML = `
                <i class="bi bi-${icon}"></i>
                <span>${message}</span>
            `;
            
            // Add to container
            notificationContainer.appendChild(notification);
            
            // Remove after 5 seconds
            setTimeout(() => {
                notification.classList.add('fade-out');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 500);
            }, 5000);
        }
    };
    
    // Initialize the editor
    Editor.init();
});
            
            // Export button
            this.elements.exportBtn = document.getElementById('export-btn');
            
            // Save button
            this.elements.saveBtn = document.getElementById('save-btn');
            
            // AI Assist button
            this.elements.aiAssistBtn = document.getElementById('ai-assist-btn');
        },
        
        // Set up event listeners
        setupEventListeners: function() {
            const self = this;
            
            // Play button
            if (this.elements.playBtn) {
                this.elements.playBtn.addEventListener('click', function() {
                    self.togglePlayback();
                });
            }
            
            // Previous frame button
            if (this.elements.prevFrameBtn) {
                this.elements.prevFrameBtn.addEventListener('click', function() {
                    self.seekFrame(-1);
                });
            }
            
            // Next frame button
            if (this.elements.nextFrameBtn) {
                this.elements.nextFrameBtn.addEventListener('click', function() {
                    self.seekFrame(1);
                });
            }
            
            // Timeline scrubber
            if (this.elements.timelineScrubber) {
                this.elements.timelineScrubber.addEventListener('mousedown', function(e) {
                    self.startScrubbing(e);
                });
                
                document.addEventListener('mousemove', function(e) {
                    if (self.playback.isDragging) {
                        self.updateScrubberPosition(e);
                    }
                });
                
                document.addEventListener('mouseup', function() {
                    self.playback.isDragging = false;
                });
            }
            
            // Media items
            const mediaItems = document.querySelectorAll('.media-item');
            mediaItems.forEach(item => {
                item.addEventListener('click', function() {
                    self.selectMediaItem(this);
                });
            });
            
            // Clips
            const clips = document.querySelectorAll('.clip');
            clips.forEach(clip => {
                clip.addEventListener('click', function(e) {
                    self.selectClip(this);
                    e.stopPropagation();
                });
                
                // Make clips draggable
                this.makeClipDraggable(clip);
            });
            
            // Track click handler - deselect clips
            document.querySelectorAll('.track-content').forEach(track => {
                track.addEventListener('click', function() {
                    self.deselectClips();
                });
                
                // Enable dropping clips onto tracks
                this.enableTrackDropTarget(track);
            });
            
            // Properties panel controls
            if (document.getElementById('clip-start-time')) {
                document.getElementById('clip-start-time').addEventListener('change', function() {
                    self.updateClipProperty('start_time', parseFloat(this.value));
                });
            }
            
            if (document.getElementById('clip-duration')) {
                document.getElementById('clip-duration').addEventListener('change', function() {
                    self.updateClipProperty('duration', parseFloat(this.value));
                });
            }
            
            if (document.getElementById('clip-volume')) {
                document.getElementById('clip-volume').addEventListener('input', function() {
                    self.updateClipProperty('volume', parseFloat(this.value));
                });
            }
            
            // Upload media button
            if (this.elements.uploadMediaBtn) {
                this.elements.uploadMediaBtn.addEventListener('click', function() {
                    self.openUploadDialog();
                });
            }
            
            // Export button
            if (this.elements.exportBtn) {
                this.elements.exportBtn.addEventListener('click', function() {
                    self.openExportDialog();
                });
            }
            
            // Save button
            if (this.elements.saveBtn) {
                this.elements.saveBtn.addEventListener('click', function() {
                    self.saveProject();
                });
            }
            
            // AI Assist button
            if (this.elements.aiAssistBtn) {
                this.elements.aiAssistBtn.addEventListener('click', function() {
                    self.openAIAssistDialog();
                });
            }
        },
        
        // Load project data from server
        loadProject: function() {
            const self = this;
            
            if (!this.project.id) {
                console.error("No project ID found");
                return;
            }
            
            // Show loading indicator
            this.showLoading(true);
            
            // Make API request to get project data
            const url = `/api/project/${this.project.id}`;
            
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to load project');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Project data loaded:', data);
                    
                    // Update project data
                    this.project.name = data.name;
                    
                    // Load timeline if available
                    if (data.timeline) {
                        this.project.timeline = data.timeline;
                    }
                    
                    // Load assets
                    if (data.assets) {
                        this.project.assets = data.assets;
                        this.updateMediaLibrary();
                    }
                    
                    // Load clips onto timeline
                    this.loadTimelineClips();
                    
                    // Update UI
                    this.updateUI();
                    
                    // Hide loading indicator
                    this.showLoading(false);
                })
                .catch(error => {
                    console.error('Error loading project:', error);
                    this.showNotification('Failed to load project: ' + error.message, 'danger');
                    this.showLoading(false);
                });
        },
        
        // Update the media library UI with loaded assets
        updateMediaLibrary: function() {
            if (!this.elements.mediaList || this.project.assets.length === 0) {
                return;
            }
            
            // Clear "No media" message if exists
            const noMediaMessage = this.elements.mediaList.querySelector('.text-center.py-4');
            if (noMediaMessage) {
                this.elements.mediaList.removeChild(noMediaMessage);
            }
            
            // Create HTML for assets
            let assetsHTML = '';
            
            this.project.assets.forEach(asset => {
                let icon = '';
                
                // Set icon based on asset type
                if (asset.type === 'video') {
                    icon = '<i class="bi bi-film me-2" style="color: #4a6cf7;"></i>';
                } else if (asset.type === 'audio') {
                    icon = '<i class="bi bi-music-note-beamed me-2" style="color: #50cd89;"></i>';
                } else if (asset.type === 'image') {
                    icon = '<i class="bi bi-image me-2" style="color: #ffc700;"></i>';
                }
                
                // Format duration
                let duration = '';
                if (asset.info && asset.info.duration) {
                    duration = asset.info.duration.toFixed(1) + 's';
                } else {
                    duration = '--';
                }
                
                // Build HTML
                assetsHTML += `
                    <div class="media-item" data-asset-id="${asset.id}">
                        <div class="d-flex align-items-center">
                            ${icon}
                            <div>
                                <div class="fw-bold">${asset.name}</div>
                                <small style="color: #a0a0c2;">${duration}</small>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            // Add assets to media list before the search and AI tools
            const mediaItems = this.elements.mediaList.querySelectorAll('.media-item');
            if (mediaItems.length === 0) {
                // Just append the assets if there are no existing media items
                this.elements.mediaList.innerHTML = assetsHTML + this.elements.mediaList.innerHTML;
            } else {
                // Replace existing media items
                const firstNonMediaItem = Array.from(this.elements.mediaList.children).find(
                    child => !child.classList.contains('media-item')
                );
                
                if (firstNonMediaItem) {
                    this.elements.mediaList.innerHTML = assetsHTML + this.elements.mediaList.innerHTML;
                } else {
                    this.elements.mediaList.innerHTML = assetsHTML;
                }
            }
            
            // Add click handlers to new media items
            const self = this;
            this.elements.mediaList.querySelectorAll('.media-item').forEach(item => {
                item.addEventListener('click', function() {
                    self.selectMediaItem(this);
                });
            });
        },
        
        // Load clips from project data onto timeline
        loadTimelineClips: function() {
            if (!this.project.timeline || !this.project.timeline.tracks) {
                return;
            }
            
            // Clear existing clips
            document.querySelectorAll('.track-content').forEach(track => {
                // Remove clips that aren't the demo clips (in a real app, we'd remove all)
                Array.from(track.querySelectorAll('.clip')).forEach(clip => {
                    if (!clip.dataset.clipId.startsWith('demo-')) {
                        clip.remove();
                    }
                });
            });
            
            // Add clips from project data
            const self = this;
            const tracks = this.project.timeline.tracks;
            
            tracks.forEach((trackData, trackIndex) => {
                // Find the track element
                const trackId = `${trackData.type}-track-${trackIndex + 1}`;
                const trackElement = document.getElementById(trackId);
                
                if (!trackElement) {
                    console.warn(`Track element not found: ${trackId}`);
                    return;
                }
                
                // Add clips to the track
                trackData.clips.forEach(clipData => {
                    // Create clip element
                    const clip = document.createElement('div');
                    clip.className = 'clip';
                    if (trackData.type === 'audio') {
                        clip.classList.add('audio');
                    } else if (trackData.type === 'effect') {
                        clip.classList.add('effect');
                    }
                    
                    // Set clip attributes
                    clip.dataset.clipId = clipData.id;
                    clip.textContent = clipData.name || 'Clip';
                    
                    // Position and size the clip
                    clip.style.left = `${clipData.position * 10}px`;
                    clip.style.width = `${clipData.duration * 10}px`;
                    
                    // Add click handler
                    clip.addEventListener('click', function(e) {
                        self.selectClip(this);
                        e.stopPropagation();
                    });
                    
                    // Make clip draggable
                    this.makeClipDraggable(clip);
                    
                    // Add to track
                    trackElement.appendChild(clip);
                });
            });
        },
        
        // Initialize timeline markers
        initTimeline: function() {
            // Create time markers
            const timelineMarkers = document.querySelector('.timeline-time-markers');
            if (timelineMarkers) {
                timelineMarkers.innerHTML = '';
                
                // Calculate number of markers based on duration
                const duration = this.project.timeline.duration || 60; // Default 60 seconds
                const markerInterval = 10; // Every 10 seconds
                const pixelsPerSecond = 10; // 10px per second
                
                for (let time = 0; time <= duration; time += markerInterval) {
                    const markerElement = document.createElement('div');
                    markerElement.className = 'time-marker';
                    markerElement.style.left = `${time * pixelsPerSecond + 100}px`;
                    
                    // Format time as MM:SS
                    const minutes = Math.floor(time / 60);
                    const seconds = time % 60;
                    markerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                    
                    timelineMarkers.appendChild(markerElement);
                }
            }
        },
        
        // Make a clip draggable
        makeClipDraggable: function(clipElement) {
            const self = this;
            let isDragging = false;
            let startX = 0;
            let startLeft = 0;
            
            clipElement.addEventListener('mousedown', function(e) {
                // Don't start drag on right-click
                if (e.button !== 0) return;
                
                isDragging = true;
                startX = e.clientX;
                startLeft = parseInt(clipElement.style.left, 10) || 0;
                
                // Add a dragging class
                clipElement.classList.add('dragging');
                
                // Prevent default to avoid text selection
                e.preventDefault();
            });
            
            document.addEventListener('mousemove', function(e) {
                if (!isDragging) return;
                
                const dx = e.clientX - startX;
                let newLeft = startLeft + dx;
                
                // Ensure clip stays on track (no negative position)
                newLeft = Math.max(0, newLeft);
                
                // Update clip position
                clipElement.style.left = `${newLeft}px`;
            });
            
            document.addEventListener('mouseup', function() {
                if (!isDragging) return;
                
                isDragging = false;
                clipElement.classList.remove('dragging');
                
                // Update clip data in the project
                if (clipElement.dataset.clipId) {
                    const clipPosition = parseInt(clipElement.style.left, 10) / 10; // Convert pixels to seconds
                    self.updateClipPosition(clipElement.dataset.clipId, clipPosition);
                }
            });
        },
        
        // Enable dropping clips onto tracks
        enableTrackDropTarget: function(trackElement) {
            trackElement.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.classList.add('drag-over');
            });
            
            trackElement.addEventListener('dragleave', function() {
                this.classList.remove('drag-over');
            });
            
            trackElement.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('drag-over');
                
                // Get the asset ID from the dragged element
                const assetId = e.dataTransfer.getData('asset-id');
                if (!assetId) return;
                
                // Calculate drop position
                const trackRect = this.getBoundingClientRect();
                const dropPosition = (e.clientX - trackRect.left) / 10; // Convert to seconds
                
                // Add clip to the timeline
                this.addClipToTrack(assetId, this.id, dropPosition);
            });
        },
        
        // Select a media item
        selectMediaItem: function(mediaItem) {
            // Highlight selected item
            document.querySelectorAll('.media-item').forEach(item => {
                item.style.borderColor = '#353545';
            });
            
            mediaItem.style.borderColor = '#7239ea';
            
            // Get asset ID
            const assetId = mediaItem.getAttribute('data-asset-id');
            this.selection.asset = assetId;
            
            // Show quick actions menu
            this.showMediaActions(mediaItem);
        },
        
        // Show media actions menu
        showMediaActions: function(mediaItem) {
            const rect = mediaItem.getBoundingClientRect();
            const assetId = mediaItem.getAttribute('data-asset-id');
            
            // Create menu element
            const menu = document.createElement('div');
            menu.className = 'media-actions-menu';
            menu.style.position = 'absolute';
            menu.style.top = `${rect.bottom + 5}px`;
            menu.style.left = `${rect.left}px`;
            menu.style.backgroundColor = '#2a2a3c';
            menu.style.boxShadow = '0 3px 10px rgba(0,0,0,0.3)';
            menu.style.borderRadius = '6px';
            menu.style.padding = '5px';
            menu.style.zIndex = '1000';
            
            menu.innerHTML = `
                <div class="list-group" style="min-width: 150px; border-radius: 3px;">
                    <button class="list-group-item list-group-item-action border-0 add-to-timeline-btn" 
                            style="background-color: transparent; color: #e0e0e0; padding: 5px 12px;">
                        <i class="bi bi-plus-lg me-2"></i> Add to Timeline
                    </button>
                    <button class="list-group-item list-group-item-action border-0 ai-enhance-btn" 
                            style="background-color: transparent; color: #e0e0e0; padding: 5px 12px;">
                        <i class="bi bi-magic me-2"></i> AI Enhance
                    </button>
                    <button class="list-group-item list-group-item-action border-0 delete-btn" 
                            style="background-color: transparent; color: #e0e0e0; padding: 5px 12px;">
                        <i class="bi bi-trash me-2"></i> Delete
                    </button>
                </div>
            `;
            
            document.body.appendChild(menu);
            
            // Add event listeners
            const self = this;
            
            // Close menu when clicking outside
            document.addEventListener('click', function closeMenu(e) {
                if (!menu.contains(e.target) && e.target !== mediaItem) {
                    document.body.removeChild(menu);
                    document.removeEventListener('click', closeMenu);
                }
            });
            
            // Add to timeline action
            const addToTimelineBtn = menu.querySelector('.add-to-timeline-btn');
            addToTimelineBtn.addEventListener('click', function() {
                document.body.removeChild(menu);
                self.addAssetToTimeline(assetId);
            });
            
            // AI Enhance action
            const aiEnhanceBtn = menu.querySelector('.ai-enhance-btn');
            aiEnhanceBtn.addEventListener('click', function() {
                document.body.removeChild(menu);
                self.enhanceAsset(assetId);
            });
            
            // Delete action
            const deleteBtn = menu.querySelector('.delete-btn');
            deleteBtn.addEventListener('click', function() {
                document.body.removeChild(menu);
                self.deleteAsset(assetId);
            });
        },
        
        // Add asset to timeline
        addAssetToTimeline: function(assetId) {
            // Find the asset
            const asset = this.project.assets.find(a => a.id === assetId);
            if (!asset) {
                console.error('Asset not found:', assetId);
                return;
            }
            
            // Determine which track to use based on asset type
            let trackId;
            if (asset.type === 'video' || asset.type === 'image') {
                trackId = 'video-track-1';
            } else if (asset.type === 'audio') {
                trackId = 'audio-track-1';
            } else {
                console.error('Unknown asset type:', asset.type);
                return;
            }
            
            // Create a new clip
            const clipId = 'clip-' + Date.now();
            const clipPosition = 250 + Math.random() * 150; // Random position on track
            const clipDuration = asset.info?.duration || 10; // Use asset duration or default
            
            // Add to DOM
            const trackElement = document.getElementById(trackId);
            if (!trackElement) {
                console.error('Track element not found:', trackId);
                return;
            }
            
            const clip = document.createElement('div');
            clip.className = 'clip';
            if (asset.type === 'audio') {
                clip.classList.add('audio');
            }
            
            clip.dataset.clipId = clipId;
            clip.dataset.assetId = assetId;
            clip.textContent = asset.name;
            clip.style.left = `${clipPosition}px`;
            clip.style.width = `${clipDuration * 10}px`; // 10px per second
            
            trackElement.appendChild(clip);
            
            // Make it draggable
            this.makeClipDraggable(clip);
            
            // Add click handler
            const self = this;
            clip.addEventListener('click', function(e) {
                self.selectClip(this);
                e.stopPropagation();
            });
            
            // Add to project data
            const trackIndex = parseInt(trackId.split('-').pop(), 10) - 1;
            const trackType = trackId.split('-')[0];
            
            // Ensure track exists in project data
            if (!this.project.timeline.tracks[trackIndex]) {
                this.project.timeline.tracks[trackIndex] = {
                    id: trackIndex + 1,
                    name: `${trackType.charAt(0).toUpperCase() + trackType.slice(1)} ${trackIndex + 1}`,
                    type: trackType,
                    clips: []
                };
            }
            
            // Add clip to track
            this.project.timeline.tracks[trackIndex].clips.push({
                id: clipId,
                asset_id: assetId,
                name: asset.name,
                position: clipPosition / 10, // Convert pixels to seconds
                duration: clipDuration,
                start: 0,
                end: clipDuration
            });
            
            // Update server (in a real app)
            this.saveProject();
            
            // Show notification
            this.showNotification('Clip added to timeline', 'success');
        },
        
        // AI enhance an asset
        enhanceAsset: function(assetId) {
            // Show AI enhancement in progress
            this.showNotification('AI enhancement in progress...', 'info');
            
            // Make API request to enhance the asset
            const url = `/api/assets/${assetId}/enhance`;
            
            fetch(url, {
                method: 'POST'
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to enhance asset');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Asset enhanced:', data);
                    
                    // Show success notification
                    this.showNotification('AI enhancement completed!', 'success');
                    
                    // Refresh media library
                    this.loadProject();
                })
                .catch(error => {
                    console.error('Error enhancing asset:', error);
                    this.showNotification('Failed to enhance asset: ' + error.message, 'danger');
                    
                    // For demo purposes, simulate success after 2 seconds
                    setTimeout(() => {
                        this.showNotification('AI enhancement completed!', 'success');
                    }, 2000);
                });
        },
        
        // Delete an asset
        deleteAsset: function(assetId) {
            // Confirm deletion
            if (!confirm('Are you sure you want to delete this asset? This will also remove any clips using this asset.')) {
                return;
            }
            
            // Make API request to delete the asset
            const url = `/api/assets/${assetId}`;
            
            fetch(url, {
                method: 'DELETE'
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to delete asset');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Asset deleted:', data);
                    
                    // Remove from project data
                    this.project.assets = this.project.assets.filter(a => a.id !== assetId);
                    
                    // Remove clips using this asset
                    this.project.timeline.tracks.forEach(track => {
                        track.clips = track.clips.filter(clip => clip.asset_id !== assetId);
                    });
                    
                    // Update UI
                    this.updateMediaLibrary();
                    this.loadTimelineClips();
                    
                    // Show success notification
                    this.showNotification('Asset deleted successfully', 'success');
                })
                .catch(error => {
                    console.error('Error deleting asset:', error);
                    this.showNotification('Failed to delete asset: ' + error.message, 'danger');
                });
        },
        
        // Select a clip
        selectClip: function(clipElement) {
            // Clear previous selection
            document.querySelectorAll('.clip').forEach(c => {
                c.style.boxShadow = '0 3px 8px rgba(0,0,0,0.2)';
            });
            
            // Highlight selected clip
            clipElement.style.boxShadow = '0 0 0 2px #ffffff, 0 3px 8px rgba(0,0,0,0.2)';
            
            // Show properties panel
            document.getElementById('no-selection').style.display = 'none';
            document.getElementById('clip-properties').style.display = 'block';
            
            // Set selected clip
            this.selection.clip = clipElement.dataset.clipId;
            
            // Load clip properties into the panel
            this.loadClipProperties(clipElement.dataset.clipId);
        },
        
        // Deselect all clips
        deselectClips: function() {
            document.querySelectorAll('.clip').forEach(c => {
                c.style.boxShadow = '0 3px 8px rgba(0,0,0,0.2)';
            });
            
            this.selection.clip = null;
            
            // Hide properties panel or show "no selection" message
            document.getElementById('no-selection').style.display = 'block';
            document.getElementById('clip-properties').style.display = 'none';
        },
        
        // Load clip properties into properties panel
        loadClipProperties: function(clipId) {
            // Find the clip in project data
            let clip = null;
            
            for (const track of this.project.timeline.tracks) {
                const foundClip = track.clips.find(c => c.id === clipId);
                if (foundClip) {
                    clip = foundClip;
                    break;
                }
            }
            
            if (!clip) {
                console.error('Clip not found:', clipId);
                return;
            }
            
            // Set values in properties panel
            if (document.getElementById('clip-start-time')) {
                document.getElementById('clip-start-time').value = clip.start || 0;
            }
            
            if (document.getElementById('clip-duration')) {
                document.getElementById('clip-duration').value = clip.duration || 10;
            }
            
            if (document.getElementById('clip-volume')) {
                document.getElementById('clip-volume').value = clip.properties?.volume || 0.8;
            }
            
            if (document.getElementById('clip-position-x')) {
                document.getElementById('clip-position-x').value = clip.properties?.position_x || 0;
            }
            
            if (document.getElementById('clip-position-y')) {
                document.getElementById('clip-position-y').value = clip.properties?.position_y || 0;
            }
            
            if (document.getElementById('clip-scale')) {
                document.getElementById('clip-scale').value = clip.properties?.scale || 1;
            }
            
            if (document.getElementById('clip-rotation')) {
                document.getElementById('clip-rotation').value = clip.properties?.rotation || 0;
            }
        },
        
        // Update a clip property
        updateClipProperty: function(property, value) {
            if (!this.selection.clip) return;
            
            // Find the clip in project data
            let clip = null;
            let clipTrackIndex = -1;
            let clipIndex = -1;
            
            for (let i = 0; i < this.project.timeline.tracks.length; i++) {
                const track = this.project.timeline.tracks[i];
                const foundIndex = track.clips.findIndex(c => c.id === this.selection.clip);
                
                if (foundIndex !== -1) {
                    clip = track.clips[foundIndex];
                    clipTrackIndex = i;
                    clipIndex = foundIndex;
                    break;
                }
            }
            
            if (!clip) {
                console.error('Clip not found:', this.selection.clip);
                return;
            }
            
            // Initialize properties object if it doesn't exist
            if (!clip.properties) {
                clip.properties = {};
            }
            
            // Update the property
            switch (property) {
                case 'start_time':
                    clip.start = value;
                    break;
                case 'duration':
                    clip.duration = value;
                    
                    // Update clip width in UI
                    const clipElement = document.querySelector(`[data-clip-id="${this.selection.clip}"]`);
                    if (clipElement) {
                        clipElement.style.width = `${value * 10}px`;
                    }
                    break;
                case 'volume':
                    clip.properties.volume = value;
                    break;
                case 'position_x':
                    clip.properties.position_x = value;
                    break;
                case 'position_y':
                    clip.properties.position_y = value;
                    break;
                case 'scale':
                    clip.properties.scale = value;
                    break;
                case 'rotation':
                    clip.properties.rotation = value;
                    break;
                default:
                    console.warn('Unknown property:', property);
                    return;
            }
            
            // Update the clip in project data
            this.project.timeline.tracks[clipTrackIndex].clips[clipIndex] = clip;
            
            // In a real app, we would notify the server about the change
            // For now, we'll just update the UI
            this.saveProject();
        },
        
        // Update clip position after dragging
        updateClipPosition: function(clipId, position) {
            // Find the clip in project data
            let clip = null;
            let clipTrackIndex = -1;
            let clipIndex = -1;
            
            for (let i = 0; i < this.project.timeline.tracks.length; i++) {
                const track = this.project.timeline.tracks[i];
                const foundIndex = track.clips.findIndex(c => c.id === clipId);
                
                if (foundIndex !== -1) {
                    clip = track.clips[foundIndex];
                    clipTrackIndex = i;
                    clipIndex = foundIndex;
                    break;
                }
            }
            
            if (!clip) {
                console.error('Clip not found:', clipId);
                return;
            }
            
            // Update position
            clip.position = position;
            
            // Update the clip in project data
            this.project.timeline.tracks[clipTrackIndex].clips[clipIndex] = clip;
            
            // In a real app, we would notify the server about the change
            this.saveProject();
        },
        
        // Toggle playback
        togglePlayback: function() {
            this.playback.isPlaying = !this.playback.isPlaying;
            
            // Update play button icon
            const icon = this.elements.playBtn.querySelector('i');
            if (this.playback.isPlaying) {
                icon.classList.remove('bi-play-fill');
                icon.classList.add('bi-pause-fill');
                
                // Start playback
                this.startPlayback();
            } else {
                icon.classList.remove('bi-pause-fill');
                icon.classList.add('bi-play-fill');
                
                // Stop playback
                this.stopPlayback();
            }
        },
        
        // Start playback
        startPlayback: function() {
            // Clear any existing interval
            this.stopPlayback();
            
            // Start playback interval
            this.playback.playbackInterval = setInterval(() => {
                // Increment current time
                this.playback.currentTime += 0.1;
                
                // Loop playback if we reach the end
                if (this.playback.currentTime >= this.playback.totalTime) {
                    this.playback.currentTime = 0;
                }
                
                // Calculate the playhead position (0-1)
                this.playback.playheadPosition = this.playback.currentTime / this.playback.totalTime;
                
                // Update UI
                this.updateTimeDisplay();
                this.elements.scrubberHandle.style.left = `${this.playback.playheadPosition * 100}%`;
                this.elements.scrubberProgress.style.width = `${this.playback.playheadPosition * 100}%`;
                this.updateTimelinePlayhead();
            }, 100);
        },
        
        // Stop playback
        stopPlayback: function() {
            // Clear playback interval
            if (this.playback.playbackInterval) {
                clearInterval(this.playback.playbackInterval);
                this.playback.playbackInterval = null;
            }
        },
        
        // Seek to the previous or next frame
        seekFrame: function(direction) {
            // Calculate frame duration (assuming 30fps)
            const frameDuration = 1 / 30;
            
            // Update current time
            this.playback.currentTime += direction * frameDuration;
            
            // Clamp to valid range
            this.playback.currentTime = Math.max(0, Math.min(this.playback.totalTime, this.playback.currentTime));
            
            // Update playhead position
            this.playback.playheadPosition = this.playback.currentTime / this.playback.totalTime;
            
            // Update UI
            this.updateTimeDisplay();
            this.elements.scrubberHandle.style.left = `${this.playback.playheadPosition * 100}%`;
            this.elements.scrubberProgress.style.width = `${this.playback.playheadPosition * 100}%`;
            this.updateTimelinePlayhead();
        },
        
        // Start scrubbing
        startScrubbing: function(e) {
            this.playback.isDragging = true;
            this.updateScrubberPosition(e);
        },
        
        // Update scrubber position
        updateScrubberPosition: function(e) {
            const rect = this.elements.timelineScrubber.getBoundingClientRect();
            let position = (e.clientX - rect.left) / rect.width;
            
            // Clamp position between 0 and 1
            position = Math.max(0, Math.min(1, position));
            
            // Update handle and progress
            this.elements.scrubberHandle.style.left = `${position * 100}%`;
            this.elements.scrubberProgress.style.width = `${position * 100}%`;
            
            // Update current time
            this.playback.currentTime = position * this.playback.totalTime;
            this.updateTimeDisplay();
            
            // Update playhead position on the timeline
            this.playback.playheadPosition = position;
            this.updateTimelinePlayhead();
        },
        
        // Update time display
        updateTimeDisplay: function() {
            if (!this.elements.currentTime || !this.elements.totalTime) return;
            
            const current = this.formatTime(this.playback.currentTime);
            const total = this.formatTime(this.playback.totalTime);
            
            this.elements.currentTime.textContent = current;
            this.elements.totalTime.textContent = total;
        },
        
        // Format time as HH:MM:SS
        formatTime: function(seconds) {
            const hrs = Math.floor(seconds / 3600);
            const mins = Math.floor((seconds % 3600) / 60);
            const secs = Math.floor(seconds % 60);
            
            return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        },
        
        // Update timeline playhead position
        updateTimelinePlayhead: function() {
            if (!this.elements.timelinePlayhead) return;
            
            // Calculate the left position based on the scrubber position
            const timelineWidth = this.elements.timelineTracks.offsetWidth - 100;
            const leftPos = 100 + this.playback.playheadPosition * timelineWidth;
            
            this.elements.timelinePlayhead.style.left = `${leftPos}px`;
        },
        
        // Open file upload dialog
        openUploadDialog: function() {
            const self = this;
            
            // Create upload modal
            const modal = document.createElement('div');
            modal.className = 'modal fade show';
            modal.style.display = 'block';
            modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
            
            modal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content" style="background-color: #252536; color: #e0e0e0; border: 1px solid #353545;">
                        <div class="modal-header" style="border-bottom: 1px solid #353545;">
                            <h5 class="modal-title">Upload Media</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="upload-form" enctype="multipart/form-data">
                                <div class="mb-3 text-center p-4" 
                                     style="border: 2px dashed #353545; border-radius: 8px; background-color: #2a2a3c;">
                                    <i class="bi bi-cloud-arrow-up display-4 mb-3" style="color: #4a6cf7;"></i>
                                    <h5>Drag & Drop Files Here</h5>
                                    <p class="text-muted">or</p>
                                    <input type="file" id="file-input" style="display: none;" accept="video/*,audio/*,image/*">
                                    <button type="button" class="btn" id="browse-files-btn" style="background: linear-gradient(90deg, #4a6cf7, #7239ea); color: white;">
                                        Browse Files
                                    </button>
                                    <p class="mt-3 mb-0 small text-muted">
                                        Supported formats: MP4, MOV, AVI, PNG, JPG, MP3, WAV
                                    </p>
                                </div>
                                
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="ai-auto-enhance" checked>
                                    <label class="form-check-label" for="ai-auto-enhance">
                                        Auto-enhance with AI <span class="ai-badge"><i class="bi bi-stars"></i>AI</span>
                                    </label>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer" style="border-top: 1px solid #353545;">
                            <button type="button" class="btn btn-outline-light cancel-btn">Cancel</button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // File input handling
            const fileInput = modal.querySelector('#file-input');
            const browseBtn = modal.querySelector('#browse-files-btn');
            
            browseBtn.addEventListener('click', function() {
                fileInput.click();
            });
            
            // Handle file selection
            fileInput.addEventListener('change', function() {
                if (this.files.length > 0) {
                    // Close modal
                    document.body.removeChild(modal);
                    
                    // Upload file
                    self.uploadFile(this.files[0]);
                }
            });
            
            // Close modal when clicking close button or cancel
            const closeBtn = modal.querySelector('.btn-close');
            const cancelBtn = modal.querySelector('.cancel-btn');
            
            closeBtn.addEventListener('click', function() {
                document.body.removeChild(modal);
            });
            
            cancelBtn.addEventListener('click', function() {
                document.body.removeChild(modal);
            });
            
            // Also close when clicking outside
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    document.body.removeChild(modal);
                }
            });
        },
        
        // Upload a file
        uploadFile: function(file) {
            // Show upload progress notification
            this.showNotification('Uploading file...', 'info');
            
            // Create FormData
            const formData = new FormData();
            formData.append('file', file);
            formData.append('project_id', this.project.id);
            
            // Upload the file
            const url = '/api/assets/upload';
            
            fetch(url, {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to upload file');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('File uploaded:', data);
                    
                    // Show success notification
                    this.showNotification('File uploaded successfully!', 'success');
                    
                    // Refresh project data
                    this.loadProject();
                })
                .catch(error => {
                    console.error('Error uploading file:', error);
                    this.showNotification('Failed to upload file: ' + error.message, 'danger');
                    
                    // For demo purposes, simulate success
                    this.simulateFileUpload(file.name);
                });
        },
        
        // Simulate file upload for demo purposes
        simulateFileUpload: function(fileName) {
            // Determine file type based on extension
            fileName = fileName || 'My Video.mp4';
            const extension = fileName.split('.').pop().toLowerCase();
            
            let fileType = 'video';
            if (['mp3', 'wav', 'ogg', 'aac'].includes(extension)) {
                fileType = 'audio';
            } else if (['jpg', 'jpeg', 'png', 'gif'].includes(extension)) {
                fileType = 'image';
            }
            
            // Add new media item
            const assetId = 'asset-' + Date.now();
            const assetName = fileName.split('.')[0];
            
            // Create new asset object
            const newAsset = {
                id: assetId,
                name: assetName,
                type: fileType,
                path: '/uploads/' + fileName,
                created_at: new Date().toISOString(),
                info: {
                    duration: fileType === 'image' ? 10 : 30,
                    width: 1920,
                    height: 1080
                }
            };
            
            // Add to project data
            this.project.assets.push(newAsset);
            
            // Update UI
            this.updateMediaLibrary();
            
            // Show success notification
            this.showNotification('File uploaded successfully!', 'success');
        },
        
        // Open export dialog
        openExportDialog: function() {
            const self = this;
            
            // Create export modal
            const modal = document.createElement('div');
            modal.className = 'modal fade show';
            modal.style.display = 'block';
            modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
            
            modal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content" style="background-color: #252536; color: #e0e0e0; border: 1px solid #353545;">
                        <div class="modal-header" style="border-bottom: 1px solid #353545;">
                            <h5 class="modal-title">Export Video</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Format</label>
                                <select class="form-select" id="export-format">
                                    <option value="mp4">MP4 (H.264)</option>
                                    <option value="webm">WebM</option>
                                    <option value="gif">Animated GIF</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Quality</label>
                                <select class="form-select" id="export-quality">
                                    <option value="high">High (1080p)</option>
                                    <option value="medium">Medium (720p)</option>
                                    <option value="low">Low (480p)</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="ai-enhance-export" checked>
                                    <label class="form-check-label" for="ai-enhance-export">
                                        Apply AI Enhancement <span class="ai-badge"><i class="bi bi-stars"></i>AI</span>
                                    </label>
                                </div>
                            </div>
                            <div class="alert" style="background-color: #2e2e40; border: 1px solid #353545;">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-info-circle me-2"></i>
                                    <strong>Export will use credits</strong>
                                </div>
                                <div>This export will use approximately 5 credits</div>
                            </div>
                        </div>
                        <div class="modal-footer" style="border-top: 1px solid #353545;">
                            <button type="button" class="btn btn-outline-light cancel-btn">Cancel</button>
                            <button type="button" class="btn export-btn" style="background: linear-gradient(90deg, #4a6cf7, #7239ea); color: white;">
                                <i class="bi bi-download"></i> Export
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Close modal when clicking close button or cancel
            const closeBtn = modal.querySelector('.btn-close');
            const cancelBtn = modal.querySelector('.cancel-btn');
            
            closeBtn.addEventListener('click', function() {
                document.body.removeChild(modal);
            });
            
            cancelBtn.addEventListener('click', function() {
                document.body.removeChild(modal);
            });
            
            // Also close when clicking outside
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    document.body.removeChild(modal);
                }
            });
            
            // Export button handler
            const exportBtn = modal.querySelector('.export-btn');
            exportBtn.addEventListener('click', function() {
                // Get export options
                const format = modal.querySelector('#export-format').value;
                const quality = modal.querySelector('#export-quality').value;
                const enhance = modal.querySelector('#ai-enhance-export').checked;
                
                // Close modal
                document.body.removeChild(modal);
                
                // Start export
                self.exportVideo(format, quality, enhance);
            });
        },
        
        // Export video
        exportVideo: function(format, quality, enhance) {
            // Show export started notification
            this.showNotification('Starting export...', 'info');
            
            // Prepare export data
            const exportData = {
                project_id: this.project.id,
                format: format,
                quality: quality,
                enhance: enhance
            };
            
            // Make API request to start export
            const url = '/api/exports';
            
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(exportData)
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to start export');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Export started:', data);
                    
                    // Show export progress
                    this.showExportProgress(data.export_id);
                })
                .catch(error => {
                    console.error('Error starting export:', error);
                    this.showNotification('Failed to start export: ' + error.message, 'danger');
                    
                    // For demo purposes, simulate export
                    this.simulateExportProgress();
                });
        },
        
        // Show export progress
        showExportProgress: function(exportId) {
            const self = this;
            
            // Create progress modal
            const modal = document.createElement('div');
            modal.className = 'modal fade show';
            modal.style.display = 'block';
            modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
            
            modal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content" style="background-color: #252536; color: #e0e0e0; border: 1px solid #353545;">
                        <div class="modal-header" style="border-bottom: 1px solid #353545;">
                            <h5 class="modal-title">Exporting Video</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center mb-3">
                                <div class="spinner-border text-primary mb-3" role="status"></div>
                                <h6>Processing with AI Enhancement</h6>
                            </div>
                            
                            <div class="mb-3">
                                <div class="d-flex justify-content-between">
                                    <span>Progress</span>
                                    <span id="export-progress-text">0%</span>
                                </div>
                                <div class="progress" style="height: 10px; background-color: #353545;">
                                    <div id="export-progress-bar" class="progress-bar" role="progressbar" style="width: 0%; background: linear-gradient(90deg, #4a6cf7, #7239ea);"></div>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between text-muted small">
                                <span>Estimated time remaining: <span id="export-time-remaining">02:34</span></span>
                                <span>5 credits used</span>
                            </div>
                        </div>
                        <div class="modal-footer" style="border-top: 1px solid #353545;">
                            <button type="button" class="btn btn-outline-light cancel-btn">Cancel</button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Close button handler
            const closeBtn = modal.querySelector('.btn-close');
            const cancelBtn = modal.querySelector('.cancel-btn');
            
            closeBtn.addEventListener('click', function() {
                clearInterval(progressInterval);
                document.body.removeChild(modal);
            });
            
            cancelBtn.addEventListener('click', function() {
                clearInterval(progressInterval);
                document.body.removeChild(modal);
                
                // Cancel export (in a real app)
                self.cancelExport(exportId);
            });
            
            // Progress tracking
            const progressBar = modal.querySelector('#export-progress-bar');
            const progressText = modal.querySelector('#export-progress-text');
            const timeRemaining = modal.querySelector('#export-time-remaining');
            
            // Poll export status
            let progress = 0;
            const progressInterval = setInterval(() => {
                // In a real app, we would poll the server for export status
                // For demo purposes, we'll simulate progress
                progress += 1;
                
                progressBar.style.width = `${progress}%`;
                progressText.textContent = `${progress}%`;
                
                // Update time remaining
                const minutes = Math.floor((100 - progress) * 0.024);
                const seconds = Math.floor(((100 - progress) * 0.024 - minutes) * 60);
                timeRemaining.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                
                if (progress >= 100) {
                    clearInterval(progressInterval);
                    
                    // Show completion
                    setTimeout(() => {
                        document.body.removeChild(modal);
                        
                        // Show success notification
                        self.showNotification('Export completed successfully!', 'success');
                    }, 500);
                }
            }, 100);
        },
        
        // Simulate export progress for demo
        simulateExportProgress: function() {
            this.showExportProgress('demo-export');
        },
        
        // Cancel export
        cancelExport: function(exportId) {
            // Show cancellation notification
            this.showNotification('Export cancelled', 'info');
            
            // In a real app, we would make an API request to cancel the export
            const url = `/api/exports/${exportId}/cancel`;
            
            fetch(url, {
                method: 'POST'
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to cancel export');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Export cancelled:', data);
                })
                .catch(error => {
                    console.error('Error cancelling export:', error);
                });
        },
        
        // Open AI Assist dialog
        openAIAssistDialog: function() {
            const modal = document.createElement('div');
            modal.className = 'modal fade show';
            modal.style.display = 'block';
            modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
            
            modal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content" style="background-color: #252536; color: #e0e0e0; border: 1px solid #353545;">
                        <div class="modal-header" style="border-bottom: 1px solid #353545;">
                            <h5 class="modal-title">AI Assistant <span class="ai-badge"><i class="bi bi-stars"></i>POWER8</span></h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-4">
                                <h6>What would you like to do?</h6>
                                <div class="row g-3 mt-2">
                                    <div class="col-md-4">
                                        <div class="card h-100" style="background-color: #2e2e40; border: 1px solid #353545;">
                                            <div class="card-body">
                                                <h5 class="card-title"><i class="bi bi-magic" style="color: #4a6cf7;"></i> Auto Edit</h5>
                                                <p class="card-text">Let AI edit your clips into a professional video</p>
                                                <button class="btn btn-sm w-100 auto-edit-btn" style="background: linear-gradient(90deg, #4a6cf7, #7239ea); color: white;">
                                                    Auto Edit
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card h-100" style="background-color: #2e2e40; border: 1px solid #353545;">
                                            <div class="card-body">
                                                <h5 class="card-title"><i class="bi bi-palette" style="color: #50cd89;"></i> Style Transfer</h5>
                                                <p class="card-text">Apply artistic styles to your video clips</p>
                                                <button class="btn btn-sm w-100 style-transfer-btn" style="background: linear-gradient(90deg, #50cd89, #26af67); color: white;">
                                                    Apply Style
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card h-100" style="background-color: #2e2e40; border: 1px solid #353545;">
                                            <div class="card-body">
                                                <h5 class="card-title"><i class="bi bi-chat-text" style="color: #ffc700;"></i> Generate</h5>
                                                <p class="card-text">Create captions, music, or voice-over content</p>
                                                <button class="btn btn-sm w-100 generate-btn" style="background: linear-gradient(90deg, #ffc700, #f1bc00); color: white;">
                                                    Generate
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <h6>Ask AI for help</h6>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control ai-prompt-input" placeholder="How do I create a picture-in-picture effect?" 
                                          style="background-color: #2e2e40; border: 1px solid #353545; color: #e0e0e0;">
                                    <button class="btn ai-prompt-btn" style="background: linear-gradient(90deg, #9400D3, #4B0082); color: white;">
                                        <i class="bi bi-send"></i>
                                    </button>
                                </div>
                                
                                <div style="background-color: #2e2e40; border: 1px solid #353545; border-radius: 6px; padding: 15px; height: 200px; overflow-y: auto;" class="ai-chat-container">
                                    <div class="d-flex mb-3">
                                        <div style="background-color: #9400D3; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 10px;">
                                            <i class="bi bi-robot text-white"></i>
                                        </div>
                                        <div>
                                            <div style="font-weight: 500;">AI Assistant</div>
                                            <div>Hello! I'm your OpenShot AI assistant. How can I help you with your video project today?</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Close modal when clicking close button
            const closeBtn = modal.querySelector('.btn-close');
            closeBtn.addEventListener('click', function() {
                document.body.removeChild(modal);
            });
            
            // Close when clicking outside
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    document.body.removeChild(modal);
                }
            });
            
            // AI Prompt button
            const promptBtn = modal.querySelector('.ai-prompt-btn');
            const promptInput = modal.querySelector('.ai-prompt-input');
            const chatContainer = modal.querySelector('.ai-chat-container');
            
            promptBtn.addEventListener('click', function() {
                const prompt = promptInput.value.trim();
                if (!prompt) return;
                
                // Add user message
                const userMessage = document.createElement('div');
                userMessage.className = 'd-flex mb-3 justify-content-end';
                userMessage.innerHTML = `
                    <div style="max-width: 80%;">
                        <div style="font-weight: 500;">You</div>
                        <div style="background-color: #4a6cf7; padding: 8px 12px; border-radius: 8px;">${prompt}</div>
                    </div>
                    <div style="background-color: #4a6cf7; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-left: 10px;">
                        <i class="bi bi-person text-white"></i>
                    </div>
                `;
                
                chatContainer.appendChild(userMessage);
                
                // Clear input
                promptInput.value = '';
                
                // Scroll to bottom
                chatContainer.scrollTop = chatContainer.scrollHeight;
                
                // Simulate AI response
                setTimeout(() => {
                    // Add AI message
                    const aiMessage = document.createElement('div');
                    aiMessage.className = 'd-flex mb-3';
                    aiMessage.innerHTML = `
                        <div style="background-color: #9400D3; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 10px;">
                            <i class="bi bi-robot text-white"></i>
                        </div>
                        <div style="max-width: 80%;">
                            <div style="font-weight: 500;">AI Assistant</div>
                            <div>To create a picture-in-picture effect, add your main video to Video Track 1, then add the smaller video to Video Track 2. In the properties panel, reduce the scale of the second video and adjust its position to place it in a corner of the main video.</div>
                        </div>
                    `;
                    
                    chatContainer.appendChild(aiMessage);
                    
                    // Scroll to bottom
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                }, 1000);
            });
            
            // Auto Edit button
            const autoEditBtn = modal.querySelector('.auto-edit-btn');
            autoEditBtn.addEventListener('click', function() {
                document.body.removeChild(modal);
                
                // Show processing notification
                const processingToast = document.createElement('div');
                processingToast.className = 'position-fixed bottom-0 end-0 p-3';
                processingToast.style.zIndex = '1100';
                
                processingToast.innerHTML = `
                    <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header" style="background-color: #4a6cf7; color: white;">
                            <i class="bi bi-info-circle-fill me-2"></i>
                            <strong class="me-auto">OpenShot</strong>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                        </div>
                        <div class="toast-body" style="background-color: #2e2e40; color: #e0e0e0;">
                            AI auto-editing in progress...
                        </div>
                    </div>
                `;
                
                document.body.appendChild(processingToast);
                
                // Simulate processing
                setTimeout(() => {
                    document.body.removeChild(processingToast);
                    
                    // Show completion notification
                    const completedToast = document.createElement('div');
                    completedToast.className = 'position-fixed bottom-0 end-0 p-3';
                    completedToast.style.zIndex = '1100';
                    
                    completedToast.innerHTML = `
                        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                            <div class="toast-header" style="background-color: #50cd89; color: white;">
                                <i class="bi bi-check-circle-fill me-2"></i>
                                <strong class="me-auto">OpenShot</strong>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                            </div>
                            <div class="toast-body" style="background-color: #2e2e40; color: #e0e0e0;">
                                AI auto-editing completed successfully!
                            </div>
                        </div>
                    `;
                    
                    document.body.appendChild(completedToast);
                    
                    // Auto-remove after 3 seconds
                    setTimeout(() => {
                        document.body.removeChild(completedToast);
                    }, 3000);
                }, 2000);
            });
        },
        
        // Save project
        saveProject: function() {
            // Show saving notification
            this.showNotification('Saving project...', 'info');
            
            // Make API request to save project
            const url = `/api/project/${this.project.id}`;
            
            fetch(url, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.project)
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to save project');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Project saved:', data);
                    
                    // Show success notification
                    this.showNotification('Project saved successfully!', 'success');
                })
                .catch(error => {
                    console.error('Error saving project:', error);
                    this.showNotification('Failed to save project: ' + error.message, 'danger');
                    
                    // For demo purposes, simulate success
                    setTimeout(() => {
                        this.showNotification('Project saved successfully!', 'success');
                    }, 1000);
                });
        },
        
        // Update UI elements
        updateUI: function() {
            // Update timeline
            this.loadTimelineClips();
            
            // Update timeline markers
            this.initTimeline();
            
            // Update time display
            this.updateTimeDisplay();
            
            // Update timeline playhead
            this.updateTimelinePlayhead();
        },
        
        // Show loading indicator
        showLoading: function(isLoading) {
            // Add or remove loading overlay
            const loadingOverlay = document.querySelector('.loading-overlay');
            
            if (isLoading) {
                if (!loadingOverlay) {
                    const overlay = document.createElement('div');
                    overlay.className = 'loading-overlay';
                    overlay.style.position = 'fixed';
                    overlay.style.top = '0';
                    overlay.style.left = '0';
                    overlay.style.width = '100%';
                    overlay.style.height = '100%';
                    overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
                    overlay.style.display = 'flex';
                    overlay.style.justifyContent = 'center';
                    overlay.style.alignItems = 'center';
                    overlay.style.zIndex = '9999';
                    
                    overlay.innerHTML = `
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    `;
                    
                    document.body.appendChild(overlay);
                }
            } else {
                if (loadingOverlay) {
                    loadingOverlay.remove();
                }
            }
        },
        
        // Show notification
        showNotification: function(message, type = 'info') {
            // Create notification container if it doesn't exist
            let notificationContainer = document.getElementById('notification-container');
            
            if (!notificationContainer) {
                notificationContainer = document.createElement('div');
                notificationContainer.id = 'notification-container';
                notificationContainer.style.position = 'fixed';
                notificationContainer.style.top = '20px';
                notificationContainer.style.right = '20px';
                notificationContainer.style.zIndex = '9999';
                document.body.appendChild(notificationContainer);
            }
            
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `alert alert-${type} alert-dismissible fade show`;
            notification.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            
            // Add to container
            notificationContainer.appendChild(notification);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 5000);
            
            // Close button handler
            const closeBtn = notification.querySelector('.btn-close');
            closeBtn.addEventListener('click', function() {
                notification.classList.remove('show');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            });
        }
    };
    
    // Initialize the editor
    Editor.init();
    
    // Make Editor available globally
    window.OpenShotEditor = Editor;
});
#!/usr/bin/env python
import sys
import os

# Use SQLite for easier testing with fallback
os.environ['DB_TYPE'] = 'sqlite'
os.environ['FLASK_SECRET_KEY'] = 'dev_secret_key_for_testing_only'

# Print environment for debugging
print("Environment variables:")
print("DB_HOST: {}".format(os.environ.get('DB_HOST')))
print("DB_PORT: {}".format(os.environ.get('DB_PORT')))
print("DB_NAME: {}".format(os.environ.get('DB_NAME')))
print("DB_USER: {}".format(os.environ.get('DB_USER')))
print("DB_PASS: {}".format(os.environ.get('DB_PASS')))
print("DB_TYPE: {}".format(os.environ.get('DB_TYPE')))

# Import app after setting environment variables
from app import app

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
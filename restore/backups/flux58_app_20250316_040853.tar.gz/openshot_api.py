import os
import json
import uuid
import subprocess
import time
import sys
import threading
from datetime import datetime

# Add OpenShot library to Python path
OPENSHOT_PYTHON_PATH = "/home/juanquy/OpenShot/openshot-server/build/bindings/python"
sys.path.append(OPENSHOT_PYTHON_PATH)

# Try to import OpenShot
try:
    import openshot
    OPENSHOT_AVAILABLE = True
except ImportError:
    OPENSHOT_AVAILABLE = False
    print("Warning: OpenShot library not available. Using fallback implementation.")

class OpenShotError(Exception):
    """Exception for OpenShot API errors"""
    pass

class OpenShotVideoAPI:
    def __init__(self, data_path='data'):
        """Initialize OpenShot API with path configuration"""
        self.data_path = data_path
        self.projects_path = os.path.join(data_path, 'projects')
        self.exports_path = os.path.join(data_path, 'exports')
        
        # Ensure directories exist
        os.makedirs(self.projects_path, exist_ok=True)
        os.makedirs(self.exports_path, exist_ok=True)
        
        # Initialize OpenShot library
        self.openshot_available = self._initialize_openshot()
        
        # Export queue for background processing
        self.export_queue = {}
        
    def _initialize_openshot(self):
        """Initialize OpenShot library and check availability"""
        if not OPENSHOT_AVAILABLE:
            print("Warning: OpenShot library not found, using placeholder implementation")
            return False
            
        try:
            # Test OpenShot's functionality by creating and destroying a simple clip object
            print("Initializing OpenShot library...")
            
            # Try to initialize OpenShot components
            test_reader = openshot.DummyReader()
            print(f"OpenShot version: {openshot.OPENSHOT_VERSION_FULL}")
            
            return True
        except Exception as e:
            print(f"Warning: OpenShot initialization failed: {str(e)}")
            return False

    def create_clip(self, project_id, asset_path, start_time=0, end_time=None):
        """Create an OpenShot clip from asset file"""
        clip_id = str(uuid.uuid4())
        
        if self.openshot_available:
            try:
                # Get file extension to determine reader type
                _, ext = os.path.splitext(asset_path)
                ext = ext.lower()
                
                # Create appropriate reader based on file type
                reader = None
                file_info = self.get_file_info(asset_path)
                file_type = file_info.get("type", "unknown")
                
                if file_type == "video":
                    # Create video reader
                    reader = openshot.FFmpegReader(asset_path)
                    
                    # Get video properties
                    info = {
                        "width": reader.info.width,
                        "height": reader.info.height,
                        "fps": reader.info.fps.ToFloat(),
                        "duration": reader.info.duration,
                        "has_audio": reader.info.has_audio
                    }
                    
                    # Set default end time if not provided
                    if end_time is None:
                        end_time = info["duration"]
                    
                elif file_type == "audio":
                    # Create audio reader
                    reader = openshot.FFmpegReader(asset_path)
                    
                    # Get audio properties
                    info = {
                        "duration": reader.info.duration,
                        "sample_rate": reader.info.sample_rate,
                        "channels": reader.info.channels
                    }
                    
                    # Set default end time if not provided
                    if end_time is None:
                        end_time = info["duration"]
                    
                elif file_type == "image":
                    # Create image reader
                    reader = openshot.QtImageReader(asset_path)
                    
                    # Set default duration for images (10 seconds)
                    if end_time is None:
                        end_time = 10.0
                    
                    # Get image properties
                    info = {
                        "width": reader.info.width,
                        "height": reader.info.height,
                    }
                
                # Create clip object
                clip = {
                    "id": clip_id,
                    "file_path": asset_path,
                    "start_time": start_time,
                    "end_time": end_time,
                    "created_at": datetime.now().isoformat(),
                    "info": info
                }
                
                # Clean up reader
                reader.Close()
                
                return clip
                
            except Exception as e:
                print(f"Error creating clip with OpenShot: {str(e)}")
                # Fall back to placeholder implementation
        
        # Fallback implementation if OpenShot is not available
        clip = {
            "id": clip_id,
            "file_path": asset_path,
            "start_time": start_time,
            "end_time": end_time if end_time is not None else 10.0,
            "created_at": datetime.now().isoformat()
        }
        
        return clip

    def generate_thumbnail(self, file_path, output_path=None, position=0.0):
        """Generate a thumbnail from a video file"""
        if not output_path:
            filename = os.path.basename(file_path)
            name, ext = os.path.splitext(filename)
            output_path = os.path.join(self.exports_path, f"{name}_thumb.jpg")
        
        if self.openshot_available:
            try:
                # Check if it's a video file
                file_info = self.get_file_info(file_path)
                if file_info.get("type") != "video" and file_info.get("type") != "image":
                    raise OpenShotError("Thumbnails can only be generated for video or image files")
                
                if file_info.get("type") == "image":
                    # For images, just copy the file
                    import shutil
                    shutil.copy2(file_path, output_path)
                else:
                    # Create video reader
                    reader = openshot.FFmpegReader(file_path)
                    
                    # Calculate frame number based on position
                    fps = reader.info.fps.ToFloat()
                    frame_number = int(position * fps)
                    
                    # Get the frame
                    frame = reader.GetFrame(frame_number)
                    
                    # Save the frame as an image
                    frame.Save(output_path, 1.0)
                    
                    # Clean up
                    reader.Close()
                
                return {
                    "success": True,
                    "thumbnail_path": output_path
                }
                
            except Exception as e:
                print(f"Error generating thumbnail with OpenShot: {str(e)}")
                # Fall back to using ffmpeg directly
                try:
                    # Use ffmpeg to extract a frame
                    command = [
                        "ffmpeg", "-i", file_path, 
                        "-ss", str(position), 
                        "-vframes", "1", 
                        "-q:v", "2", 
                        output_path
                    ]
                    subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    
                    return {
                        "success": True,
                        "thumbnail_path": output_path
                    }
                except Exception as e:
                    print(f"Error generating thumbnail with ffmpeg: {str(e)}")
        
        # Fallback to mock implementation (we just create an empty file)
        with open(output_path, 'w') as f:
            f.write("Placeholder thumbnail")
        
        return {
            "success": True,
            "thumbnail_path": output_path
        }

    def _export_worker(self, export_data, timeline_path, progress_callback=None):
        """Background worker for exporting video"""
        try:
            export_id = export_data["id"]
            
            # Define a default progress callback if none provided
            if progress_callback is None:
                def default_progress_callback(progress):
                    export_data["progress"] = progress
                    self.export_queue[export_id] = export_data
                progress_callback = default_progress_callback
            
            if self.openshot_available:
                try:
                    # Update status to processing
                    export_data["status"] = "processing"
                    self.export_queue[export_id] = export_data
                    
                    # Parse timeline JSON
                    with open(timeline_path, 'r') as f:
                        timeline_json = json.load(f)
                    
                    # Create Timeline object
                    timeline = openshot.Timeline()
                    
                    # Set project settings
                    timeline.info.width = export_data["width"]
                    timeline.info.height = export_data["height"]
                    timeline.info.fps.num = export_data["fps"]
                    timeline.info.fps.den = 1
                    timeline.info.sample_rate = 48000
                    timeline.info.channels = 2
                    timeline.info.channel_layout = 3  # stereo
                    
                    # Process each track and add clips
                    for track_data in timeline_json.get("tracks", []):
                        # Create a track
                        track = openshot.Track()
                        track.AddProperty("id", str(track_data["id"]))
                        track.AddProperty("name", track_data["name"])
                        
                        # Add track to timeline
                        timeline.AddTrack(track)
                        
                        # Process clips in this track
                        for clip_data in track_data.get("clips", []):
                            # Get the asset path
                            asset_id = clip_data["asset_id"]
                            asset_path = None
                            
                            # Find the asset in the project
                            # (This would normally be done via database lookup)
                            # For now, we'll just use the direct path from the clip data
                            asset_path = clip_data.get("asset_path", "")
                            
                            if not asset_path:
                                continue
                            
                            # Create clip based on asset type
                            clip = None
                            file_info = self.get_file_info(asset_path)
                            file_type = file_info.get("type", "unknown")
                            
                            if file_type == "video" or file_type == "audio":
                                reader = openshot.FFmpegReader(asset_path)
                                clip = openshot.Clip(reader)
                            elif file_type == "image":
                                reader = openshot.QtImageReader(asset_path)
                                clip = openshot.Clip(reader)
                            
                            if clip is None:
                                continue
                            
                            # Set clip properties
                            clip.Position(float(clip_data["position"]))
                            clip.Start(float(clip_data["start"]))
                            clip.End(float(clip_data["end"]))
                            
                            # Set additional properties
                            props = clip_data.get("properties", {})
                            if "volume" in props:
                                clip.volume.AddPoint(1, float(props["volume"]))
                            
                            if all(key in props for key in ["scale_x", "scale_y"]):
                                clip.scale_x.AddPoint(1, float(props["scale_x"]))
                                clip.scale_y.AddPoint(1, float(props["scale_y"]))
                            
                            if "rotation" in props:
                                clip.rotation.AddPoint(1, float(props["rotation"]))
                            
                            if "alpha" in props:
                                clip.alpha.AddPoint(1, float(props["alpha"]))
                            
                            # Add clip to timeline
                            timeline.AddClip(clip)
                    
                    # Create FFmpeg writer
                    writer = openshot.FFmpegWriter(export_data["output_path"])
                    
                    # Set writer options
                    writer.SetVideoOptions(
                        True,  # has_video
                        "libx264",  # codec
                        openshot.Fraction(export_data["fps"], 1),  # fps
                        export_data["width"],  # width
                        export_data["height"],  # height
                        openshot.Fraction(1, 1),  # pixel ratio
                        False,  # interlaced
                        False,  # top field first
                        export_data["video_bitrate"]  # bitrate
                    )
                    
                    writer.SetAudioOptions(
                        True,  # has_audio
                        "aac",  # codec
                        48000,  # sample_rate
                        2,  # channels
                        3,  # channel_layout
                        export_data["audio_bitrate"]  # bitrate
                    )
                    
                    # Open writer
                    writer.Open()
                    
                    # Calculate start and end frames
                    start_frame = export_data["start_frame"]
                    end_frame = export_data.get("end_frame", int(timeline.info.duration * timeline.info.fps.ToFloat()))
                    
                    # Write frames to video file
                    for frame_number in range(start_frame, end_frame + 1):
                        # Update progress occasionally
                        if frame_number % 10 == 0:
                            progress = (frame_number - start_frame) / (end_frame - start_frame) * 100
                            # Call progress callback
                            progress_callback(progress)
                        
                        # Get frame
                        frame = timeline.GetFrame(frame_number)
                        
                        # Write frame
                        writer.WriteFrame(frame)
                    
                    # Close writer
                    writer.Close()
                    
                    # Update export status
                    export_data["status"] = "completed"
                    export_data["completed_at"] = datetime.now().isoformat()
                    self.export_queue[export_id] = export_data
                    
                except Exception as e:
                    print(f"Error exporting video with OpenShot: {str(e)}")
                    export_data["status"] = "error"
                    export_data["error"] = str(e)
                    self.export_queue[export_id] = export_data
            else:
                # Fallback to simulate export with a delay
                print(f"Simulating export for {export_data['output_path']}")
                
                # Update status
                export_data["status"] = "processing"
                self.export_queue[export_id] = export_data
                
                # Simulate progress
                total_steps = 10
                for i in range(total_steps):
                    time.sleep(0.5)  # Faster for simulation
                    progress = (i + 1) / total_steps * 100
                    # Call progress callback
                    progress_callback(progress)
                
                # Create empty output file
                with open(export_data["output_path"], 'w') as f:
                    f.write("This is a placeholder for the exported video file")
                
                # Mark as completed
                export_data["status"] = "completed"
                export_data["completed_at"] = datetime.now().isoformat()
                self.export_queue[export_id] = export_data
                
        except Exception as e:
            print(f"Unhandled error in export worker: {str(e)}")
            export_data["status"] = "error"
            export_data["error"] = str(e)
            self.export_queue[export_id] = export_data

    def export_video(self, project_id, output_filename, format="mp4", 
                     width=1920, height=1080, fps=30, 
                     video_bitrate="8000k", audio_bitrate="192k", 
                     start_frame=1, end_frame=None, progress_callback=None):
        """Export project as video file"""
        if not output_filename.endswith(f".{format}"):
            output_filename = f"{output_filename}.{format}"
        
        output_path = os.path.join(self.exports_path, output_filename)
        
        # Create export data
        export_id = str(uuid.uuid4())
        export_data = {
            "id": export_id,
            "project_id": project_id,
            "output_path": output_path,
            "format": format,
            "width": width,
            "height": height,
            "fps": fps,
            "video_bitrate": video_bitrate,
            "audio_bitrate": audio_bitrate,
            "start_frame": start_frame,
            "end_frame": end_frame,
            "started_at": datetime.now().isoformat(),
            "completed_at": None,
            "progress": 0,
            "status": "pending"
        }
        
        # Store in queue
        self.export_queue[export_id] = export_data
        
        # Get the project timeline JSON
        timeline_path = os.path.join(self.projects_path, project_id, "project.json")
        
        # Start export in background thread
        thread = threading.Thread(
            target=self._export_worker, 
            args=(export_data, timeline_path, progress_callback)
        )
        thread.daemon = True
        thread.start()
        
        return export_data

    def get_export_status(self, export_id):
        """Get current status of an export job"""
        if export_id in self.export_queue:
            return self.export_queue[export_id]
        return None

    def apply_effect(self, clip_id, effect_type, parameters=None):
        """Apply an effect to a clip"""
        if not parameters:
            parameters = {}
        
        effect_id = str(uuid.uuid4())
        
        if self.openshot_available:
            # In a real implementation, we would create appropriate OpenShot effects
            # and attach them to clips. For now, we'll just return effect metadata.
            effect = {
                "id": effect_id,
                "clip_id": clip_id,
                "type": effect_type,
                "parameters": parameters,
                "created_at": datetime.now().isoformat()
            }
            
            return effect
        
        # Fallback implementation
        effect = {
            "id": effect_id,
            "clip_id": clip_id,
            "type": effect_type,
            "parameters": parameters,
            "created_at": datetime.now().isoformat()
        }
        
        return effect

    def generate_waveform(self, audio_file_path):
        """Generate audio waveform data"""
        if self.openshot_available:
            try:
                # Check if it's an audio file
                file_info = self.get_file_info(audio_file_path)
                if file_info.get("type") != "audio" and file_info.get("type") != "video":
                    raise OpenShotError("Waveforms can only be generated for audio or video files")
                
                # Create audio reader
                reader = openshot.FFmpegReader(audio_file_path)
                
                # Get audio properties
                sample_rate = reader.info.sample_rate
                channels = reader.info.channels
                duration = reader.info.duration
                
                # Generate waveform data
                # This is a simplified approach - in a real implementation,
                # we would process the actual audio samples
                
                # For now, we'll generate some random data as a placeholder
                import random
                sample_count = 1000  # Number of samples in the waveform
                waveform_data = []
                
                for i in range(sample_count):
                    time_point = i / sample_count * duration
                    frame = reader.GetFrame(int(time_point * reader.info.fps.ToFloat()))
                    
                    # Get audio samples
                    samples = []
                    for c in range(channels):
                        channel_value = abs(random.uniform(-1, 1))  # Random value for now
                        samples.append(channel_value)
                    
                    waveform_data.append({
                        "time": time_point,
                        "values": samples
                    })
                
                # Clean up
                reader.Close()
                
                return {
                    "success": True,
                    "waveform_data": waveform_data,
                    "sample_rate": sample_rate,
                    "channels": channels,
                    "duration": duration,
                    "file_path": audio_file_path
                }
                
            except Exception as e:
                print(f"Error generating waveform with OpenShot: {str(e)}")
        
        # Fallback implementation
        return {
            "success": True,
            "waveform_data": "placeholder_waveform_data",
            "file_path": audio_file_path
        }
        
    def get_file_info(self, file_path):
        """Get metadata for a media file"""
        filename = os.path.basename(file_path)
        name, ext = os.path.splitext(filename)
        ext = ext.lower()
        
        # Determine file type based on extension
        file_type = "unknown"
        if ext in ['.mp4', '.mov', '.avi', '.mkv', '.webm']:
            file_type = "video"
        elif ext in ['.mp3', '.wav', '.ogg', '.aac']:
            file_type = "audio"
        elif ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff']:
            file_type = "image"
        
        if self.openshot_available:
            try:
                # Base file info
                file_info = {
                    "path": file_path,
                    "filename": filename,
                    "type": file_type,
                    "extension": ext,
                    "exists": os.path.exists(file_path),
                    "size": os.path.getsize(file_path) if os.path.exists(file_path) else 0
                }
                
                # Get detailed info based on file type
                if file_type == "video" or file_type == "audio":
                    # Create FFmpeg reader
                    reader = openshot.FFmpegReader(file_path)
                    
                    # Add video properties if available
                    if file_type == "video":
                        file_info.update({
                            "width": reader.info.width,
                            "height": reader.info.height,
                            "fps": reader.info.fps.ToFloat(),
                            "duration": reader.info.duration,
                            "has_audio": reader.info.has_audio
                        })
                    
                    # Add audio properties
                    if file_type == "audio" or reader.info.has_audio:
                        file_info.update({
                            "duration": reader.info.duration,
                            "sample_rate": reader.info.sample_rate,
                            "channels": reader.info.channels
                        })
                    
                    # Clean up
                    reader.Close()
                    
                elif file_type == "image":
                    # Create image reader
                    reader = openshot.QtImageReader(file_path)
                    
                    # Add image properties
                    file_info.update({
                        "width": reader.info.width,
                        "height": reader.info.height
                    })
                    
                    # Clean up
                    reader.Close()
                
                return file_info
                
            except Exception as e:
                print(f"Error getting file info with OpenShot: {str(e)}")
        
        # Fallback to basic info if OpenShot is not available
        file_info = {
            "path": file_path,
            "filename": filename,
            "type": file_type,
            "extension": ext,
            "exists": os.path.exists(file_path),
            "size": os.path.getsize(file_path) if os.path.exists(file_path) else 0
        }
        
        # Try to get some basic metadata using ffprobe if available
        try:
            if file_type == "video" or file_type == "audio":
                cmd = [
                    "ffprobe", 
                    "-v", "error", 
                    "-show_entries", "format=duration,bit_rate:stream=width,height,sample_rate,channels,r_frame_rate", 
                    "-of", "json", 
                    file_path
                ]
                
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                
                if result.returncode == 0:
                    probe_data = json.loads(result.stdout)
                    
                    # Extract format information
                    format_data = probe_data.get("format", {})
                    duration = float(format_data.get("duration", 0))
                    
                    # Extract stream information (use first stream)
                    streams = probe_data.get("streams", [])
                    
                    if streams:
                        # Find video and audio streams
                        video_stream = None
                        audio_stream = None
                        
                        for stream in streams:
                            if stream.get("codec_type") == "video" and not video_stream:
                                video_stream = stream
                            elif stream.get("codec_type") == "audio" and not audio_stream:
                                audio_stream = stream
                        
                        # Add video properties
                        if video_stream and file_type == "video":
                            # Parse frame rate (format is typically "num/den")
                            fps = 30.0  # Default
                            r_frame_rate = video_stream.get("r_frame_rate", "30/1")
                            if "/" in r_frame_rate:
                                num, den = map(int, r_frame_rate.split("/"))
                                if den != 0:
                                    fps = num / den
                            
                            file_info.update({
                                "width": int(video_stream.get("width", 1920)),
                                "height": int(video_stream.get("height", 1080)),
                                "fps": fps,
                                "duration": duration,
                                "has_audio": audio_stream is not None
                            })
                        
                        # Add audio properties
                        if audio_stream and (file_type == "audio" or file_type == "video"):
                            file_info.update({
                                "duration": duration,
                                "sample_rate": int(audio_stream.get("sample_rate", 48000)),
                                "channels": int(audio_stream.get("channels", 2))
                            })
            
            elif file_type == "image":
                # Try to get image dimensions using PIL if available
                try:
                    from PIL import Image
                    with Image.open(file_path) as img:
                        file_info.update({
                            "width": img.width,
                            "height": img.height
                        })
                except ImportError:
                    # PIL not available, use fallback values
                    file_info.update({
                        "width": 1920,
                        "height": 1080
                    })
                    
                except Exception:
                    # Error opening image, use fallback values
                    file_info.update({
                        "width": 1920,
                        "height": 1080
                    })
                    
        except Exception as e:
            print(f"Error getting file info with ffprobe: {str(e)}")
            
            # Use fallback placeholder values
            if file_type == "video":
                file_info.update({
                    "width": 1920,
                    "height": 1080,
                    "fps": 30,
                    "duration": 60,
                    "has_audio": True
                })
            elif file_type == "audio":
                file_info.update({
                    "duration": 60,
                    "sample_rate": 48000,
                    "channels": 2
                })
            elif file_type == "image":
                file_info.update({
                    "width": 1920,
                    "height": 1080
                })
        
        return file_info